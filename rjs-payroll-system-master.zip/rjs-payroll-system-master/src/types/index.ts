

export interface Shift {
  id: string;
  name: string;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
}

export interface Employee {
  id: string;
  name: string;
  employeeId: string;
  department: string;
  role: string;
  status: 'Active' | 'On Leave' | 'Inactive';
  email: string;
  phone?: string;
  avatarUrl?: string; // Can be a web URL or a Data URL
  joinDate: string;
  dateOfBirth?: string;
  address?: string;
  salary?: number | null; // Allow null
  bankAccount?: string;
  sssNumber?: string;
  philhealthNumber?: string;
  pagibigNumber?: string;
  tinNumber?: string;
  permissionRole?: string;
  annualLeaveEntitlement?: number | null;
  shiftId?: string | null; // ID of the assigned shift
  notificationPreferences?: {
    email: boolean;
    inApp: boolean;
  };
  deletionRequested?: boolean;
  deletionRequestTimestamp?: any;
  passwordResetInitiated?: any; // Used to trigger real-time logout
  lastLogin?: {
    timestamp: any; // Firestore Timestamp
    ipAddress: string | null;
  };
}

export interface NotificationItem {
  id: string;
  userId?: string; // ID of the user this notification is for
  type: 'warning' | 'success' | 'info';
  text: string;
  timestamp: any; // To support Firestore Timestamps
  isRead: boolean;
  link?: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  leaveType: 'Annual' | 'Sick' | 'Unpaid' | 'Maternity' | 'Paternity' | 'Personal';
  startDate: string; 
  endDate: string;   
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  appliedDate: string; 
  approverComment?: string;
  processedBy?: string; // Name of the admin/user who processed the request
  processedByRole?: string; // Role of the processor, e.g., "Admin", "Manager"
  isArchived?: boolean;
  // appliedTimestamp?: any; // If using Firestore serverTimestamp
}

// Used for Visual Calendar page
export interface AttendanceEvent {
  id?: string;
  date: Date; 
  status: 'Present' | 'Absent' | 'Leave' | 'Holiday' | 'Weekend';
  employeeId?: string; // Firestore document ID of employee
  employeeName?: string; // Denormalized name
  title?: string;
  description?: string;
  repeatsYearly?: boolean;
  isStatic?: boolean; // To differentiate between DB and hardcoded holidays
}

export interface Payslip {
  id: string; // Firestore document ID (e.g., employeeId_year_month_period)
  employeeId: string; // Firestore document ID of employee
  humanReadableEmployeeId?: string; // e.g., EMP001
  employeeName: string;
  payrollMonth: string; // e.g., "July"
  payrollYear: number; // e.g., 2024
  payrollPeriod: string; // e.g., "1st-15th", "fullMonth"
  runDate: string; // YYYY-MM-DD, when this payroll was processed
  
  basicSalaryForPeriod: number; // Pro-rata basic salary for the period BEFORE absence deductions
  
  appliedOtherRates: Array<{
    name: string;
    type: RateType;
    originalValue: number; 
    calculatedAmount: number; 
    detail?: string; // Optional field for context like "X OT hours at Y%"
  }>;
  
  grossPay: number; // Total earnings (pro-rata basic + other rates)

  appliedDeductions: Array<{
    name: string;
    type: DeductionType | 'fixed_amount' | 'benefit_contribution'; // Allow 'fixed_amount' for things like absence deduction
    originalValue: number; 
    calculatedAmount: number; 
    detail?: string; // Optional field for context like "X days absent"
  }>;
  
  appliedLoans?: Array<{
    loanId: string;
    loanType: string;
    deductionAmount: number;
  }>;

  totalDeductions: number; 
  netPay: number; 
  currency: string; // e.g., "PHP"
  isArchived?: boolean;
  notes?: string; 
}


export interface ActivityFeedItem {
  id: string;
  text: string; 
  userId?: string; 
  userName: string; 
  userRole?: string; 
  timestamp: any; 
  avatarUrl?: string;
  avatarFallback?: string;
  relatedEntityType?: 'leave' | 'employee' | 'profile' | 'system' | 'payroll' | 'settings' | 'login'; 
  relatedEntityId?: string; 
  details?: Array<{ label: string; value: string }>;
  ipAddress?: string | null;
}

// Used for Attendance Records page (detailed clock-in/out)
export interface AttendanceRecord {
  id: string; // Firestore document ID
  employeeId: string; // Firestore document ID of employee
  date: string; // YYYY-MM-DD format
  morningIn?: string | null; // HH:mm format
  lunchOut?: string | null; // HH:mm format
  lunchIn?: string | null; // HH:mm format
  afternoonOut?: string | null; // HH:mm format
  shiftId?: string | null; // The shift ID active for this day
  notes?: string;
}

export interface AttendanceSettings {
  expectedMorningIn: string; 
  expectedLunchOut: string; 
  expectedLunchIn: string; 
  expectedAfternoonOut: string;
  requiredWorkHours: number; 
  lateGracePeriod: number; 
  earlyLeaveThreshold: number; 
  shifts?: Shift[];
}

// Payroll Settings
export type DeductionType = 'percentage_basic' | 'fixed_amount';
export type RateType = 'percentage' | 'fixed_amount';


export interface PayrollDeductionSetting {
  id: string; 
  name: string; 
  type: DeductionType;
  value: number;
  description?: string;
}

export interface PayrollRateSetting {
  id: string; 
  name: string; 
  type: RateType; 
  rate: number; 
  description?: string;
}

export interface TaxBracket {
  id: string;
  from: number;
  to: number | null;
  rate: number;
  baseAmount: number;
  description?: string;
}

export interface PayrollSettings {
  deductions: PayrollDeductionSetting[];
  otherRates: PayrollRateSetting[]; 
  taxRates: TaxBracket[]; 
  payslipCompanyName?: string;
  payslipCompanyAddress?: string;
  payslipCompanyContact?: string;
  payslipCompanyWebsite?: string;
  customFooter?: string;
}

export interface LeaveSettings {
  archiveOlderThanDays: number;
}

// Fields for Management Dialog
export interface Department {
  id: string;
  name: string;
}

export interface JobRole {
  id: string;
  name: string;
}

export interface HelpDeskTicket {
  id: string;
  submittedByUserId?: string;
  submittedByUserName?: string;
  submittedByUserEmail?: string;
  subject?: string;
  description?: string;
  status?: 'Open' | 'In Progress' | 'Resolved' | 'Closed';
  createdAt?: any;
  adminNotes?: string;
}

// New Financials Interfaces
export interface Loan {
  id: string;
  employeeId: string;
  employeeName: string;
  loanType: string;
  totalAmount: number;
  amountPaid: number;
  monthlyDeduction: number;
  startDate: string; // YYYY-MM-DD
  status: 'Active' | 'Paid Off';
  notes?: string;
}

export interface BenefitType {
  id: string;
  name: string;
}

export interface Benefit {
  id: string;
  employeeId: string;
  employeeName: string;
  benefitType: string;
  provider: string;
  policyNumber?: string;
  monthlyContribution: number; // Employee's share
  notes?: string;
}

export interface ThirteenthMonthPay {
  id: string; // e.g., employeeId_year
  employeeId: string;
  employeeName: string;
  year: number;
  totalBasicSalaryForYear: number;
  monthsIncluded: number;
  amount: number;
  runDate: string; // YYYY-MM-DD
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  authorName: string;
  authorId: string;
  timestamp: any;
  isPublished: boolean;
}

export interface AnnouncementComment {
  id: string;
  announcementId: string;
  userId: string;
  userName: string;
  userAvatarUrl?: string;
  userAvatarFallback: string;
  commentText: string;
  timestamp: any; // Firestore Timestamp
  parentCommentId?: string;
}
