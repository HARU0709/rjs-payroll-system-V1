
'use client';

import type { ReactNode } from 'react';
import { usePathname, useRouter, redirect } from 'next/navigation';
import {
  SidebarProvider,
  Sidebar,
  SidebarInset,
} from '@/components/ui/sidebar';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from '@/components/ui/button';
import { Loader2, LogOut, Timer } from 'lucide-react';
import { AppHeader } from './header';
import { SidebarNav } from './sidebar-nav';
import { useAuth } from '@/contexts/auth-context';
import { useEffect } from 'react';
import { useSessionTimeout } from '@/hooks/use-session-timeout';
import { AppInitializer } from './app-initializer';
import { ScrollArea } from '@/components/ui/scroll-area';

interface MainLayoutProps {
  children: ReactNode;
}

function SessionTimeoutDialog() {
  const { isWarningDialogOpen, countdown, isLoggingOut, handleLogout, handleStayLoggedIn } = useSessionTimeout();
  const minutes = Math.floor(countdown / 60);
  const seconds = countdown % 60;

  return (
    <AlertDialog open={isWarningDialogOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <Timer className="h-6 w-6 text-yellow-500" />
            Are you still there?
          </AlertDialogTitle>
          <AlertDialogDescription>
            For your security, you will be logged out automatically due to inactivity.
            Time remaining: {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <Button
            variant="outline"
            onClick={handleLogout}
            disabled={isLoggingOut}
          >
            {isLoggingOut ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <LogOut className="mr-2 h-4 w-4"/>}
            Log Out Now
          </Button>
          <AlertDialogAction onClick={handleStayLoggedIn} disabled={isLoggingOut}>
            Stay Logged In
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}


export function MainLayout({ children }: MainLayoutProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, loading } = useAuth();
  
  if (pathname === '/') {
    redirect('/login');
  }

  useEffect(() => {
    if (!loading) {
      const isAuthPage = pathname === '/login' || pathname === '/auth/action';
      if (!user && !isAuthPage) {
        router.push('/login');
      } else if (user && isAuthPage) {
        router.push('/dashboard');
      }
    }
  }, [user, loading, pathname, router]);

  if (loading) {
    return null;
  }
  
  if (pathname === '/login' || pathname === '/auth/action') {
    return <>{children}</>;
  }
  
  if (!user && pathname !== '/login') {
    return null;
  }


  return (
    <SidebarProvider defaultOpen>
      <AppInitializer />
      <Sidebar variant="sidebar" collapsible="icon">
        <SidebarNav />
      </Sidebar>
      <SidebarInset className="flex h-screen flex-col overflow-hidden">
        <AppHeader />
        <ScrollArea className="flex-1">
          <main className="p-4 sm:p-6 lg:p-8">
            {children}
          </main>
        </ScrollArea>
        <SessionTimeoutDialog />
      </SidebarInset>
    </SidebarProvider>
  );
}
