
'use client';

import { useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';

// This component handles client-side effects that need to run once on app load.
export function AppInitializer() {
  const { user, loading } = useAuth();

  // Effect for setting up theme, font, and right-click prevention
  useEffect(() => {
    // Disable right-click context menu
    const handleContextmenu = (e: MouseEvent) => {
      e.preventDefault();
    };
    document.addEventListener('contextmenu', handleContextmenu);

    // Apply saved theme and font settings from localStorage
    const savedFont = localStorage.getItem('app-font') || 'sans';
    const savedTheme = localStorage.getItem('app-theme') || 'default';
    const savedFontSize = (localStorage.getItem('app-font-size') as any) || 'default';
    const savedIsDark = localStorage.getItem('dark-mode') === 'true';

    const root = document.documentElement;
    const body = document.body;

    body.classList.remove('font-sans', 'font-roboto', 'font-lato');
    body.classList.add(`font-${savedFont}`);

    root.setAttribute('data-theme', savedTheme);
    root.setAttribute('data-font-size', savedFontSize);

    if (savedIsDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    // Cleanup function to remove event listener
    return () => {
      document.removeEventListener('contextmenu', handleContextmenu);
    };
  }, []); // Empty dependency array ensures this runs only once on mount

  return null; // This component does not render anything
}
