
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Bell, ExternalLink, MailOpen, Trash2, DollarSign, Plane, LifeBuoy, Megaphone } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { NotificationItem } from '@/types';
import { ScrollArea } from '@/components/ui/scroll-area';
import { db } from '@/lib/firebase';
import { collection, query, where, orderBy, limit, onSnapshot, writeBatch, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { formatDistanceToNow, isValid } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth-context';

export function NotificationsDropdown() {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!user) {
      setLoading(false);
      setNotifications([]);
      return;
    }

    setLoading(true);
    const notificationsCollection = collection(db, "notifications");
    const q = query(
      notificationsCollection, 
      where("userId", "==", user.uid),
      orderBy("timestamp", "desc"),
      limit(10)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedNotifications = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as NotificationItem));

      setNotifications(fetchedNotifications);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching user notifications:", error);
      toast({
        title: "Error",
        description: "Could not fetch your notifications.",
        variant: "destructive",
      });
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, toast]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      const notificationRef = doc(db, "notifications", notificationId);
      await updateDoc(notificationRef, { isRead: true });
    } catch (error) {
      console.error("Error updating notification state:", error);
      toast({ title: "Error", description: "Could not mark notification as read.", variant: "destructive" });
    }
  };

  const handleNotificationClick = async (notification: NotificationItem) => {
    if (!notification.isRead) {
      await handleMarkAsRead(notification.id);
    }
    if (notification.link) {
      router.push(notification.link);
    }
    setOpen(false); // Close dropdown after clicking
  };

  const markAllAsRead = async () => {
    if (unreadCount === 0 || !user) return;
    
    const unreadIds = notifications.filter(n => !n.isRead).map(n => n.id);
    if (unreadIds.length === 0) return;

    const batch = writeBatch(db);
    unreadIds.forEach(id => {
      const docRef = doc(db, "notifications", id);
      batch.update(docRef, { isRead: true });
    });

    try {
      await batch.commit();
    } catch (error) {
       console.error("Error marking all notifications as read:", error);
       toast({
        title: "Error",
        description: "Could not mark all notifications as read.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteNotification = async (notificationId: string) => {
    try {
      await deleteDoc(doc(db, "notifications", notificationId));
      toast({ title: "Notification Deleted", variant: 'success' });
    } catch (error) {
      console.error("Error deleting notification:", error);
      toast({ title: "Error", description: "Could not delete notification.", variant: "destructive" });
    }
  };
  
  const formatTimestamp = (timestamp: any): string => {
    if (!timestamp) return 'Just now';
    let date: Date;
    if (timestamp?.toDate && typeof timestamp.toDate === 'function') {
      date = timestamp.toDate();
    } else {
      date = new Date(timestamp);
    }
    
    if (!isValid(date)) return 'Invalid date';

    return formatDistanceToNow(date, { addSuffix: true });
  };
  
  const getNotificationIcon = (link?: string) => {
    const iconClass = "h-4 w-4 text-white";
    if (link?.includes('announcement')) {
      return <Megaphone className={iconClass} />;
    }
    switch (link) {
      case '/payroll':
        return <DollarSign className={iconClass} />;
      case '/leave':
        return <Plane className={iconClass} />;
      case '/help-desk':
        return <LifeBuoy className={iconClass} />;
      default:
        return <Bell className={iconClass} />;
    }
  };

  const getIconBgClass = (type: NotificationItem['type']) => {
    switch (type) {
      case 'success':
        return "bg-green-500";
      case 'warning':
        return "bg-amber-500";
      case 'info':
      default:
        return "bg-blue-500";
    }
  };


  return (
    <TooltipProvider delayDuration={300}>
      <DropdownMenu open={open} onOpenChange={setOpen}>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Notifications"
            className="relative rounded-full focus-visible:ring-0 focus-visible:ring-offset-0 hover:text-muted-foreground"
          >
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-96" align="end">
          <DropdownMenuLabel className="flex items-center justify-between p-2">
            <span className="font-semibold">Notifications</span>
            {unreadCount > 0 && (
              <Button variant="link" size="sm" className="h-auto p-0" onClick={markAllAsRead}>
                Mark all as read
              </Button>
            )}
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <ScrollArea className="h-[300px]">
            {loading ? (
              <div className="flex h-full items-center justify-center p-4 text-center text-sm text-muted-foreground">
                Loading notifications...
              </div>
            ) : notifications.length > 0 ? (
              notifications.map((notification) => (
                <DropdownMenuItem
                  key={notification.id}
                  className={cn(
                    'group relative flex flex-col items-start p-3 focus:bg-accent',
                    !notification.isRead && 'bg-primary/5',
                    'cursor-default'
                  )}
                  onSelect={(e) => e.preventDefault()}
                >
                  <div className="flex w-full items-start gap-3">
                    <div className={cn(
                          "flex h-7 w-7 shrink-0 items-center justify-center rounded-full",
                          getIconBgClass(notification.type)
                        )}>
                      {getNotificationIcon(notification.link)}
                    </div>
                    <div className="flex-1 space-y-0.5">
                      <p className="text-sm leading-snug">{notification.text}</p>
                      <p className={cn('text-xs', !notification.isRead ? 'font-medium text-primary' : 'text-muted-foreground')}>
                        {formatTimestamp(notification.timestamp)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex w-full justify-end items-center gap-1 overflow-hidden max-h-0 opacity-0 group-hover:max-h-8 group-hover:mt-2 group-hover:opacity-100 transition-all duration-300 ease-in-out">
                    {!notification.isRead && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            className="h-8 w-8 gap-0 rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200 dark:bg-blue-900/50 dark:text-blue-400 dark:hover:bg-blue-900"
                            onClick={() => handleMarkAsRead(notification.id)}
                          >
                            <MailOpen className="h-5 w-5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="px-2 py-1 text-xs">Mark as read</TooltipContent>
                      </Tooltip>
                    )}
                    {notification.link && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            size="icon"
                            className="h-8 w-8 gap-0 rounded-full bg-green-100 text-green-600 hover:bg-green-200 dark:bg-green-900/50 dark:text-green-400 dark:hover:bg-green-900"
                            onClick={() => handleNotificationClick(notification)}
                          >
                            <ExternalLink className="h-5 w-5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="px-2 py-1 text-xs">Open link</TooltipContent>
                      </Tooltip>
                    )}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="icon"
                          className="h-8 w-8 gap-0 rounded-full bg-red-100 text-red-600 hover:bg-red-200 dark:bg-red-900/50 dark:text-red-400 dark:hover:bg-red-900"
                          onClick={() => handleDeleteNotification(notification.id)}
                        >
                          <Trash2 className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent className="px-2 py-1 text-xs">Delete</TooltipContent>
                    </Tooltip>
                  </div>
                </DropdownMenuItem>
              ))
            ) : (
              <div className="flex h-full flex-col items-center justify-center p-4 text-center text-muted-foreground">
                <Bell className="mb-2 h-8 w-8" />
                <p className="font-semibold">You're all caught up!</p>
                <p className="text-xs">New notifications will appear here.</p>
              </div>
            )}
          </ScrollArea>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild className="group justify-center p-2 bg-primary text-primary-foreground hover:bg-accent focus:bg-accent">
            <Link href="/notifications" className="flex items-center gap-2 text-sm group-hover:text-accent-foreground focus:text-accent-foreground outline-none">
              View all notifications <ExternalLink className="h-4 w-4" />
            </Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </TooltipProvider>
  );
}
