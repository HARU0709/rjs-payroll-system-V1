
'use client';
import { useState, useEffect, type KeyboardEvent } from 'react';
import { useRouter } from 'next/navigation';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { UserNav } from './user-nav';
import { Button } from '@/components/ui/button';
import { Sun, Moon, Search, History } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { NotificationsDropdown } from './notifications-dropdown';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/auth-context';
import { format } from 'date-fns';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';


export function AppHeader() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const router = useRouter();
  const { employeeProfile } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';

  useEffect(() => {
    const checkDarkMode = () => document.documentElement.classList.contains('dark');
    setIsDarkMode(checkDarkMode());

    const observer = new MutationObserver(() => {
      setIsDarkMode(checkDarkMode());
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const toggleTheme = () => {
    const isDark = document.documentElement.classList.toggle('dark');
    setIsDarkMode(isDark);
    localStorage.setItem('dark-mode', String(isDark));
  };

  const handleSearch = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchTerm.trim()) {
      router.push(`/employees?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <header className="sticky top-0 z-10 h-16 w-full border-b border-border bg-background/90 backdrop-blur-sm">
      <div className="container flex h-full max-w-screen-2xl items-center px-4 md:px-6">
        <div className="flex items-center gap-2">
          <div className="md:hidden">
            <SidebarTrigger />
          </div>
          {isAdmin && (
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search employees..."
                className="h-9 w-full rounded-lg pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleSearch}
              />
            </div>
          )}
        </div>

        <div className="flex flex-1 items-center justify-end gap-2">
          {employeeProfile?.lastLogin && (
             <TooltipProvider delayDuration={100}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground border-r pr-3 mr-1">
                    <History className="h-4 w-4" />
                    <span>
                      {format(employeeProfile.lastLogin.timestamp.toDate(), 'p')}
                    </span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Last login: {format(employeeProfile.lastLogin.timestamp.toDate(), 'PPP p')}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}

          <div className="hidden md:block">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Toggle Theme"
              onClick={toggleTheme}
              className="rounded-full relative overflow-hidden focus-visible:ring-0 focus-visible:ring-offset-0 transition-colors duration-200 hover:text-muted-foreground"
            >
              <Sun
                className={cn(
                  'h-5 w-5 transition-all duration-300 ease-in-out',
                  isDarkMode ? 'transform rotate-90 scale-0 opacity-0' : 'transform rotate-0 scale-100 opacity-100'
                )}
              />
              <Moon
                className={cn(
                  'h-5 w-5 absolute transition-all duration-300 ease-in-out',
                  isDarkMode ? 'transform rotate-0 scale-100 opacity-100' : 'transform rotate-90 scale-0 opacity-0'
                )}
              />
            </Button>
          </div>

          <Separator orientation="vertical" className="h-6 hidden md:block" />

          <NotificationsDropdown />
          
          <Separator orientation="vertical" className="h-6" />

          <UserNav />
        </div>
      </div>
    </header>
  );
}
