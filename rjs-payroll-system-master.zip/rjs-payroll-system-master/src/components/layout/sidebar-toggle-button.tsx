
'use client';

import { Button } from '@/components/ui/button';
import { useSidebar } from '@/hooks/use-sidebar';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export function SidebarToggleButton({ className, side = "left" }: { className?: string, side?: "left" | "right" }) {
  const { toggleSidebar, open, isMobile } = useSidebar();

  if (isMobile) {
    return null; // This button is for desktop sidebar
  }

  // When this button is rendered, it's for the 'icon' collapsible mode on desktop.
  // 'open' is true if the sidebar is expanded, false if collapsed to icon view.
  const positionClasses = side === "left"
    ? (open
        ? "right-0 translate-x-1/2" // Expanded: Centered on the right edge
        : "left-full ml-1")          // Collapsed to icon: To the right of the sidebar, with a small gap
    : (open
        ? "left-0 -translate-x-1/2" // Expanded: Centered on the left edge
        : "right-full mr-1");        // Collapsed to icon: To the left of the sidebar, with a small gap

  return (
    <Button
      variant="default" // Uses primary color
      size="icon"
      className={cn(
        "absolute top-[302px] -translate-y-1/2 z-20 rounded-full h-9 w-9 p-0 shadow-lg hover:bg-primary/90 hover:-translate-y-1/2 active:-translate-y-1/2",
        positionClasses, // Apply dynamic positioning
        className
      )}
      onClick={toggleSidebar}
      aria-label={open ? "Collapse sidebar" : "Expand sidebar"}
    >
      {open ? (
        <ChevronLeft className="h-5 w-5 text-primary-foreground" />
      ) : (
        <ChevronRight className="h-5 w-5 text-primary-foreground" />
      )}
    </Button>
  );
}
