
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';
import {
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarSeparator,
  SidebarMenuBadge,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton
} from '@/components/ui/sidebar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  LayoutDashboard,
  Users,
  Clock, 
  DollarSign, 
  Plane,
  TrendingUp, 
  FileText, 
  Bell, 
  Settings,
  Briefcase, 
  CalendarDays,
  KeyRound,
  Shield,
  LifeBuoy,
  X,
  Send,
  Loader2,
  Landmark,
  Megaphone,
  Gift,
  ChevronDown,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/auth-context';
import { useSidebar } from '@/hooks/use-sidebar';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from "@/hooks/use-toast";
import { db } from '@/lib/firebase';
import { collection, addDoc, query, where, onSnapshot } from 'firebase/firestore';


const mainNavItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, permission: 'dashboard:view' },
  { href: '/employees', label: 'Employees', icon: Users, permission: 'employees:view' },
  { 
    href: '/calendar', 
    label: 'Visual Calendar', 
    icon: CalendarDays, 
    permission: 'calendar:view',
    subItems: [
      { href: '/holidays', label: 'Holidays', icon: Gift, permission: 'employees:manage'}
    ]
  },
  { href: '/attendance', label: 'Attendance', icon: Clock, permission: 'attendance:manage' },
  { href: '/payroll', label: 'Payroll', icon: DollarSign, permission: 'payroll:view_history' },
  { href: '/financials', label: 'Financials', icon: Landmark, permission: 'financials:manage' },
  { href: '/leave', label: 'Leave', icon: Plane, permission: 'leave:apply' },
  { href: '/reports', label: 'Reports', icon: TrendingUp, permission: 'reports:view' },
  { href: '/announcements', label: 'Announcements', icon: Megaphone, permission: 'announcements:manage' },
  { href: '/help-desk', label: 'Help Desk', icon: LifeBuoy, permission: 'helpdesk:view' },
];

const footerNavItems = [
  { href: '/notifications', label: 'Notifications', icon: Bell },
  { href: '/settings', label: 'Settings', icon: Settings },
];

const helpDeskSchema = z.object({
  subject: z.string().min(5, "Subject must be at least 5 characters long."),
  description: z.string().min(20, "Please provide a detailed description of your concern (at least 20 characters)."),
});

type HelpDeskFormValues = z.infer<typeof helpDeskSchema>;

export function SidebarNav() {
  const pathname = usePathname();
  const { permissions, employeeProfile } = useAuth();
  const { isMobile, state: sidebarState } = useSidebar();
  const { toast } = useToast();
  
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  const [openTicketCount, setOpenTicketCount] = useState(0);

  const [isHelpCardVisible, setIsHelpCardVisible] = useState(false);
  const [isHelpDialogOpen, setIsHelpDialogOpen] = useState(false);
  const [isSubmittingHelp, setIsSubmittingHelp] = useState(false);

  const [openSubMenus, setOpenSubMenus] = useState<string[]>([]);

  useEffect(() => {
    // Show the card on initial load for the session
    setIsHelpCardVisible(true);

    // Automatically open the submenu if one of its items is active
    const activeSubMenuParent = mainNavItems.find(item => 
      item.subItems?.some(sub => pathname === sub.href)
    );
    if (activeSubMenuParent) {
      setOpenSubMenus(prev => [...new Set([...prev, activeSubMenuParent.href])]);
    }
  }, [pathname]);
  
  // Real-time listener for open help desk tickets for admins
  useEffect(() => {
    if (!isAdmin) {
      setOpenTicketCount(0);
      return;
    }

    const ticketsCollection = collection(db, "helpDeskTickets");
    const q = query(ticketsCollection, where("status", "==", "Open"));

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      setOpenTicketCount(querySnapshot.size);
    }, (error) => {
      console.error("Error fetching open ticket count:", error);
      toast({
        title: "Error",
        description: "Could not fetch help desk notifications.",
        variant: "destructive",
      });
    });

    return () => unsubscribe();
  }, [isAdmin, toast]);

  const form = useForm<HelpDeskFormValues>({
    resolver: zodResolver(helpDeskSchema),
    defaultValues: { subject: '', description: '' },
  });

  const handleDismissHelpCard = () => {
    setIsHelpCardVisible(false);
  };

  const onSubmitHelpRequest = async (data: HelpDeskFormValues) => {
    if (!employeeProfile || !employeeProfile.id) {
      toast({ title: 'Error', description: 'Could not identify your user profile. Please try logging in again.', variant: 'destructive' });
      return;
    }
    setIsSubmittingHelp(true);
    
    const ticketDataForFirestore = {
      submittedByUserId: String(employeeProfile.id),
      submittedByUserName: String(employeeProfile.name || 'Unknown User'),
      submittedByUserEmail: String(employeeProfile.email || 'no-email@provided.com'),
      subject: String(data.subject),
      description: String(data.description),
      status: 'Open',
      createdAt: new Date(),
      adminNotes: '',
    };

    try {
      await addDoc(collection(db, "helpDeskTickets"), ticketDataForFirestore);
      
      toast({ title: 'Success', description: 'Your support ticket has been submitted.', variant: 'success' });
      form.reset();
      setIsHelpDialogOpen(false);
    } catch (error) {
      console.error("Error submitting help ticket:", error);
      toast({ title: 'Error', description: 'Failed to submit your ticket. Please try again.', variant: 'destructive' });
    } finally {
      setIsSubmittingHelp(false);
    }
  };

  const hasPermission = (requiredPermission?: string) => {
    if (!requiredPermission) return true;
    return permissions.includes(requiredPermission);
  };
  
  const toggleSubMenu = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    e.stopPropagation();
    setOpenSubMenus(prev => 
      prev.includes(href) ? prev.filter(item => item !== href) : [...prev, href]
    );
  };

  const filteredMainNavItems = mainNavItems.filter(item => hasPermission(item.permission));
  
  const userName = employeeProfile?.name || 'User';
  const userRole = employeeProfile?.permissionRole || 'No Role Assigned';
  
  const isSidebarCollapsed = sidebarState === 'collapsed' && !isMobile;

  return (
    <>
      <SidebarHeader className="p-4">
        <Link href="/dashboard" className="flex items-center gap-2 group-data-[collapsible=icon]:justify-center">
          <div className="flex items-center justify-center h-8 w-8 bg-white rounded-md group-data-[collapsible=icon]:h-7 group-data-[collapsible=icon]:w-7">
            <span className="font-bold text-primary text-sm">RJS</span>
          </div>
          <h1 className="text-lg font-semibold text-primary-foreground group-data-[collapsible=icon]:hidden">RJS Payroll System</h1>
        </Link>
      </SidebarHeader>
      <SidebarSeparator className="group-data-[collapsible=icon]:mx-1" />
      
      <div className="p-3 group-data-[collapsible=icon]:p-2 group-data-[collapsible=icon]:py-3">
        <div className="flex items-center gap-3 group-data-[collapsible=icon]:justify-center">
          <div className="flex items-center justify-center h-10 w-10 bg-white/20 rounded-full p-2 group-data-[collapsible=icon]:h-8 group-data-[collapsible=icon]:w-8 group-data-[collapsible=icon]:p-1.5">
            {userRole === 'Administrator' ? (
              <Shield className="h-full w-full text-white" />
            ) : (
              <Briefcase className="h-full w-full text-white" />
            )}
          </div>
          <div className="group-data-[collapsible=icon]:hidden">
            <p className="text-sm font-semibold text-sidebar-foreground">{userName}</p>
            <p className="text-xs text-sidebar-foreground/80">{userRole.toUpperCase()}</p>
          </div>
        </div>
      </div>
      <SidebarSeparator className="group-data-[collapsible=icon]:mx-1" />

      <SidebarContent className="p-2">
        <SidebarMenu>
          {filteredMainNavItems.map((item) => {
            const isHelpDeskItem = item.href === '/help-desk';
            const hasSubItems = item.subItems && item.subItems.length > 0 && item.subItems.some(sub => hasPermission(sub.permission));
            const isSubMenuOpen = openSubMenus.includes(item.href);
            const isAnySubItemActive = hasSubItems && item.subItems.some(sub => pathname === sub.href);
            const isParentActive = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href) && !isAnySubItemActive);

            const menuItemContent = (
              <SidebarMenuButton
                isActive={isParentActive || isAnySubItemActive}
                tooltip={{ children: item.label, className: "ml-2" }}
                className="justify-start group-data-[collapsible=icon]:h-9 group-data-[collapsible=icon]:w-9 flex-grow"
              >
                <item.icon className="h-5 w-5 group-data-[collapsible=icon]:h-[18px] group-data-[collapsible=icon]:w-[18px]" />
                <span className="group-data-[collapsible=icon]:hidden">{item.label}</span>
                {isHelpDeskItem && isAdmin && openTicketCount > 0 && (
                  <SidebarMenuBadge className="bg-red-500 text-white rounded-full">{openTicketCount}</SidebarMenuBadge>
                )}
                {hasSubItems && !isSidebarCollapsed && (
                  <div
                      role="button"
                      onClick={(e) => toggleSubMenu(e, item.href)}
                      className={cn("absolute right-2 top-1/2 -translate-y-1/2 p-0.5 rounded-md text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-black/10 transition-colors", (isParentActive || isAnySubItemActive) && "text-sidebar-primary-foreground/80 hover:text-sidebar-primary-foreground")}
                      aria-label={isSubMenuOpen ? "Collapse section" : "Expand section"}
                  >
                      <ChevronDown className={cn("h-4 w-4 transition-transform duration-200", isSubMenuOpen && "rotate-180")} />
                  </div>
                )}
              </SidebarMenuButton>
            );

            if (hasSubItems && isSidebarCollapsed) {
              return (
                <SidebarMenuItem key={item.href}>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      {menuItemContent}
                    </DropdownMenuTrigger>
                    <DropdownMenuContent side="right" align="start" sideOffset={10}>
                      <DropdownMenuItem asChild>
                        <Link href={item.href}>
                           <item.icon className="mr-2 h-4 w-4" />
                          {item.label}
                        </Link>
                      </DropdownMenuItem>
                      {item.subItems
                        .filter(sub => hasPermission(sub.permission))
                        .map(subItem => (
                          <DropdownMenuItem key={subItem.href} asChild>
                            <Link href={subItem.href}>
                              <subItem.icon className="mr-2 h-4 w-4" />
                              {subItem.label}
                            </Link>
                          </DropdownMenuItem>
                        ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </SidebarMenuItem>
              );
            }

            return (
              <SidebarMenuItem key={item.href}>
                <Link href={item.href} passHref legacyBehavior>
                  <a className={cn(hasSubItems && 'flex items-center w-full')}>
                    {menuItemContent}
                  </a>
                </Link>
                {hasSubItems && isSubMenuOpen && (
                  <SidebarMenuSub>
                    {item.subItems
                      .filter(sub => hasPermission(sub.permission))
                      .map(subItem => (
                        <SidebarMenuSubItem key={subItem.href}>
                          <Link href={subItem.href} passHref legacyBehavior>
                            <SidebarMenuSubButton isActive={pathname === subItem.href} asChild>
                              <a>
                                <subItem.icon className="h-4 w-4 shrink-0" />
                                <span>{subItem.label}</span>
                              </a>
                            </SidebarMenuSubButton>
                          </Link>
                        </SidebarMenuSubItem>
                      ))
                    }
                  </SidebarMenuSub>
                )}
              </SidebarMenuItem>
            );
          })}
        </SidebarMenu>
      </SidebarContent>
      
      {isHelpCardVisible && !isMobile && !isAdmin && (
        <div className="p-3 group-data-[collapsible=icon]:hidden">
          <div className="relative rounded-lg bg-black/10 dark:bg-black/20 p-4">
            <Button variant="ghost" size="icon" className="absolute top-1 right-1 h-6 w-6 text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-white/10" onClick={handleDismissHelpCard}>
              <X className="h-4 w-4" />
            </Button>
            <div className="flex items-center gap-2 mb-2 text-sidebar-foreground">
                <LifeBuoy className="h-5 w-5" />
                <h4 className="font-semibold">Help Desk</h4>
            </div>
            <p className="text-xs text-sidebar-foreground/80 mb-3">
                Need assistance? Submit a ticket to our support team for any issues or questions.
            </p>
            <Button 
                className="w-full h-8 text-xs bg-sidebar-primary-foreground text-primary hover:bg-sidebar-primary-foreground/90"
                onClick={() => setIsHelpDialogOpen(true)}
            >
                Submit a Ticket
            </Button>
          </div>
        </div>
      )}

      <SidebarFooter className="p-2">
         <SidebarMenu>
            {footerNavItems.map((item) => (
               <SidebarMenuItem key={item.href}>
                <Link href={item.href} passHref legacyBehavior>
                  <SidebarMenuButton
                      asChild
                      isActive={pathname.startsWith(item.href)}
                      tooltip={{children: item.label, className: "ml-2"}}
                      className="justify-start group-data-[collapsible=icon]:h-9 group-data-[collapsible=icon]:w-9"
                  >
                      <a>
                          <item.icon className="h-5 w-5 group-data-[collapsible=icon]:h-[18px] group-data-[collapsible=icon]:w-[18px]" />
                          <span className="group-data-[collapsible=icon]:hidden">{item.label}</span>
                      </a>
                  </SidebarMenuButton>
                </Link>
              </SidebarMenuItem>
            ))}
        </SidebarMenu>
        {!isAdmin && (
          <>
            <SidebarSeparator className="my-2 group-data-[collapsible=icon]:mx-1" />
            <p className="px-2 text-xs text-sidebar-foreground/60 group-data-[collapsible=icon]:hidden text-center">
              © 2025 RJS Payroll System
            </p>
          </>
        )}
      </SidebarFooter>

      <Dialog open={isHelpDialogOpen} onOpenChange={setIsHelpDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Submit a Help Desk Ticket</DialogTitle>
            <DialogDescription>
              Describe your issue or question below. Our admin team will get back to you.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form id="help-desk-form" onSubmit={form.handleSubmit(onSubmitHelpRequest)} className="space-y-4 py-2">
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl><Input {...field} placeholder="e.g., Payroll calculation error" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl><Textarea {...field} placeholder="Please provide as much detail as possible..." rows={5} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </form>
          </Form>
          <DialogFooter>
            <DialogClose asChild><Button type="button" variant="outline" disabled={isSubmittingHelp}>Cancel</Button></DialogClose>
            <Button type="submit" form="help-desk-form" disabled={isSubmittingHelp}>
              {isSubmittingHelp ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
              Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
