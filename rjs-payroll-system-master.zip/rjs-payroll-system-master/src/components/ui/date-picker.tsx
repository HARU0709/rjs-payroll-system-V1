
"use client"

import * as React from "react"
import { format } from "date-fns"
import { Calendar as CalendarIcon } from "lucide-react"
import type { DateRange } from "react-day-picker";

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar, type CalendarProps } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

// NOTE: This component is simplified. For more complex form scenarios,
// it might be better to build the Popover + Calendar structure directly
// within a <FormField> to ensure correct accessibility and state management.

interface DatePickerProps {
  date?: Date;
  onDateChange?: (date?: Date) => void;
  placeholder?: string;
  className?: string;
  buttonClassName?: string;
  captionLayout?: "dropdown-buttons" | "buttons";
  fromYear?: number;
  toYear?: number;
  disabled?: ((date: Date) => boolean) | boolean;
  numberOfMonths?: number;
  mode?: "single" | "range";
  selected?: Date | DateRange;
  onSelect?: (date: DateRange | undefined) => void;
}

export function DatePicker({
  date,
  onDateChange,
  placeholder = "Pick a date",
  className,
  buttonClassName,
  captionLayout,
  fromYear,
  toYear,
  disabled,
  numberOfMonths = 1,
  mode = "single",
  selected,
  onSelect
}: DatePickerProps) {
  
  const isPickerDisabled = typeof disabled === 'boolean' && disabled;

  let displayValue: React.ReactNode = <span>{placeholder || "Pick a date"}</span>;
  let hasValue = false;

  if (mode === 'range') {
    const range = selected as DateRange | undefined;
    if (range?.from) {
      hasValue = true;
      if (range.to) {
        displayValue = `${format(range.from, "LLL dd, y")} - ${format(range.to, "LLL dd, y")}`;
      } else {
        displayValue = format(range.from, "LLL dd, y");
      }
    }
  } else {
    const singleDate = selected as Date | undefined || date;
    if (singleDate) {
      hasValue = true;
      displayValue = format(singleDate, "PPP");
    }
  }
  
  return (
    <Popover>
      <PopoverTrigger asChild className={className}>
        <Button
          variant={"outline"}
          disabled={isPickerDisabled}
          className={cn(
            "w-full justify-start text-left font-normal",
            !hasValue && "text-muted-foreground",
            buttonClassName
          )}
        >
          <span className="flex items-center">
            <CalendarIcon className="mr-2 h-4 w-4" />
            {displayValue}
          </span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <Calendar
          mode={mode as "single" | "range"}
          selected={selected || date}
          onSelect={onSelect || onDateChange as any}
          disabled={typeof disabled === 'function' ? disabled : undefined}
          captionLayout={captionLayout}
          fromYear={fromYear}
          toYear={toYear}
          numberOfMonths={numberOfMonths}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  )
}
