
import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: ReactNode;
  icon?: ReactNode; // New optional icon prop
  className?: string;
}

export function PageHeader({ title, description, actions, icon, className }: PageHeaderProps) {
  return (
    <div className={cn("mb-6 md:flex md:items-center md:justify-between", className)}>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-3"> {/* Flex container for icon and title */}
          {icon && <div className="flex-shrink-0">{icon}</div>}
          <h2 className="text-2xl font-bold leading-7 text-foreground sm:truncate sm:text-3xl sm:tracking-tight">
            {title}
          </h2>
        </div>
        {description && (
          <p className={cn("mt-1 text-sm text-muted-foreground", icon && "md:ml-[calc(theme(height.7)_+_theme(spacing.3))]")}>{description}</p>
        )}
      </div>
      {actions && <div className="mt-4 flex md:ml-4 md:mt-0">{actions}</div>}
    </div>
  );
}
