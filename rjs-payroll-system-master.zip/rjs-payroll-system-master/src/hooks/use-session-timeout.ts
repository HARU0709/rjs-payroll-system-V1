
'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { useRouter } from 'next/navigation';
import { useToast } from './use-toast';
import { signOut } from 'firebase/auth';
import { auth } from '@/lib/firebase';

const INACTIVITY_TIMEOUT_MS = 28 * 60 * 1000; // 28 minutes
const WARNING_DURATION_MS = 2 * 60 * 1000; // 2 minutes

// This hook now returns state and functions, NOT JSX.
export function useSessionTimeout() {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const [isWarningDialogOpen, setIsWarningDialogOpen] = useState(false);
  const [countdown, setCountdown] = useState(WARNING_DURATION_MS / 1000);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const inactivityTimerRef = useRef<NodeJS.Timeout>();
  const logoutTimerRef = useRef<NodeJS.Timeout>();
  const countdownIntervalRef = useRef<NodeJS.Timer>();

  const handleLogout = useCallback(async () => {
    setIsLoggingOut(true);
    try {
      await signOut(auth);
      toast({
        title: 'Session Expired',
        description: 'You have been logged out due to inactivity.',
        variant: 'default',
      });
      router.push('/login');
    } catch (error) {
      console.error("Logout error:", error);
      toast({
        title: 'Logout Failed',
        description: 'Could not log you out. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsWarningDialogOpen(false);
      setIsLoggingOut(false);
    }
  }, [router, toast]);

  const startLogoutTimer = useCallback(() => {
    // Clear any previously existing logout timers to be safe
    if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);

    logoutTimerRef.current = setTimeout(handleLogout, WARNING_DURATION_MS);
    
    setCountdown(WARNING_DURATION_MS / 1000);
    countdownIntervalRef.current = setInterval(() => {
        setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
  }, [handleLogout]);

  const showWarningDialog = useCallback(() => {
    setIsWarningDialogOpen(true);
    startLogoutTimer();
  }, [startLogoutTimer]);

  const resetInactivityTimer = useCallback(() => {
    if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);

    if (user) {
      inactivityTimerRef.current = setTimeout(showWarningDialog, INACTIVITY_TIMEOUT_MS);
    }
  }, [user, showWarningDialog]);
  
  const handleStayLoggedIn = () => {
    setIsWarningDialogOpen(false);
    // Clear the timers that were set when the dialog opened
    if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    // And reset the main inactivity timer
    resetInactivityTimer();
  };

  useEffect(() => {
    if (user) {
      const events: (keyof WindowEventMap)[] = ['mousemove', 'keydown', 'click', 'scroll'];
      
      const eventListener = () => {
        // Only reset the main timer if the warning is not currently open
        if (!isWarningDialogOpen) {
          resetInactivityTimer();
        }
      };

      events.forEach(event => window.addEventListener(event, eventListener));
      
      resetInactivityTimer();

      return () => {
        events.forEach(event => window.removeEventListener(event, eventListener));
        if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
        if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
        if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
      };
    }
  }, [user, resetInactivityTimer, isWarningDialogOpen]);

  return {
    isWarningDialogOpen,
    countdown,
    isLoggingOut,
    handleLogout,
    handleStayLoggedIn,
  };
}
