
'use client';

import type { ReactNode } from 'react';
import { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import { auth, db } from '@/lib/firebase';
import { doc, getDoc, setDoc, onSnapshot, updateDoc } from 'firebase/firestore';
import { Skeleton } from '@/components/ui/skeleton';
import type { Employee } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

interface AuthContextType {
  user: User | null;
  employeeProfile: Employee | null;
  permissions: string[];
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// A definitive list of all permissions available in the app.
const allPermissions = [
  'dashboard:view',
  'profile:view_own',
  'leave:apply',
  'employees:view',
  'employees:manage',
  'profile:view_all',
  'calendar:view',
  'attendance:manage',
  'leave:approve_all',
  'leave:manage_history',
  'payroll:view_history',
  'payroll:run',
  'payroll:configure',
  'roles:manage',
  'reports:view',
  'documents:view',
  'helpdesk:view',
  'financials:manage',
  'announcements:manage', 
];

const userPermissions = [
  'dashboard:view',
  'profile:view_own',
  'leave:apply',
  'calendar:view',
  'payroll:view_history',
  'documents:view',
  'attendance:manage', // Allow user to see the attendance page
  'helpdesk:view', // Allow user to see their own tickets
];


export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [employeeProfile, setEmployeeProfile] = useState<Employee | null>(null);
  const [permissions, setPermissions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    let profileUnsubscribe: (() => void) | null = null;

    const authUnsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      // Clean up previous profile listener if it exists
      if (profileUnsubscribe) {
        profileUnsubscribe();
        profileUnsubscribe = null;
      }
      
      setUser(currentUser);
      
      if (currentUser) {
        try {
          const employeeDocRef = doc(db, 'employees', currentUser.uid);
          
          // Set up a real-time listener for the employee profile
          profileUnsubscribe = onSnapshot(employeeDocRef, async (employeeDocSnap) => {
            if (employeeDocSnap.exists()) {
              const employeeData = employeeDocSnap.data() as Employee;
              
              // Check for password reset flag
              if (employeeData.passwordResetInitiated) {
                // Clear the flag in Firestore
                await updateDoc(employeeDocRef, { passwordResetInitiated: null });

                // Log the user out
                await signOut(auth);

                // Show a toast message
                toast({
                  title: "Security Alert",
                  description: "A password reset was initiated for your account. You have been logged out.",
                  variant: "destructive",
                  duration: 7000,
                });

                router.push('/login');
                return; // Stop further processing
              }

              setEmployeeProfile({ id: employeeDocSnap.id, ...employeeData });
              
              if (employeeData.permissionRole === 'Administrator') {
                setPermissions(allPermissions);
              } else {
                setPermissions(userPermissions);
              }
            } else {
              // This handles the bootstrap case for the admin account
              const isHardcodedAdminEmail = currentUser.email === 'admin@gmail.com';
              if (isHardcodedAdminEmail) {
                const adminProfile: Omit<Employee, 'id'> = {
                  name: 'Admin',
                  employeeId: 'ADMIN',
                  department: 'System',
                  role: 'Administrator',
                  status: 'Active',
                  email: currentUser.email,
                  permissionRole: 'Administrator',
                  joinDate: new Date().toISOString().split('T')[0],
                };
                await setDoc(employeeDocRef, adminProfile);
                // The listener will automatically pick up the new data, so no need to set state here.
              } else {
                 setEmployeeProfile(null);
                 setPermissions([]);
              }
            }
            setLoading(false); // Set loading to false once profile is processed
          }, (error) => {
             console.error("Error with profile snapshot:", error);
             setEmployeeProfile(null);
             setPermissions([]);
             setLoading(false);
          });

        } catch (error) {
          console.error("Error setting up user profile listener:", error);
          setEmployeeProfile(null);
          setPermissions([]);
          setLoading(false);
        }
      } else {
        // User is logged out
        setEmployeeProfile(null);
        setPermissions([]);
        setLoading(false);
      }
    });

    return () => {
      authUnsubscribe();
      if (profileUnsubscribe) {
        profileUnsubscribe();
      }
    };
  }, [toast, router]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="space-y-4 w-1/2">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, employeeProfile, permissions, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
