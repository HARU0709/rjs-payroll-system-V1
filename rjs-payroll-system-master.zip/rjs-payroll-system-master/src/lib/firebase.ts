
import { initializeApp, getApps, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

// Vercel environment variables are automatically available in the build process
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
};

// Fallback configuration for local development or if environment variables are not set
const firebaseConfigFallback = {
  apiKey: "AIzaSyCoWruZ2JxTaEx2QALGdfhE0M_hOfyXfjU",
  authDomain: "rjspayrollsystem.firebaseapp.com",
  projectId: "rjspayrollsystem",
  storageBucket: "rjspayrollsystem.appspot.com",
  messagingSenderId: "683297492751",
  appId: "1:683297492751:web:58ef3773bfffb28a1e787a",
  measurementId: "G-2RKH2K7R3D"
};

// Determine which config to use
export const effectiveFirebaseConfig = firebaseConfig.apiKey ? firebaseConfig : firebaseConfigFallback;

let app: FirebaseApp;
let auth: Auth;
let db: Firestore;

// Initialize Firebase safely
if (!getApps().length) {
  try {
    app = initializeApp(effectiveFirebaseConfig);
  } catch(e) {
      console.error("CRITICAL: Firebase initialization failed", e);
      // Provide dummy objects to prevent further crashes on the server.
      app = {} as FirebaseApp;
      auth = {} as Auth;
      db = {} as Firestore;
  }
} else {
  app = getApps()[0];
}

// Initialize other services after the app is guaranteed to be initialized
// These calls are safe on the server
try {
  auth = getAuth(app);
  db = getFirestore(app);
} catch(e) {
    console.error("CRITICAL: Failed to initialize Firebase Auth or Firestore", e);
    // Provide dummy objects to prevent further crashes.
    auth = {} as Auth;
    db = {} as Firestore;
}


// This console.log is for debugging and can be removed in production
if (typeof window !== 'undefined') {
  if (effectiveFirebaseConfig.apiKey === firebaseConfigFallback.apiKey) {
    console.log("Firebase initialized with fallback configuration on the client.");
  } else {
    console.log("Firebase initialized with environment variables on the client.");
  }
}

export { app, auth, db };
