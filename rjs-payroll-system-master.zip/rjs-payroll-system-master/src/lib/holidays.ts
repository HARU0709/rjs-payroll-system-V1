
// This file is deprecated. All holidays are now managed dynamically in the database via the /holidays page.
// It is kept for reference but is no longer actively used by the application.
// You can use the "Add Holiday" feature on the holidays page to add both national and company-specific holidays.

export interface StaticHoliday {
  name: string;
  month: number; // 0-11 (Jan-Dec)
  day: number;
}

export const staticHolidays: StaticHoliday[] = [];

export const getStaticHolidaysForYear = (year: number) => {
  return [];
};
