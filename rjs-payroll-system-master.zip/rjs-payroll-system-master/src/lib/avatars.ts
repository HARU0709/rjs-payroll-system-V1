// A curated list of avatar URLs hosted on ibb.co
// This is a simple array of URLs for a streamlined avatar selection process.

export const avatarLibrary: string[] = [
  'https://i.ibb.co/VYWP8DMM/27470335-7309683-1.jpg',
  'https://i.ibb.co/WN3kSXY9/27470334-7309681.jpg',
  'https://i.ibb.co/XvL2szq/27470347-7309691-1.jpg',
  'https://i.ibb.co/WW62TXYL/27470362-7309673-1.jpg',
  'https://i.ibb.co/XrdH068M/27470346-7294811-1.jpg',
  'https://i.ibb.co/0RL3ZF3v/27470336-7294793-1.jpg',
  'https://i.ibb.co/RpFJn8yX/117182-1.jpg',
  'https://i.ibb.co/WWYm7Vw1/8843421.jpg',
  'https://i.ibb.co/9kQXThXN/8843427.jpg',
  'https://i.ibb.co/CTr36bs/30875850-7748151.jpg',
  'https://i.ibb.co/8gqxD0xC/30875853-7748166.jpg',
  'https://i.ibb.co/wFg12Sqk/30875855-7748184.jpg',
  'https://i.ibb.co/Ld26511b/30875858-7742204.jpg',
  'https://i.ibb.co/2Y3wsJVz/30875863-7742248.jpg',
  'https://i.ibb.co/QFXQfX31/30875866-7742218.jpg',
  'https://i.ibb.co/cSNzmMFj/172780851-9994823.jpg',
  'https://i.ibb.co/fGMswJJ4/172780852-9994831.jpg',
  'https://i.ibb.co/4HRnz2P/172780862-9994850.jpg'
];
