import type { Employee, LeaveRequest, Role, AttendanceEvent, Payslip, NotificationItem } from '@/types';

export const mockEmployees: Employee[] = [
  { id: '1', name: 'Alice Wonderland', employeeId: 'EMP001', department: 'Engineering', role: 'Software Engineer', status: 'Active', email: 'alice@paycentral.com', phone: '555-0101', avatarUrl: 'https://placehold.co/100x100.png?text=AW', joinDate: '2022-01-15', address: '123 Fairy Lane, Storybook City', dateOfBirth: '1990-05-20', salary: 80000 },
  { id: '2', name: 'Bob The Builder', employeeId: 'EMP002', department: 'Operations', role: 'Project Manager', status: 'Active', email: 'bob@paycentral.com', phone: '555-0102', avatarUrl: 'https://placehold.co/100x100.png?text=BB', joinDate: '2021-07-01', address: '456 Construction Rd, Tool Town', dateOfBirth: '1985-11-10', salary: 95000 },
  { id: '3', name: 'Charlie Chaplin', employeeId: 'EMP003', department: 'Marketing', role: 'Marketing Specialist', status: 'On Leave', email: 'charlie@paycentral.com', phone: '555-0103', avatarUrl: 'https://placehold.co/100x100.png?text=CC', joinDate: '2023-03-10', address: '789 Comedy Ave, Silent Film Era', dateOfBirth: '1988-04-16', salary: 70000 },
  { id: '4', name: 'Diana Prince', employeeId: 'EMP004', department: 'HR', role: 'HR Manager', status: 'Active', email: 'diana@paycentral.com', phone: '555-0104', avatarUrl: 'https://placehold.co/100x100.png?text=DP', joinDate: '2020-11-20', address: '1 Paradise Island, Themyscira', dateOfBirth: '1980-03-01', salary: 100000 },
  { id: '5', name: 'Edward Scissorhands', employeeId: 'EMP005', department: 'Creative', role: 'Graphic Designer', status: 'Inactive', email: 'edward@paycentral.com', phone: '555-0105', avatarUrl: 'https://placehold.co/100x100.png?text=ES', joinDate: '2022-09-01', address: '1 Gothic Mansion, Suburbia', dateOfBirth: '1992-12-25', salary: 65000 },
];

export const mockLeaveRequests: LeaveRequest[] = [
  { id: 'lr1', employeeId: '3', employeeName: 'Charlie Chaplin', leaveType: 'Annual', startDate: '2024-07-10', endDate: '2024-07-15', reason: 'Vacation', status: 'Approved', appliedDate: '2024-06-20' },
  { id: 'lr2', employeeId: '1', employeeName: 'Alice Wonderland', leaveType: 'Sick', startDate: '2024-08-01', endDate: '2024-08-02', reason: 'Flu', status: 'Pending', appliedDate: '2024-07-28' },
  { id: 'lr3', employeeId: '2', employeeName: 'Bob The Builder', leaveType: 'Paternity', startDate: '2024-09-01', endDate: '2024-09-15', reason: 'New child', status: 'Pending', appliedDate: '2024-07-15' },
  { id: 'lr4', employeeId: '4', employeeName: 'Diana Prince', leaveType: 'Annual', startDate: '2024-07-20', endDate: '2024-07-22', reason: 'Personal time', status: 'Rejected', appliedDate: '2024-07-01', approverComment: 'Operational needs' },
];

export const mockRoles: Role[] = [
  { id: 'role1', name: 'Administrator', description: 'Full access to all system features.', permissions: ['manage_users', 'manage_payroll', 'approve_leave', 'view_reports', 'manage_roles'] },
  { id: 'role2', name: 'HR Manager', description: 'Manages employee data, leave, and recruitment.', permissions: ['manage_users', 'approve_leave', 'view_reports_hr'] },
  { id: 'role3', name: 'Employee', description: 'Standard employee access.', permissions: ['view_profile', 'apply_leave', 'view_payslips'] },
  { id: 'role4', name: 'Team Lead', description: 'Manages a team, can approve leave for team members.', permissions: ['view_profile', 'apply_leave', 'view_payslips', 'approve_team_leave'] },
];

export const mockAttendanceEvents: AttendanceEvent[] = [
  { date: new Date(2024, 6, 1), status: 'Present', employeeId: '1', title: 'Alice - Present' }, // July is month 6
  { date: new Date(2024, 6, 1), status: 'Holiday', title: 'Canada Day' },
  { date: new Date(2024, 6, 2), status: 'Leave', employeeId: '3', title: 'Charlie - Annual Leave' },
  { date: new Date(2024, 6, 3), status: 'Absent', employeeId: '2', title: 'Bob - Absent' },
  { date: new Date(2024, 6, 6), status: 'Weekend' },
  { date: new Date(2024, 6, 7), status: 'Weekend' },
];

export const mockPayslips: Payslip[] = [
    { id: 'ps1', employeeId: '1', month: 'June', year: 2024, grossSalary: 6666.67, deductions: 1500, netSalary: 5166.67, issueDate: '2024-06-30' },
    { id: 'ps2', employeeId: '1', month: 'May', year: 2024, grossSalary: 6666.67, deductions: 1500, netSalary: 5166.67, issueDate: '2024-05-31' },
    { id: 'ps3', employeeId: '2', month: 'June', year: 2024, grossSalary: 7916.67, deductions: 1800, netSalary: 6116.67, issueDate: '2024-06-30' },
];

export const mockNotifications: NotificationItem[] = [
  { id: '1', type: 'success', text: 'Payroll for June 2024 has been successfully processed.', timestamp: '14:30', isRead: false },
  { id: '2', type: 'warning', text: 'Alice Wonderland\'s leave request for July 10-15 needs approval.', timestamp: '11:15', isRead: false },
  { id: '3', type: 'info', text: 'System maintenance is scheduled for tonight at 11:00 PM.', timestamp: '09:00', isRead: true },
  { id: '4', type: 'warning', text: 'Bob The Builder has an incomplete timesheet for last week.', timestamp: '08:45', isRead: false },
];
