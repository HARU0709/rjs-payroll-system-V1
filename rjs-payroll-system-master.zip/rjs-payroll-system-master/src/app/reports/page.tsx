
'use client';

import { useState, useMemo, useEffect } from 'react';
import { PageHeader } from '@/components/shared/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DatePicker } from '@/components/ui/date-picker';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent, type ChartConfig } from '@/components/ui/chart';
import { useAuth } from '@/contexts/auth-context';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, where, orderBy, doc, getDoc } from 'firebase/firestore';
import type { Payslip, LeaveRequest, Employee, AttendanceRecord, AttendanceSettings } from '@/types';
import { format, parse, startOfMonth, endOfMonth, eachDayOfInterval, isWeekend, isWithinInterval } from 'date-fns';
import type { DateRange } from 'react-day-picker';
import { Loader2, TrendingUp, Download, AlertTriangle, UserX, Clock, DollarSign, Plane, Users, TrendingDown, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

// Helper function to convert array of objects to CSV string
function convertToCSV(data: Array<Record<string, any>>, headers: Record<string, string>): string {
  const headerRow = Object.values(headers).join(',');
  const dataRows = data.map(row => {
    return Object.keys(headers).map(key => {
      let cellValue = row[key] === undefined || row[key] === null ? '' : String(row[key]);
      if (cellValue.includes(',') || cellValue.includes('\n') || cellValue.includes('"')) {
        cellValue = `"${cellValue.replace(/"/g, '""')}"`;
      }
      return cellValue;
    }).join(',');
  });
  return [headerRow, ...dataRows].join('\n');
}

// Helper to trigger download
function downloadCSV(csvString: string, filename: string) {
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

const formatCurrency = (amount: number) => new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount);

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const payrollChartConfig = {
  grossPay: {
    label: "Gross Pay",
    color: "hsl(var(--chart-2))",
  },
  netPay: {
    label: "Net Pay",
    color: "hsl(var(--chart-1))",
  },
} satisfies ChartConfig;

const leaveChartConfig = {
  value: {
    label: "Leaves",
  },
  Annual: {
    label: "Annual",
    color: "hsl(var(--chart-1))",
  },
  Sick: {
    label: "Sick",
    color: "hsl(var(--chart-2))",
  },
  Unpaid: {
    label: "Unpaid",
    color: "hsl(var(--chart-3))",
  },
  Maternity: {
    label: "Maternity",
    color: "hsl(var(--chart-4))",
  },
   Paternity: {
    label: "Paternity",
    color: "hsl(var(--chart-5))",
  },
  Personal: {
    label: "Personal",
    color: "hsl(var(--chart-1))",
  },
} satisfies ChartConfig

export default function ReportsPage() {
  const { employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState('payroll');
  const [loading, setLoading] = useState(true);

  // Data states
  const [allPayslips, setAllPayslips] = useState<Payslip[]>([]);
  const [allLeaves, setAllLeaves] = useState<LeaveRequest[]>([]);
  const [allEmployees, setAllEmployees] = useState<Employee[]>([]);
  const [allAttendance, setAllAttendance] = useState<AttendanceRecord[]>([]);
  const [attendanceSettings, setAttendanceSettings] = useState<AttendanceSettings | null>(null);

  // Filter states
  const [payrollMonthFilter, setPayrollMonthFilter] = useState(format(new Date(), 'yyyy-MM'));
  const [leaveDateFilter, setLeaveDateFilter] = useState<DateRange | undefined>({
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date()),
  });
   const [attendanceDateFilter, setAttendanceDateFilter] = useState<DateRange | undefined>({
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date()),
  });

  const getStatusBadgeComponent = (status: LeaveRequest['status']) => {
    switch (status) {
      case 'Approved':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-700/30 dark:text-green-300 hover:bg-green-200/80">Approved</Badge>;
      case 'Pending':
        return <Badge variant="secondary">Pending</Badge>;
      case 'Rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getStatusBadgeComponentForEmployee = (status: Employee['status']) => {
    switch (status) {
      case 'Active':
        return <Badge variant="default">Active</Badge>;
      case 'On Leave':
        return <Badge variant="secondary">On Leave</Badge>;
      case 'Inactive':
        return <Badge variant="destructive">Inactive</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  useEffect(() => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      setLoading(true);
      try {
        const payslipsPromise = getDocs(query(collection(db, 'payslips'), orderBy('runDate', 'desc')));
        const leavesPromise = getDocs(query(collection(db, 'leaveRequests'), orderBy('appliedDate', 'desc')));
        const employeesPromise = getDocs(query(collection(db, 'employees'), orderBy('name')));
        const attendancePromise = getDocs(query(collection(db, 'attendanceRecords')));
        const settingsPromise = getDoc(doc(db, 'companySettings', 'attendance'));

        const [payslipsSnap, leavesSnap, employeesSnap, attendanceSnap, settingsSnap] = await Promise.all([
          payslipsPromise,
          leavesPromise,
          employeesPromise,
          attendancePromise,
          settingsPromise,
        ]);

        setAllPayslips(payslipsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Payslip)));
        setAllLeaves(leavesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as LeaveRequest)));
        setAllEmployees(employeesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee)).filter(e => e.employeeId !== 'ADMIN'));
        setAllAttendance(attendanceSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as AttendanceRecord)));
        
        if (settingsSnap.exists()) {
          setAttendanceSettings(settingsSnap.data() as AttendanceSettings);
        } else {
          setAttendanceSettings({ 
            expectedMorningIn: '08:00', lateGracePeriod: 15, requiredWorkHours: 8,
            expectedLunchOut: '12:00', expectedLunchIn: '13:00', expectedAfternoonOut: '17:00', earlyLeaveThreshold: 15 
          });
          toast({ title: "Default Settings Used", description: "Attendance settings not found. Using default values for report calculation.", variant: 'warning' });
        }

      } catch (error) {
        console.error("Error fetching report data:", error);
        toast({ title: "Error", description: "Could not fetch report data.", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [isAdmin, toast]);

  const filteredPayrollData = useMemo(() => {
    const [year, month] = payrollMonthFilter.split('-');
    const monthName = format(new Date(parseInt(year), parseInt(month) - 1), 'MMMM');
    return allPayslips.filter(p => p.payrollMonth === monthName && p.payrollYear === parseInt(year));
  }, [allPayslips, payrollMonthFilter]);

  const payrollSummary = useMemo(() => {
    return filteredPayrollData.reduce((acc, slip) => {
      acc.totalGross += slip.grossPay;
      acc.totalDeductions += slip.totalDeductions;
      acc.totalNet += slip.netPay;
      return acc;
    }, { totalGross: 0, totalDeductions: 0, totalNet: 0 });
  }, [filteredPayrollData]);

  const filteredLeaveData = useMemo(() => {
    if (!leaveDateFilter?.from) return [];
    const fromDate = leaveDateFilter.from;
    const toDate = leaveDateFilter.to || fromDate;
    return allLeaves.filter(leave => {
      try {
        const leaveStart = parse(leave.startDate, 'yyyy-MM-dd', new Date());
        return leaveStart >= fromDate && leaveStart <= toDate;
      } catch (e) { return false; }
    });
  }, [allLeaves, leaveDateFilter]);
  
  const leaveTypeSummary = useMemo(() => {
    const summary = filteredLeaveData.reduce((acc, leave) => {
      acc[leave.leaveType] = (acc[leave.leaveType] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    return Object.entries(summary).map(([name, value]) => ({ name, value }));
  }, [filteredLeaveData]);

  const timeToMinutes = (timeStr: string | null | undefined): number => {
    if (!timeStr || !/^\d{2}:\d{2}$/.test(timeStr)) return Infinity;
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const filteredAttendanceData = useMemo(() => {
    const report: { lates: { employeeName: string; date: string; timeIn: string; lateByMinutes: number }[], absences: { employeeName: string; date: string }[] } = { lates: [], absences: [] };
    if (!attendanceDateFilter?.from || !allEmployees.length || !attendanceSettings) {
      return report;
    }

    const fromDate = attendanceDateFilter.from;
    const toDate = attendanceDateFilter.to || fromDate;
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Normalize to start of day for comparison

    const expectedTimeInMinutes = timeToMinutes(attendanceSettings.expectedMorningIn) + attendanceSettings.lateGracePeriod;

    const dateRange = eachDayOfInterval({ start: fromDate, end: toDate });

    for (const day of dateRange) {
        // Skip future dates and weekends
        if (day > today || isWeekend(day)) continue;
        
        const dateString = format(day, 'yyyy-MM-dd');

        for (const employee of allEmployees.filter(e => e.status === 'Active')) {
            const isOnLeave = allLeaves.some(leave => {
                try {
                    return leave.employeeId === employee.id &&
                    leave.status === 'Approved' &&
                    isWithinInterval(day, {
                        start: parse(leave.startDate, 'yyyy-MM-dd', new Date()),
                        end: parse(leave.endDate, 'yyyy-MM-dd', new Date())
                    });
                } catch(e) { return false; }
            });

            if (isOnLeave) continue;

            const attendanceRecord = allAttendance.find(
                record => record.employeeId === employee.id && record.date === dateString
            );
            
            if (!attendanceRecord || !attendanceRecord.morningIn) {
                report.absences.push({ employeeName: employee.name, date: dateString });
            } else {
                const clockInTimeMinutes = timeToMinutes(attendanceRecord.morningIn);
                if (clockInTimeMinutes > expectedTimeInMinutes) {
                    report.lates.push({
                        employeeName: employee.name,
                        date: dateString,
                        timeIn: attendanceRecord.morningIn,
                        lateByMinutes: clockInTimeMinutes - timeToMinutes(attendanceSettings.expectedMorningIn)
                    });
                }
            }
        }
    }
    return report;
  }, [allAttendance, allLeaves, allEmployees, attendanceSettings, attendanceDateFilter]);


  const handleExport = (reportType: 'payroll' | 'leave' | 'employee' | 'attendance') => {
    let csvData, filename, headers;
    const dateStr = format(new Date(), 'yyyyMMdd');

    switch (reportType) {
      case 'payroll':
        if(filteredPayrollData.length === 0) { toast({ title: "No Data", description: "No payroll data to export."}); return; }
        headers = { employeeName: 'Employee', payrollPeriod: 'Period', grossPay: 'Gross Pay', totalDeductions: 'Deductions', netPay: 'Net Pay' };
        csvData = convertToCSV(filteredPayrollData, headers);
        filename = `payroll_summary_${payrollMonthFilter}_${dateStr}.csv`;
        break;
      case 'leave':
        if(filteredLeaveData.length === 0) { toast({ title: "No Data", description: "No leave data to export."}); return; }
        headers = { employeeName: 'Employee', leaveType: 'Type', startDate: 'Start', endDate: 'End', status: 'Status' };
        csvData = convertToCSV(filteredLeaveData, headers);
        filename = `leave_report_${format(leaveDateFilter?.from || new Date(), 'yyyyMMdd')}-${format(leaveDateFilter?.to || new Date(), 'yyyyMMdd')}_${dateStr}.csv`;
        break;
      case 'employee':
        if(allEmployees.length === 0) { toast({ title: "No Data", description: "No employee data to export."}); return; }
        headers = { name: 'Name', employeeId: 'ID', email: 'Email', department: 'Department', role: 'Role', status: 'Status', joinDate: 'Join Date' };
        csvData = convertToCSV(allEmployees, headers);
        filename = `employee_directory_${dateStr}.csv`;
        break;
      case 'attendance':
        const latesForExport = filteredAttendanceData.lates.map(l => ({ employeeName: l.employeeName, date: l.date, type: 'Late', details: `In at ${l.timeIn} (${l.lateByMinutes}m late)` }));
        const absencesForExport = filteredAttendanceData.absences.map(a => ({ employeeName: a.employeeName, date: a.date, type: 'Absent', details: 'No record' }));
        const combinedData = [...latesForExport, ...absencesForExport];
        if(combinedData.length === 0) { toast({ title: "No Data", description: "No attendance data to export."}); return; }
        headers = { employeeName: 'Employee', date: 'Date', type: 'Type', details: 'Details' };
        csvData = convertToCSV(combinedData, headers);
        filename = `attendance_report_${format(attendanceDateFilter?.from || new Date(), 'yyyyMMdd')}-${format(attendanceDateFilter?.to || new Date(), 'yyyyMMdd')}_${dateStr}.csv`;
        break;
    }
    if (csvData && filename) {
        downloadCSV(csvData, filename);
        toast({ title: "Export Started", description: `Downloading ${filename}`, variant: 'success' });
    }
  };
  
  if (authLoading) return <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mt-10" />;
  
  if (!isAdmin) {
    return (
        <>
            <PageHeader
              icon={<TrendingUp className="h-7 w-7 text-primary" />}
              title="Reports & Analytics"
              description="Generate and view various HR and payroll reports." />
            <Card className="text-center p-8">
                <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
                <CardTitle>Access Denied</CardTitle>
                <CardDescription className="mt-2">You do not have permission to view this page. Please contact an administrator.</CardDescription>
            </Card>
        </>
    );
  }

  return (
    <>
      <PageHeader
        icon={<TrendingUp className="h-7 w-7 text-primary" />}
        title="Reports & Analytics"
        description="Generate and view various HR and payroll reports."
      />
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="payroll"><DollarSign className="h-4 w-4" />Payroll Report</TabsTrigger>
          <TabsTrigger value="leave"><Plane className="h-4 w-4" />Leave Report</TabsTrigger>
          <TabsTrigger value="attendance"><Clock className="h-4 w-4" />Attendance Report</TabsTrigger>
          <TabsTrigger value="employees"><Users className="h-4 w-4" />Employee Directory</TabsTrigger>
        </TabsList>

        <TabsContent value="payroll" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div>
                  <CardTitle>Payroll Summary</CardTitle>
                  <CardDescription>Review payroll data for a selected month.</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Input type="month" value={payrollMonthFilter} onChange={(e) => setPayrollMonthFilter(e.target.value)} className="w-auto"/>
                  <Button onClick={() => handleExport('payroll')} disabled={loading || filteredPayrollData.length === 0}><Download className="mr-2 h-4 w-4" /> Export CSV</Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mt-10" />
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                        <CardHeader>
                            <div className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardDescription>Total Gross Pay</CardDescription>
                                <TrendingUp className="h-4 w-4 text-muted-foreground" />
                            </div>
                            <CardTitle className="text-2xl font-bold">{formatCurrency(payrollSummary.totalGross)}</CardTitle>
                        </CardHeader>
                    </Card>
                    <Card>
                        <CardHeader>
                            <div className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardDescription>Total Deductions</CardDescription>
                                <TrendingDown className="h-4 w-4 text-destructive" />
                            </div>
                            <CardTitle className="text-2xl font-bold text-destructive">{formatCurrency(payrollSummary.totalDeductions)}</CardTitle>
                        </CardHeader>
                    </Card>
                    <Card>
                        <CardHeader>
                            <div className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardDescription>Total Net Pay</CardDescription>
                                <DollarSign className="h-4 w-4 text-primary" />
                            </div>
                            <CardTitle className="text-2xl font-bold text-primary">{formatCurrency(payrollSummary.totalNet)}</CardTitle>
                        </CardHeader>
                    </Card>
                  </div>
                  <Card>
                    <CardHeader><CardTitle>Payroll Breakdown</CardTitle></CardHeader>
                    <CardContent>
                       <ChartContainer config={payrollChartConfig} className="min-h-[250px] w-full">
                        <LineChart accessibilityLayer data={filteredPayrollData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                          <CartesianGrid vertical={false} />
                          <XAxis
                            dataKey="employeeName"
                            tickLine={false}
                            tickMargin={10}
                            axisLine={false}
                            angle={-15}
                            textAnchor="end"
                            height={50}
                            interval={0}
                            stroke="hsl(var(--foreground))"
                          />
                          <YAxis tickFormatter={(value) => `₱${Number(value) / 1000}k`} stroke="hsl(var(--foreground))" />
                          <ChartTooltip
                            cursor={true}
                            content={<ChartTooltipContent indicator="dot" formatter={(value) => formatCurrency(Number(value))} />}
                          />
                          <ChartLegend content={<ChartLegendContent />} />
                          <Line type="monotone" dataKey="grossPay" stroke="var(--color-grossPay)" strokeWidth={2} activeDot={{ r: 8 }} />
                          <Line type="monotone" dataKey="netPay" stroke="var(--color-netPay)" strokeWidth={2} activeDot={{ r: 8 }} />
                        </LineChart>
                      </ChartContainer>
                    </CardContent>
                  </Card>
                  <Table>
                    <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Period</TableHead><TableHead className="text-right">Gross</TableHead><TableHead className="text-right">Deductions</TableHead><TableHead className="text-right">Net</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {filteredPayrollData.length > 0 ? filteredPayrollData.map(p => (
                        <TableRow key={p.id}>
                            <TableCell>{p.employeeName}</TableCell>
                            <TableCell>{p.payrollPeriod}</TableCell>
                            <TableCell className="text-right">{formatCurrency(p.grossPay)}</TableCell>
                            <TableCell className="text-right text-destructive">{formatCurrency(p.totalDeductions)}</TableCell>
                            <TableCell className={cn("text-right font-medium", p.netPay < 0 ? 'text-destructive' : 'text-primary')}>
                                {formatCurrency(p.netPay)}
                            </TableCell>
                        </TableRow>
                      )) : <TableRow><TableCell colSpan={5} className="text-center">No payroll data for this month.</TableCell></TableRow>}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="leave" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                  <div>
                    <CardTitle>Leave Analysis</CardTitle>
                    <CardDescription>Analyze leave trends over a selected period.</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <DatePicker mode="range" selected={leaveDateFilter} onSelect={setLeaveDateFilter} buttonClassName="w-auto" />
                    <Button onClick={() => handleExport('leave')} disabled={loading || filteredLeaveData.length === 0}><Download className="mr-2 h-4 w-4" /> Export CSV</Button>
                  </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mt-10" /> : (
                <div className="space-y-6">
                  <Card>
                    <CardHeader><CardTitle>Leave Types Distribution</CardTitle></CardHeader>
                    <CardContent>
                      <ChartContainer config={leaveChartConfig} className="mx-auto aspect-square max-h-[300px]">
                          <PieChart>
                              <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                              <Pie data={leaveTypeSummary} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                                  {leaveTypeSummary.map((entry) => <Cell key={`cell-${entry.name}`} fill={`var(--color-${entry.name})`} />)}
                              </Pie>
                              <ChartLegend content={<ChartLegendContent nameKey="name" />} />
                          </PieChart>
                      </ChartContainer>
                    </CardContent>
                  </Card>
                  <Table>
                    <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Type</TableHead><TableHead>Start Date</TableHead><TableHead>End Date</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {filteredLeaveData.length > 0 ? filteredLeaveData.map(l => (
                        <TableRow key={l.id}>
                          <TableCell>{l.employeeName}</TableCell>
                          <TableCell>{l.leaveType}</TableCell>
                          <TableCell>{l.startDate}</TableCell>
                          <TableCell>{l.endDate}</TableCell>
                          <TableCell>{getStatusBadgeComponent(l.status)}</TableCell>
                        </TableRow>
                      )) : <TableRow><TableCell colSpan={5} className="text-center">No leave data for this period.</TableCell></TableRow>}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div>
                  <CardTitle>Attendance Report</CardTitle>
                  <CardDescription>Review employee lates and absences for a selected period.</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <DatePicker mode="range" selected={attendanceDateFilter} onSelect={setAttendanceDateFilter} buttonClassName="w-auto" />
                  <Button onClick={() => handleExport('attendance')} disabled={loading || (filteredAttendanceData.lates.length === 0 && filteredAttendanceData.absences.length === 0)}><Download className="mr-2 h-4 w-4" /> Export CSV</Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mt-10" /> : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-destructive">
                        <Clock className="mr-2 h-5 w-5" /> Late Clock-ins ({filteredAttendanceData.lates.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-72">
                        <Table>
                          <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Date</TableHead><TableHead className="text-right">Late By</TableHead></TableRow></TableHeader>
                          <TableBody>
                            {filteredAttendanceData.lates.length > 0 ? filteredAttendanceData.lates.map((l, i) => (
                              <TableRow key={`late-${i}`}><TableCell>{l.employeeName}</TableCell><TableCell>{l.date}</TableCell><TableCell className="text-right">{l.lateByMinutes} min</TableCell></TableRow>
                            )) : <TableRow><TableCell colSpan={3} className="text-center h-24">No late clock-ins for this period.</TableCell></TableRow>}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-muted-foreground">
                        <UserX className="mr-2 h-5 w-5" /> Absences ({filteredAttendanceData.absences.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-72">
                        <Table>
                          <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
                          <TableBody>
                            {filteredAttendanceData.absences.length > 0 ? filteredAttendanceData.absences.map((a, i) => (
                              <TableRow key={`absent-${i}`}><TableCell>{a.employeeName}</TableCell><TableCell>{a.date}</TableCell></TableRow>
                            )) : <TableRow><TableCell colSpan={2} className="text-center h-24">No absences for this period.</TableCell></TableRow>}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employees" className="mt-4">
          <Card>
            <CardHeader>
               <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div>
                  <CardTitle>Employee Directory Export</CardTitle>
                  <CardDescription>Export a full list of all employees in the system.</CardDescription>
                </div>
                <Button onClick={() => handleExport('employee')} disabled={loading || allEmployees.length === 0}><Download className="mr-2 h-4 w-4" /> Export CSV</Button>
              </div>
            </CardHeader>
            <CardContent>
               {loading ? <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mt-10" /> : (
                  <Table>
                    <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>ID</TableHead><TableHead>Email</TableHead><TableHead>Department</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {allEmployees.length > 0 ? allEmployees.map(e => (
                        <TableRow key={e.id}>
                          <TableCell>{e.name}</TableCell>
                          <TableCell>{e.employeeId}</TableCell>
                          <TableCell>{e.email}</TableCell>
                          <TableCell>{e.department}</TableCell>
                          <TableCell>{getStatusBadgeComponentForEmployee(e.status)}</TableCell>
                        </TableRow>
                      )) : <TableRow><TableCell colSpan={5} className="text-center">No employees found.</TableCell></TableRow>}
                    </TableBody>
                  </Table>
               )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
