

'use client';

import { useState, useEffect, type FormEvent } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { doc, getDoc, updateDoc, onSnapshot } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { useAuth } from '@/contexts/auth-context';
import type { Employee } from '@/types';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { AlertTriangle, ArrowLeft, Briefcase, Contact, DollarSign, Fingerprint, KeyRound, Mail, UserCircle, Loader2, Edit3, XCircle, Save, Home, Phone, Cake, Files, Eye, EyeOff, Check } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { sendPasswordResetEmail, EmailAuthProvider, reauthenticateWithCredential, updatePassword, signOut, updateEmail } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { avatarLibrary } from '@/lib/avatars';
import Image from 'next/image';

const getStatusBadgeComponent = (status: Employee['status']) => {
    switch (status) {
      case 'Active':
        return <Badge className="border-transparent bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300">Active</Badge>;
      case 'On Leave':
        return <Badge variant="secondary">On Leave</Badge>;
      case 'Inactive':
        return <Badge variant="destructive">Inactive</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
};

const formatCurrency = (amount: number | undefined | null) => {
    if (amount === undefined || amount === null) return 'Not Set';
    return new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount);
};


export default function EmployeeProfilePage() {
    const params = useParams();
    const router = useRouter();
    const { user, employeeProfile: loggedInEmployee, loading: authLoading } = useAuth();
    const { toast } = useToast();
    const employeeId = params.id as string;

    const [employee, setEmployee] = useState<Employee | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = useState(false);
    const [isSendingReset, setIsSendingReset] = useState(false);
    
    // New state for editing user/admin email
    const [isEditEmailDialogOpen, setIsEditEmailDialogOpen] = useState(false);
    const [newEmail, setNewEmail] = useState('');
    const [currentPasswordForEmail, setCurrentPasswordForEmail] = useState('');
    const [isUpdatingEmail, setIsUpdatingEmail] = useState(false);
    
    // State for Change Password Dialog
    const [isChangePasswordDialogOpen, setIsChangePasswordDialogOpen] = useState(false);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmNewPassword, setConfirmNewPassword] = useState('');
    const [isChangingPassword, setIsChangingPassword] = useState(false);
    const [showCurrentPassword, setShowCurrentPassword] = useState(false);
    const [showNewPassword, setShowNewPassword] = useState(false);
    const [passwordStrength, setPasswordStrength] = useState(0);

    // State for avatar selection
    const [isAvatarDialogOpen, setIsAvatarDialogOpen] = useState(false);
    const [selectedAvatarUrl, setSelectedAvatarUrl] = useState<string | undefined>(undefined);
    const [isUpdatingAvatar, setIsUpdatingAvatar] = useState(false);

    const isAdmin = loggedInEmployee?.permissionRole === 'Administrator';
    const isOwnProfile = user?.uid === employeeId;
    const canViewProfile = isAdmin || isOwnProfile;
    const canEditAvatar = isAdmin || isOwnProfile;
    
    useEffect(() => {
        if (authLoading) return;

        if (!canViewProfile) {
            setError("You don't have permission to view this profile.");
            setLoading(false);
            return;
        }

        if (employeeId) {
            setLoading(true);
            const employeeDocRef = doc(db, 'employees', employeeId);
            
            const unsubscribe = onSnapshot(employeeDocRef, (docSnap) => {
                if (docSnap.exists()) {
                    const data = { id: docSnap.id, ...docSnap.data() } as Employee;
                    setEmployee(data);
                    setSelectedAvatarUrl(data.avatarUrl); // Sync avatar state
                    setError(null);
                } else {
                    // Check if the current user is the admin viewing their own (virtual) profile
                    if (loggedInEmployee && loggedInEmployee.id === employeeId && loggedInEmployee.permissionRole === 'Administrator') {
                        setEmployee(loggedInEmployee);
                        setSelectedAvatarUrl(loggedInEmployee.avatarUrl);
                        setError(null);
                    } else {
                        setError('Employee not found.');
                        setEmployee(null);
                    }
                }
                setLoading(false);
            }, (err) => {
                console.error("Error fetching employee profile:", err);
                setError('Failed to fetch employee profile.');
                setLoading(false);
            });

            return () => unsubscribe(); // Cleanup the listener on unmount
        }
    }, [employeeId, authLoading, canViewProfile, loggedInEmployee]);
    
    const handleSendPasswordReset = async () => {
      if (!employee?.email) {
        toast({ title: "Error", description: "This account does not have a valid email address.", variant: "destructive" });
        return;
      }
      
      setIsSendingReset(true);
      try {
        await sendPasswordResetEmail(auth, employee.email);
        
        // After sending the email, update the employee document to trigger real-time logout.
        const employeeDocRef = doc(db, 'employees', employee.id);
        await updateDoc(employeeDocRef, {
            passwordResetInitiated: new Date(),
        });

        toast({
          title: "Success!",
          description: `Password reset email sent to ${employee.email}.`,
          variant: 'success',
          duration: 5000,
        });
        setIsResetPasswordDialogOpen(false);
      } catch (error: any) {
        console.error("Password reset error:", error);
        toast({ title: "Error", description: "Failed to send password reset email.", variant: "destructive" });
      } finally {
        setIsSendingReset(false);
      }
    };

    const handleUpdateEmail = async () => {
      if (!auth.currentUser || !newEmail || !currentPasswordForEmail) {
        toast({ title: "Error", description: "Please fill all fields.", variant: "destructive" });
        return;
      }

      if (newEmail.toLowerCase() === auth.currentUser.email?.toLowerCase()) {
        toast({ title: "Error", description: "You entered the same email address. Please provide a new email.", variant: "destructive" });
        return;
      }
      
      setIsUpdatingEmail(true);
      const user = auth.currentUser;

      try {
        const credential = EmailAuthProvider.credential(user.email!, currentPasswordForEmail);
        await reauthenticateWithCredential(user, credential);
        
        await updateEmail(user, newEmail);
        
        // Also update the email in the employee's Firestore document
        const employeeDocRef = doc(db, 'employees', user.uid);
        await updateDoc(employeeDocRef, { email: newEmail });

        toast({
          title: "Email Updated Successfully",
          description: `Your email has been changed to ${newEmail}. You will be logged out to complete the change. Please log in with your new email.`,
          variant: 'success',
          duration: 8000
        });

        setIsEditEmailDialogOpen(false);
        await signOut(auth);
        router.push('/login');

      } catch (error: any) {
        let description = "An unexpected error occurred. Please try again.";
        if (error.code === 'auth/invalid-credential' || error.code === 'auth/wrong-password') {
            description = "The password you entered is incorrect. Please try again.";
        } else if (error.code === 'auth/email-already-in-use') {
            description = "This email address is already in use by another account.";
        } else if (error.code === 'auth/requires-recent-login') {
            description = "This is a sensitive operation. Please log out and log back in before changing your email.";
        } else if (error.code === 'auth/invalid-email') {
            description = "The new email address is not valid.";
        }
        else {
            console.error("Email update error:", error);
        }
        toast({ title: "Update Failed", description, variant: "destructive" });
      } finally {
        setIsUpdatingEmail(false);
      }
    };

    const calculatePasswordStrength = (password: string) => {
        let score = 0;
        if (!password) {
            setPasswordStrength(0);
            return;
        }
        // Award points for length
        if (password.length >= 8) score += 25;
        // Award points for containing lowercase letters
        if (/[a-z]/.test(password)) score += 25;
        // Award points for containing uppercase letters
        if (/[A-Z]/.test(password)) score += 25;
        // Award points for containing numbers
        if (/\d/.test(password)) score += 25;
        // Optional: Award points for special characters
        // if (/[^A-Za-z0-9]/.test(password)) score += 20;

        setPasswordStrength(Math.min(100, score));
    };

    useEffect(() => {
        calculatePasswordStrength(newPassword);
    }, [newPassword]);
    
    const handleChangePassword = async (e: FormEvent) => {
      e.preventDefault();
      if (!user || !user.email) {
        toast({ title: "Error", description: "You must be logged in to change your password.", variant: "destructive" });
        return;
      }
      if (newPassword !== confirmNewPassword) {
        toast({ title: "Error", description: "New passwords do not match.", variant: "destructive" });
        return;
      }
      if (newPassword.length < 6) {
        toast({ title: "Error", description: "New password must be at least 6 characters long.", variant: "destructive" });
        return;
      }
      if (!currentPassword) {
          toast({ title: "Error", description: "Please enter your current password.", variant: "destructive" });
          return;
      }
      
      setIsChangingPassword(true);
      try {
        const credential = EmailAuthProvider.credential(user.email, currentPassword);
        await reauthenticateWithCredential(user, credential);
        await updatePassword(user, newPassword);

        toast({
          title: "Password Updated Successfully",
          description: "Your password has been changed. You will be logged out for security.",
          variant: "success",
          duration: 5000,
        });

        setIsChangePasswordDialogOpen(false);
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
        
        await signOut(auth);
        router.push('/login');

      } catch (error: any) {
        let description = "An unexpected error occurred.";
        if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
          description = "Incorrect current password. Please try again.";
        } else {
            console.error("Password Change Error:", error);
        }
        toast({ title: "Password Change Failed", description, variant: "destructive" });
      } finally {
        setIsChangingPassword(false);
      }
    };
    
    const handleSaveAvatar = async () => {
        if (!employee || !selectedAvatarUrl) return;
        setIsUpdatingAvatar(true);
        try {
            const employeeDocRef = doc(db, 'employees', employee.id);
            await updateDoc(employeeDocRef, { avatarUrl: selectedAvatarUrl });
            toast({ title: "Success", description: "Avatar updated successfully.", variant: 'success' });
            setIsAvatarDialogOpen(false);
        } catch (error) {
            console.error("Error updating avatar:", error);
            toast({ title: "Error", description: "Failed to update avatar.", variant: "destructive" });
        } finally {
            setIsUpdatingAvatar(false);
        }
    };


    if (loading || authLoading) {
        return (
            <>
                <PageHeader title="Loading Profile..." />
                <div className="space-y-6">
                    <Card><CardContent className="p-6"><Skeleton className="h-24 w-full" /></CardContent></Card>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                         <Card><CardContent className="p-6"><Skeleton className="h-32 w-full" /></CardContent></Card>
                         <Card><CardContent className="p-6"><Skeleton className="h-32 w-full" /></CardContent></Card>
                    </div>
                </div>
            </>
        );
    }
    
    if (error) {
         return (
             <Card className="mt-6">
                <CardHeader>
                    <CardTitle className="flex items-center text-destructive">
                        <AlertTriangle className="mr-2 h-5 w-5" /> Error
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p>{error}</p>
                    <Button onClick={() => router.back()} className="mt-4"><ArrowLeft className="mr-2 h-4 w-4" /> Go Back</Button>
                </CardContent>
             </Card>
        );
    }

    if (!employee) {
        return (
             <Card className="mt-6">
                <CardHeader>
                    <CardTitle className="flex items-center text-muted-foreground">
                        <AlertTriangle className="mr-2 h-5 w-5" /> Not Found
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p>The requested employee profile could not be found.</p>
                    <Button onClick={() => router.push('/employees')} className="mt-4"><ArrowLeft className="mr-2 h-4 w-4" /> Go to Directory</Button>
                </CardContent>
             </Card>
        );
    }
    
    const avatarFallback = (employee.name?.split(' ').length > 1
        ? `${employee.name.split(' ')[0][0]}${employee.name.split(' ')[employee.name.split(' ').length - 1][0]}`
        : employee.name?.substring(0, 2) || ''
    ).toUpperCase();
    
    // Special view for the virtual admin profile
    if (employee.employeeId === 'ADMIN') {
        return (
            <>
                <PageHeader
                    icon={<KeyRound className="h-7 w-7 text-primary" />}
                    title="Admin Account"
                    description="Manage your administrator account settings."
                    actions={
                        <Button onClick={() => router.back()}>
                            <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
                        </Button>
                    }
                />
                 <div className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center"><UserCircle className="mr-2 h-5 w-5 text-primary" /> Admin Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center gap-6">
                                <div className="relative group">
                                    <Avatar className="h-20 w-20">
                                        <AvatarImage src={employee.avatarUrl || `https://placehold.co/80x80.png?text=AD`} alt={employee.name} data-ai-hint="admin avatar"/>
                                        <AvatarFallback className="text-2xl">
                                            {avatarFallback}
                                        </AvatarFallback>
                                    </Avatar>
                                    <button
                                        onClick={() => {
                                            setSelectedAvatarUrl(employee.avatarUrl);
                                            setIsAvatarDialogOpen(true);
                                        }}
                                        className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                                        aria-label="Edit avatar"
                                    >
                                        <Edit3 className="h-6 w-6 text-white" />
                                    </button>
                                </div>
                                <div className="flex-grow">
                                    <p className="text-muted-foreground">Email / Username</p>
                                    <p className="font-medium text-lg">{employee.email}</p>
                                </div>
                                {isOwnProfile && (
                                    <Button variant="outline" size="sm" onClick={() => {
                                        setNewEmail(employee.email || '');
                                        setCurrentPasswordForEmail('');
                                        setIsEditEmailDialogOpen(true);
                                    }}><Edit3 className="mr-2 h-4 w-4"/>Edit</Button>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center"><KeyRound className="mr-2 h-5 w-5 text-primary" /> Security</CardTitle>
                            <CardDescription>
                                Manage your account security settings.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            {isOwnProfile && (
                                <Button onClick={() => setIsChangePasswordDialogOpen(true)}>
                                    <KeyRound className="mr-2 h-4 w-4" /> Change Password
                                </Button>
                            )}
                        </CardContent>
                    </Card>
                </div>

                <Dialog open={isEditEmailDialogOpen} onOpenChange={setIsEditEmailDialogOpen}>
                    <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                            <DialogTitle>Edit Admin Email/Username</DialogTitle>
                            <DialogDescription>
                                Enter your new email and current password. You will be logged out to complete the change.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-2">
                            <div>
                                <Label htmlFor="new-email">New Email</Label>
                                <Input id="new-email" type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} disabled={isUpdatingEmail} />
                            </div>
                            <div>
                                <Label htmlFor="current-password-for-email">Current Password</Label>
                                <Input id="current-password-for-email" type="password" value={currentPasswordForEmail} onChange={(e) => setCurrentPasswordForEmail(e.target.value)} disabled={isUpdatingEmail} />
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsEditEmailDialogOpen(false)} disabled={isUpdatingEmail}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button>
                            <Button onClick={handleUpdateEmail} disabled={isUpdatingEmail}>
                                {isUpdatingEmail ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4"/>}
                                Save Changes
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
                 <Dialog open={isChangePasswordDialogOpen} onOpenChange={setIsChangePasswordDialogOpen}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Change Your Password</DialogTitle>
                            <DialogDescription>
                                Enter your current password and a new password below. You will be logged out after a successful change.
                            </DialogDescription>
                        </DialogHeader>
                        <form onSubmit={handleChangePassword} className="space-y-4 py-2">
                            <div className="space-y-2">
                                <Label htmlFor="currentPasswordDlg">Current Password</Label>
                                <div className="relative">
                                    <Input id="currentPasswordDlg" type={showCurrentPassword ? 'text' : 'password'} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
                                    <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-[-50%]" onClick={() => setShowCurrentPassword((p) => !p)}>
                                        {showCurrentPassword ? <EyeOff /> : <Eye />}
                                    </Button>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="newPasswordDlg">New Password</Label>
                                <div className="relative">
                                    <Input id="newPasswordDlg" type={showNewPassword ? 'text' : 'password'} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
                                    <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-[-50%]" onClick={() => setShowNewPassword((p) => !p)}>
                                        {showNewPassword ? <EyeOff /> : <Eye />}
                                    </Button>
                                </div>
                                {newPassword && (
                                    <div className="mt-2">
                                        <Progress value={passwordStrength} className={cn(
                                            passwordStrength < 50 ? "bg-red-500" : passwordStrength < 75 ? "bg-yellow-500" : "bg-green-500"
                                        )} />
                                        <p className="text-xs mt-1 text-muted-foreground">
                                            {passwordStrength < 50 ? "Weak" : passwordStrength < 75 ? "Medium" : "Strong"}
                                        </p>
                                    </div>
                                )}
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="confirmNewPasswordDlg">Confirm New Password</Label>
                                <Input id="confirmNewPasswordDlg" type={showNewPassword ? 'text' : 'password'} value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} required />
                            </div>
                            <DialogFooter className="pt-2">
                                <Button type="button" variant="outline" onClick={() => setIsChangePasswordDialogOpen(false)} disabled={isChangingPassword}>
                                    <XCircle className="mr-2 h-4 w-4" />Cancel
                                </Button>
                                <Button type="submit" disabled={isChangingPassword}>
                                    {isChangingPassword ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                                    Change Password
                                </Button>
                            </DialogFooter>
                        </form>
                    </DialogContent>
                </Dialog>
                <Dialog open={isAvatarDialogOpen} onOpenChange={setIsAvatarDialogOpen}>
                  <DialogContent className="sm:max-w-xl">
                    <DialogHeader>
                      <DialogTitle>Select a New Avatar</DialogTitle>
                      <DialogDescription>
                        Choose a new profile picture from the library.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4 py-4 max-h-[50vh] overflow-y-auto">
                      {avatarLibrary.map((url) => (
                        <button
                          key={url}
                          className={cn(
                            "relative aspect-square rounded-full border-2 transition-all",
                            selectedAvatarUrl === url
                              ? "border-primary ring-2 ring-primary ring-offset-2"
                              : "border-transparent"
                          )}
                          onClick={() => setSelectedAvatarUrl(url)}
                        >
                          <Image
                            src={url}
                            alt="Avatar option"
                            width={100}
                            height={100}
                            className="rounded-full"
                          />
                          {selectedAvatarUrl === url && (
                            <div className="absolute inset-0 bg-primary/70 flex items-center justify-center rounded-full">
                              <Check className="h-8 w-8 text-primary-foreground" />
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => setIsAvatarDialogOpen(false)}
                        disabled={isUpdatingAvatar}
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                      <Button
                        onClick={handleSaveAvatar}
                        disabled={
                          isUpdatingAvatar || selectedAvatarUrl === employee.avatarUrl
                        }
                      >
                        {isUpdatingAvatar ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Avatar
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
            </>
        );
    }

    return (
        <>
            <PageHeader
                icon={<UserCircle className="h-7 w-7 text-primary" />}
                title="Employee Profile"
                description={`Viewing details for ${employee.name}.`}
                actions={
                    <Button onClick={() => router.back()}>
                        <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
                    </Button>
                }
            />

            <div className="space-y-6">
                <Card>
                    <CardContent className="p-6 flex flex-col sm:flex-row items-center gap-6">
                        <div className="relative group">
                            <Avatar className="h-24 w-24">
                                <AvatarImage src={employee.avatarUrl || `https://placehold.co/100x100.png?text=${avatarFallback}`} alt={employee.name} data-ai-hint="employee avatar"/>
                                <AvatarFallback className="text-3xl">
                                    {avatarFallback}
                                </AvatarFallback>
                            </Avatar>
                            {canEditAvatar && (
                                <button
                                    onClick={() => {
                                        setSelectedAvatarUrl(employee.avatarUrl);
                                        setIsAvatarDialogOpen(true);
                                    }}
                                    className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                    <Edit3 className="h-8 w-8 text-white" />
                                </button>
                            )}
                        </div>
                        <div className="space-y-1 text-center sm:text-left">
                            <h2 className="text-2xl font-bold">{employee.name}</h2>
                            <p className="text-muted-foreground">{employee.role}</p>
                            <div className="flex items-center gap-2 justify-center sm:justify-start pt-1">
                                {getStatusBadgeComponent(employee.status)}
                                {employee.permissionRole && (
                                    <Badge variant="secondary">{employee.permissionRole}</Badge>
                                )}
                            </div>
                        </div>
                        <div className="ml-auto flex flex-col sm:flex-row gap-2">
                            {isOwnProfile && (
                                <>
                                 <Button variant="outline" onClick={() => {
                                        setNewEmail(employee.email || '');
                                        setCurrentPasswordForEmail('');
                                        setIsEditEmailDialogOpen(true);
                                    }}>
                                        <Mail className="mr-2 h-4 w-4" /> Change Email
                                    </Button>
                                    <Button variant="outline" onClick={() => setIsChangePasswordDialogOpen(true)}>
                                        <KeyRound className="mr-2 h-4 w-4" /> Change Password
                                    </Button>
                                </>
                            )}
                            {isAdmin && !isOwnProfile && (
                                <Button variant="outline" className="ml-auto" onClick={() => setIsResetPasswordDialogOpen(true)}>
                                    <KeyRound className="mr-2 h-4 w-4" /> Reset Password
                                </Button>
                            )}
                        </div>
                    </CardContent>
                </Card>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary" /> Job Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Employee ID</span>
                                <span className="font-medium">{employee.employeeId}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Department</span>
                                <span className="font-medium">{employee.department}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Join Date</span>
                                <span className="font-medium">{employee.joinDate ? format(parseISO(employee.joinDate), 'MMMM d, yyyy') : 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Annual Leave Entitlement</span>
                                <span className="font-medium">{employee.annualLeaveEntitlement ?? 'N/A'} days</span>
                            </div>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center"><Contact className="mr-2 h-5 w-5 text-primary" /> Contact & Personal</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Email</span>
                                <span className="font-medium">{employee.email}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Phone</span>
                                <span className="font-medium">{employee.phone || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Address</span>
                                <span className="font-medium text-right">{employee.address || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Date of Birth</span>
                                <span className="font-medium">{employee.dateOfBirth ? format(parseISO(employee.dateOfBirth), 'MMMM d, yyyy') : 'N/A'}</span>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center"><DollarSign className="mr-2 h-5 w-5 text-primary" /> Salary Details</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Salary</span>
                                <span className="font-medium">{formatCurrency(employee.salary)}</span>
                            </div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center"><Files className="mr-2 h-5 w-5 text-primary" /> Financial & Government IDs</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Bank Account No.</span>
                                <span className="font-medium">{employee.bankAccount || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">SSS Number</span>
                                <span className="font-medium">{employee.sssNumber || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">PhilHealth Number</span>
                                <span className="font-medium">{employee.philhealthNumber || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Pag-IBIG Number</span>
                                <span className="font-medium">{employee.pagibigNumber || 'N/A'}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">TIN</span>
                                <span className="font-medium">{employee.tinNumber || 'N/A'}</span>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
             <AlertDialog open={isResetPasswordDialogOpen} onOpenChange={setIsResetPasswordDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Reset Password</AlertDialogTitle>
                        <AlertDialogDescription>
                            Are you sure you want to send a password reset email to <span className="font-semibold">{employee?.email}</span>? This will also log the user out of any active sessions.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel disabled={isSendingReset}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleSendPasswordReset} disabled={isSendingReset}>
                            {isSendingReset ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Mail className="mr-2 h-4 w-4" />}
                            {isSendingReset ? "Sending..." : "Send Email"}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <Dialog open={isEditEmailDialogOpen} onOpenChange={setIsEditEmailDialogOpen}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>Change Your Email Address</DialogTitle>
                        <DialogDescription>
                            Enter your new email and current password. You will be logged out to complete the change.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                        <div>
                            <Label htmlFor="change-email-new">New Email</Label>
                            <Input id="change-email-new" type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} disabled={isUpdatingEmail} />
                        </div>
                        <div>
                            <Label htmlFor="change-email-password">Current Password</Label>
                            <Input id="change-email-password" type="password" value={currentPasswordForEmail} onChange={(e) => setCurrentPasswordForEmail(e.target.value)} disabled={isUpdatingEmail} />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsEditEmailDialogOpen(false)} disabled={isUpdatingEmail}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button>
                        <Button onClick={handleUpdateEmail} disabled={isUpdatingEmail}>
                            {isUpdatingEmail ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4"/>}
                            Update Email
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={isChangePasswordDialogOpen} onOpenChange={setIsChangePasswordDialogOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Change Your Password</DialogTitle>
                        <DialogDescription>
                            Enter your current password and a new password below. You will be logged out after a successful change.
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleChangePassword} className="space-y-4 py-2">
                        <div className="space-y-2">
                            <Label htmlFor="currentPasswordDlg">Current Password</Label>
                            <div className="relative">
                                <Input id="currentPasswordDlg" type={showCurrentPassword ? 'text' : 'password'} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
                                <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-[-50%]" onClick={() => setShowCurrentPassword((p) => !p)}>
                                    {showCurrentPassword ? <EyeOff /> : <Eye />}
                                </Button>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="newPasswordDlg">New Password</Label>
                            <div className="relative">
                                <Input id="newPasswordDlg" type={showNewPassword ? 'text' : 'password'} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
                                <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-[-50%]" onClick={() => setShowNewPassword((p) => !p)}>
                                    {showNewPassword ? <EyeOff /> : <Eye />}
                                </Button>
                            </div>
                            {newPassword && (
                                <div className="mt-2">
                                    <Progress value={passwordStrength} className={cn(
                                        "h-2",
                                        passwordStrength < 50 ? "bg-red-500" : passwordStrength < 75 ? "bg-yellow-500" : "bg-green-500"
                                    )} />
                                    <p className={cn(
                                        "text-xs mt-1",
                                        passwordStrength < 50 ? "text-red-500" : passwordStrength < 75 ? "text-yellow-500" : "text-green-500"
                                    )}>
                                        {passwordStrength < 50 ? "Weak" : passwordStrength < 75 ? "Medium" : "Strong"}
                                    </p>
                                </div>
                            )}
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="confirmNewPasswordDlg">Confirm New Password</Label>
                            <Input id="confirmNewPasswordDlg" type={showNewPassword ? 'text' : 'password'} value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} required />
                        </div>
                        <DialogFooter className="pt-2">
                            <Button type="button" variant="outline" onClick={() => setIsChangePasswordDialogOpen(false)} disabled={isChangingPassword}>
                                <XCircle className="mr-2 h-4 w-4" />Cancel
                            </Button>
                            <Button type="submit" disabled={isChangingPassword}>
                                {isChangingPassword ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                                Change Password
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>

            <Dialog open={isAvatarDialogOpen} onOpenChange={setIsAvatarDialogOpen}>
              <DialogContent className="sm:max-w-xl">
                <DialogHeader>
                  <DialogTitle>Select a New Avatar</DialogTitle>
                  <DialogDescription>
                    Choose a new profile picture from the library.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4 py-4 max-h-[50vh] overflow-y-auto">
                  {avatarLibrary.map((url) => (
                    <button
                      key={url}
                      className={cn(
                        "relative aspect-square rounded-full border-2 transition-all",
                        selectedAvatarUrl === url
                          ? "border-primary ring-2 ring-primary ring-offset-2"
                          : "border-transparent"
                      )}
                      onClick={() => setSelectedAvatarUrl(url)}
                    >
                      <Image
                        src={url}
                        alt="Avatar option"
                        width={100}
                        height={100}
                        className="rounded-full"
                      />
                      {selectedAvatarUrl === url && (
                        <div className="absolute inset-0 bg-primary/70 flex items-center justify-center rounded-full">
                          <Check className="h-8 w-8 text-primary-foreground" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => setIsAvatarDialogOpen(false)}
                    disabled={isUpdatingAvatar}
                  >
                    <XCircle className="mr-2 h-4 w-4" />
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSaveAvatar}
                    disabled={
                      isUpdatingAvatar || selectedAvatarUrl === employee.avatarUrl
                    }
                  >
                    {isUpdatingAvatar ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="mr-2 h-4 w-4" />
                    )}
                    Save Avatar
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
        </>
    );
}
