
'use client';

import { redirect } from 'next/navigation';
import { useEffect } from 'react';

// This page is deprecated in favor of the new dialog-based "Add Employee" flow.
// It now simply redirects users back to the main employee directory.
export default function DeprecatedAddEmployeePage() {
  useEffect(() => {
    redirect('/employees');
  }, []);

  return null; // Render nothing while redirecting
}
