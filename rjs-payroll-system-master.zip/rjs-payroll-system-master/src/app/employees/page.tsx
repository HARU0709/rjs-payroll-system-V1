

'use client';

import { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, parseISO } from 'date-fns';
import Link from 'next/link';

import { PageHeader } from '@/components/shared/page-header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import type { Employee, Department, JobRole, Shift } from '@/types';
import { Search, Filter, Edit3, Trash2, MoreHorizontal, Loader2, PlusCircle, Save, XCircle, ArrowRight, ArrowLeft, SlidersHorizontal, Gift, FingerprintIcon, Home, ShieldAlert, Banknote, Eye, KeyRound, Briefcase, CalendarDays, Mail, RotateCcw, Users, EyeOff, UserX, Check } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { ScrollArea } from '@/components/ui/scroll-area';
import { DatePicker } from '@/components/ui/date-picker';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from "@/hooks/use-toast";
import { Label } from '@/components/ui/label';
import { db, auth } from '@/lib/firebase';
import { collection, addDoc, deleteDoc, doc, query, orderBy, onSnapshot, updateDoc, setDoc, writeBatch } from 'firebase/firestore';
import { createUserWithEmailAndPassword, sendPasswordResetEmail, getAuth } from 'firebase/auth';
import { useAuth } from '@/contexts/auth-context';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { initializeApp, deleteApp } from 'firebase/app';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { avatarLibrary } from '@/lib/avatars';

const numberPreprocess = (val: unknown) => (val === "" || val === undefined || val === null || Number.isNaN(parseFloat(String(val))) ? undefined : parseFloat(String(val)));


// Schema for the new employee form
const addEmployeeSchema = z.object({
  // Step 1
  name: z.string().min(2, "Full name must be at least 2 characters."),
  avatarUrl: z.string().optional(),
  employeeId: z.string().min(1, "Employee ID is required."),
  email: z.string().email("Please enter a valid email address."),
  password: z.string().min(6, "Password must be at least 6 characters."),
  confirmPassword: z.string(),
  department: z.string().min(1, "Department is required."),
  role: z.string().min(1, "Job Role is required."),
  permissionRole: z.enum(['Administrator', 'User']),
  joinDate: z.date({ required_error: "Join date is required." }),
  dateOfBirth: z.date().optional(),
  shiftId: z.string().optional(),

  // Step 2
  status: z.enum(['Active', 'On Leave', 'Inactive']).default('Active'),
  phone: z.string().optional(),
  address: z.string().optional(),
  salary: z.preprocess(
    numberPreprocess,
    z.number().positive({ message: "Salary must be a positive number." }).optional()
  ),
  annualLeaveEntitlement: z.preprocess(
    numberPreprocess,
    z.number().int().min(0, "Leave days must be a non-negative number.").optional()
  ),
  bankAccount: z.string().optional(),
  sssNumber: z.string().optional(),
  philhealthNumber: z.string().optional(),
  pagibigNumber: z.string().optional(),
  tinNumber: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});
type AddEmployeeFormValues = z.infer<typeof addEmployeeSchema>;

const editEmployeeSchema = z.object({
  name: z.string().min(2, { message: "Full name must be at least 2 characters." }),
  avatarUrl: z.string().optional(),
  employeeId: z.string(), // Read-only when editing
  email: z.string().email({ message: "Please enter a valid email address." }),
  department: z.string({ required_error: "Department is required." }).min(1, "Department is required."),
  role: z.string({ required_error: "Job Role is required." }).min(1, "Job Role is required."),
  permissionRole: z.enum(['Administrator', 'User']),
  joinDate: z.date({ required_error: "Join date is required." }),
  dateOfBirth: z.date().optional(),
  shiftId: z.string().optional(),
  status: z.enum(['Active', 'On Leave', 'Inactive']),
  phone: z.string().optional(),
  address: z.string().optional(),
  salary: z.preprocess(
    numberPreprocess,
    z.number().positive({ message: "Salary must be a positive number." }).optional()
  ),
  annualLeaveEntitlement: z.preprocess(
    numberPreprocess,
    z.number().int().min(0, "Leave days must be a non-negative number.").optional()
  ),
  bankAccount: z.string().optional(),
  sssNumber: z.string().optional(),
  philhealthNumber: z.string().optional(),
  pagibigNumber: z.string().optional(),
  tinNumber: z.string().optional(),
});
type EditEmployeeFormValues = z.infer<typeof editEmployeeSchema>;


const statuses: Employee['status'][] = ['Active', 'On Leave', 'Inactive'];



export default function EmployeesPage() {
  const { user, employeeProfile } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  const { toast } = useToast();
  const searchParams = useSearchParams();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // State for Add Employee Dialog
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isSubmittingAdd, setIsSubmittingAdd] = useState(false);
  const [addFormStep, setAddFormStep] = useState(1);
  const [showAddPassword, setShowAddPassword] = useState(false);
  const [addPasswordStrength, setAddPasswordStrength] = useState(0);
  
  // State for Edit Employee Dialog
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isSubmittingEdit, setIsSubmittingEdit] = useState(false);
  const [employeeToEdit, setEmployeeToEdit] = useState<Employee | null>(null);
  const [editFormStep, setEditFormStep] = useState(1);


  // Dialog states for soft deletion (marking for deletion)
  const [isSoftDeleteDialogOpen, setIsSoftDeleteDialogOpen] = useState(false);
  const [employeeToSoftDelete, setEmployeeToSoftDelete] = useState<Employee | null>(null);
  
  // Dialog state for password reset
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = useState(false);
  const [employeeForPasswordReset, setEmployeeForPasswordReset] = useState<Employee | null>(null);

  // State for Permanent Deletion (from user request)
  const [isPermanentDeleteDialogOpen, setIsPermanentDeleteDialogOpen] = useState(false);
  const [employeeToPermanentlyDelete, setEmployeeToPermanentlyDelete] = useState<Employee | null>(null);
  const [isCancelDeletionDialogOpen, setIsCancelDeletionDialogOpen] = useState(false);
  const [employeeToCancelDeletion, setEmployeeToCancelDeletion] = useState<Employee | null>(null);


  // State for Departments and Roles (needed for filters and forms)
  const [departments, setDepartments] = useState<Department[]>([]);
  const [jobRoles, setJobRoles] = useState<JobRole[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [isLoadingFields, setIsLoadingFields] = useState(true);

  // Dialog states for managing fields
  const [isManageFieldsDialogOpen, setIsManageFieldsDialogOpen] = useState(false);
  const [newDepartmentName, setNewDepartmentName] = useState('');
  const [newJobRoleName, setNewJobRoleName] = useState('');
  const [isSubmittingNewField, setIsSubmittingNewField] = useState(false);
  
  const [fieldToEdit, setFieldToEdit] = useState<{ id: string; name: string; type: 'department' | 'role' } | null>(null);
  const [editFieldName, setEditFieldName] = useState('');
  const [isSubmittingFieldEdit, setIsSubmittingFieldEdit] = useState(false);

  const [fieldToDelete, setFieldToDelete] = useState<{ id: string; name: string; type: 'department' | 'role' } | null>(null);
  const [isSubmittingFieldDelete, setIsSubmittingFieldDelete] = useState(false);
  
  const [isResetEmailDialogOpen, setIsResetEmailDialogOpen] = useState(false);
  const [employeeForResetEmail, setEmployeeForResetEmail] = useState<Employee | null>(null);

  // Avatar Selection State
  const [isAvatarDialogOpen, setIsAvatarDialogOpen] = useState(false);
  const [selectedAvatarUrl, setSelectedAvatarUrl] = useState('');
  const [currentFormType, setCurrentFormType] = useState<'add' | 'edit' | null>(null);
  
  const addForm = useForm<AddEmployeeFormValues>({
    resolver: zodResolver(addEmployeeSchema),
    defaultValues: {
      status: 'Active',
      name: '',
      employeeId: '',
      email: '',
      password: '',
      confirmPassword: '',
      permissionRole: 'User',
      phone: '',
      address: '',
      bankAccount: '',
      sssNumber: '',
      philhealthNumber: '',
      pagibigNumber: '',
      tinNumber: '',
      dateOfBirth: undefined,
      shiftId: 'default_shift',
      avatarUrl: '',
    },
  });
  
  const editForm = useForm<EditEmployeeFormValues>({
    resolver: zodResolver(editEmployeeSchema),
    defaultValues: {},
  });

  const calculatePasswordStrength = (password: string) => {
    let score = 0;
    if (!password) return 0;
    if (password.length >= 8) score += 25;
    if (/[a-z]/.test(password)) score += 25;
    if (/[A-Z]/.test(password)) score += 25;
    if (/\d/.test(password)) score += 25;
    return Math.min(100, score);
  };
  
  const addPasswordValue = addForm.watch('password');
  useEffect(() => {
    setAddPasswordStrength(calculatePasswordStrength(addPasswordValue));
  }, [addPasswordValue]);

  useEffect(() => {
    setIsLoading(true);
    const q = query(collection(db, "employees"), orderBy("name")); 
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedEmployees: Employee[] = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Employee));
      setEmployees(fetchedEmployees.filter(emp => emp.employeeId !== 'ADMIN'));
      setIsLoading(false);
    }, (err) => {
      console.error("Detailed error fetching employees:", err); 
      setError("Failed to load employees. Please try again.");
      toast({
        title: "Error",
        description: "Could not fetch employee data from the database.",
        variant: "destructive",
      });
      setIsLoading(false);
    });

    setIsLoadingFields(true);
    let deptsLoaded = false, rolesLoaded = false, shiftsLoaded = false;
    const checkAllLoaded = () => {
        if (deptsLoaded && rolesLoaded && shiftsLoaded) {
            setIsLoadingFields(false);
        }
    }

    const deptsQuery = query(collection(db, "departments"), orderBy("name"));
    const unsubDepartments = onSnapshot(deptsQuery, (snapshot) => {
      setDepartments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Department)));
      deptsLoaded = true;
      checkAllLoaded();
    }, (err) => { console.error("Error fetching departments:", err); toast({ title: "Error", description: "Could not fetch departments.", variant: "destructive" }); });

    const jobRolesQuery = query(collection(db, "jobRoles"), orderBy("name"));
    const unsubJobRoles = onSnapshot(jobRolesQuery, (snapshot) => {
      setJobRoles(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as JobRole)));
      rolesLoaded = true;
      checkAllLoaded();
    }, (err) => { console.error("Error fetching job roles:", err); toast({ title: "Error", description: "Could not fetch job roles.", variant: "destructive" }); });
    
    const settingsDocRef = doc(db, 'companySettings', 'attendance');
    const unsubShifts = onSnapshot(settingsDocRef, (docSnap) => {
      if (docSnap.exists() && docSnap.data().shifts) {
        setShifts(docSnap.data().shifts);
      } else {
        setShifts([]);
      }
      shiftsLoaded = true;
      checkAllLoaded();
    }, (err) => { console.error("Error fetching shifts:", err); toast({ title: "Error", description: "Could not fetch work shifts.", variant: "destructive" }); });


    return () => {
        unsubscribe();
        unsubDepartments();
        unsubJobRoles();
        unsubShifts();
    };
  }, [toast]);


  const allDepartmentsForFilter = useMemo(() => {
    if (isLoadingFields) return [{ value: 'all', label: 'All Departments' }];
    return [
      { value: 'all', label: 'All Departments' },
      ...departments.map(dept => ({ value: dept.name, label: dept.name }))
    ];
  }, [departments, isLoadingFields]);
  
  const employeeStatusesForFilter = ['all', 'Active', 'On Leave', 'Inactive'];

  const { filteredEmployees, pendingDeletions } = useMemo(() => {
    const pending: Employee[] = [];
    const filtered = employees.filter((employee) => {
      if (employee.deletionRequested) {
        pending.push(employee);
      }
      const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            employee.employeeId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            employee.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDepartment = departmentFilter === 'all' || employee.department === departmentFilter;
      const matchesStatus = statusFilter === 'all' || employee.status === statusFilter;
      return matchesSearch && matchesDepartment && matchesStatus;
    });
    return { filteredEmployees: filtered, pendingDeletions: pending };
  }, [employees, searchTerm, departmentFilter, statusFilter]);

  const getStatusBadgeComponent = (status: Employee['status']) => {
    switch (status) {
      case 'Active':
        return <Badge className="border-transparent bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300">Active</Badge>;
      case 'On Leave':
        return <Badge variant="secondary">On Leave</Badge>;
      case 'Inactive':
        return <Badge variant="destructive">Inactive</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const openSoftDeleteDialog = (employee: Employee) => {
    setEmployeeToSoftDelete(employee);
    setIsSoftDeleteDialogOpen(true);
  };

  const handleSoftDeleteConfirm = async () => {
    if (employeeToSoftDelete) {
      try {
        const employeeRef = doc(db, "employees", employeeToSoftDelete.id);
        await updateDoc(employeeRef, {
            status: 'Inactive',
            deletionRequested: true,
            deletionRequestTimestamp: new Date(),
        });

        toast({
          title: "Employee Marked for Deletion",
          description: `${employeeToSoftDelete.name} has been moved to the pending deletion queue.`,
          variant: 'success',
        });
      } catch (err) {
        console.error("Error marking employee for deletion: ", err);
        toast({
          title: "Error",
          description: "Failed to mark employee for deletion. Please try again.",
          variant: "destructive",
        });
      }
    }
    setIsSoftDeleteDialogOpen(false);
    setEmployeeToSoftDelete(null);
  };
  
  const handleNextStep = async () => {
    const fieldsToValidate: (keyof AddEmployeeFormValues)[] = ['name', 'employeeId', 'email', 'password', 'confirmPassword', 'department', 'role', 'joinDate', 'permissionRole', 'dateOfBirth'];
    const isValid = await addForm.trigger(fieldsToValidate);
    if (isValid) {
      setAddFormStep(2);
    }
  };

  async function onAddSubmit(data: AddEmployeeFormValues) {
    setIsSubmittingAdd(true);
    
    const tempAppName = `newUserApp-${Date.now()}`;
    const tempApp = initializeApp(auth.app.options, tempAppName);
    const tempAuth = getAuth(tempApp);

    try {
      const userCredential = await createUserWithEmailAndPassword(tempAuth, data.email, data.password);
      const newUserId = userCredential.user.uid;

      const { password, confirmPassword, ...firestoreData } = data;
      const newEmployeeData = {
        ...firestoreData,
        joinDate: format(data.joinDate, 'yyyy-MM-dd'),
        dateOfBirth: data.dateOfBirth ? format(data.dateOfBirth, 'yyyy-MM-dd') : null,
        phone: data.phone || null,
        address: data.address || null,
        salary: data.salary ?? null,
        annualLeaveEntitlement: data.annualLeaveEntitlement ?? null,
        bankAccount: data.bankAccount || null,
        sssNumber: data.sssNumber || null,
        philhealthNumber: data.philhealthNumber || null,
        pagibigNumber: data.pagibigNumber || null,
        tinNumber: data.tinNumber || null,
        shiftId: data.shiftId === 'default_shift' ? null : data.shiftId,
        avatarUrl: data.avatarUrl || "",
      };

      const employeeDocRef = doc(db, "employees", newUserId);
      await setDoc(employeeDocRef, newEmployeeData);

      const adminName = employeeProfile?.name || "Admin";
      const adminNameParts = adminName.split(' ');
      const adminInitials = (
          adminNameParts.length > 1
          ? `${adminNameParts[0][0]}${adminNameParts[adminNameParts.length - 1][0]}`
          : adminName.substring(0, 2)
      ).toUpperCase();

      await addDoc(collection(db, "activityFeedItems"), {
        text: `added a new employee.`,
        userId: user?.uid,
        userName: employeeProfile?.name || "Admin",
        userRole: employeeProfile?.permissionRole || "Administrator",
        avatarUrl: employeeProfile?.avatarUrl || "",
        avatarFallback: adminInitials,
        timestamp: new Date(),
        relatedEntityType: 'employee',
        relatedEntityId: newUserId,
        details: [
          { label: 'New Employee', value: data.name },
          { label: 'Role', value: data.role },
        ]
      });
      
      toast({
        title: "Employee Added",
        description: `${data.name} has been successfully added with a login account.`,
        variant: 'success',
      });
      setIsAddDialogOpen(false);
      addForm.reset();
      setAddFormStep(1);
    } catch (error: any) {
      if (error.code === 'auth/email-already-in-use') {
        toast({
          title: "Registration Failed",
          description: "This email address is already in use by another account.",
          variant: "destructive",
        });
      } else {
        console.error("Error adding employee:", error);
        toast({
          title: "Error",
          description: "An unexpected error occurred. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      if (tempApp) {
        await deleteApp(tempApp);
      }
      setIsSubmittingAdd(false);
    }
  }

  const openEditDialog = (employee: Employee) => {
    setEmployeeToEdit(employee);
    setEditFormStep(1);
    editForm.reset({
      name: employee.name,
      avatarUrl: employee.avatarUrl || '',
      employeeId: employee.employeeId,
      email: employee.email,
      department: employee.department,
      role: employee.role,
      permissionRole: employee.permissionRole === 'Administrator' ? 'Administrator' : 'User',
      joinDate: employee.joinDate ? parseISO(employee.joinDate) : new Date(),
      dateOfBirth: employee.dateOfBirth ? parseISO(employee.dateOfBirth) : undefined,
      shiftId: employee.shiftId || 'default_shift',
      status: employee.status,
      phone: employee.phone || '',
      address: employee.address || '',
      salary: employee.salary ?? undefined,
      annualLeaveEntitlement: employee.annualLeaveEntitlement ?? undefined,
      bankAccount: employee.bankAccount || '',
      sssNumber: employee.sssNumber || '',
      philhealthNumber: employee.philhealthNumber || '',
      pagibigNumber: employee.pagibigNumber || '',
      tinNumber: employee.tinNumber || '',
    });
    setIsEditDialogOpen(true);
  };

  const handleEditNextStep = async () => {
    const fieldsToValidate: (keyof EditEmployeeFormValues)[] = ['name', 'email', 'department', 'role', 'joinDate', 'permissionRole', 'dateOfBirth'];
    const isValid = await editForm.trigger(fieldsToValidate);
    if (isValid) {
      setEditFormStep(2);
    }
  };
  
  async function onEditSubmit(data: EditEmployeeFormValues) {
    if (!employeeToEdit) return;
    setIsSubmittingEdit(true);

    const updatePayload: Partial<Employee> = {
      name: data.name,
      avatarUrl: data.avatarUrl,
      email: data.email,
      department: data.department,
      role: data.role,
      permissionRole: data.permissionRole,
      joinDate: format(data.joinDate, 'yyyy-MM-dd'),
      dateOfBirth: data.dateOfBirth ? format(data.dateOfBirth, 'yyyy-MM-dd') : null,
      shiftId: data.shiftId === 'default_shift' ? null : data.shiftId,
      status: data.status,
      phone: data.phone,
      address: data.address,
      salary: data.salary ?? null,
      annualLeaveEntitlement: data.annualLeaveEntitlement ?? null,
      bankAccount: data.bankAccount || null,
      sssNumber: data.sssNumber || null,
      philhealthNumber: data.philhealthNumber || null,
      pagibigNumber: data.pagibigNumber || null,
      tinNumber: data.tinNumber || null,
    };

    try {
      const employeeRef = doc(db, "employees", employeeToEdit.id);
      await updateDoc(employeeRef, updatePayload);

      const adminName = employeeProfile?.name || "Admin";
      const adminNameParts = adminName.split(' ');
      const adminInitials = (
          adminNameParts.length > 1
          ? `${adminNameParts[0][0]}${adminNameParts[adminNameParts.length - 1][0]}`
          : adminName.substring(0, 2)
      ).toUpperCase();

      await addDoc(collection(db, "activityFeedItems"), {
        text: `updated the profile for ${employeeToEdit.name}.`,
        userId: user?.uid,
        userName: employeeProfile?.name || "Admin",
        userRole: employeeProfile?.permissionRole || "Administrator",
        avatarUrl: employeeProfile?.avatarUrl || "",
        avatarFallback: adminInitials,
        timestamp: new Date(),
        relatedEntityType: 'employee',
        relatedEntityId: employeeToEdit.id,
      });

      toast({
        title: 'Profile Updated',
        description: `${employeeToEdit.name}'s profile has been successfully updated.`,
        variant: 'success',
      });
      setIsEditDialogOpen(false);
      setEmployeeToEdit(null);
    } catch (err) {
      console.error("Error updating employee:", err);
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmittingEdit(false);
    }
  }
  
  const openResetPasswordDialog = (employee: Employee) => {
    setEmployeeForPasswordReset(employee);
    setIsResetPasswordDialogOpen(true);
  };
  
  const handleSendPasswordReset = async () => {
    if (!employeeForPasswordReset?.email) {
      toast({ title: "Error", description: "Employee does not have a valid email address.", variant: "destructive" });
      return;
    }
    
    try {
      await sendPasswordResetEmail(auth, employeeForPasswordReset.email);
      
      const employeeDocRef = doc(db, 'employees', employeeForPasswordReset.id);
      await updateDoc(employeeDocRef, {
          passwordResetInitiated: new Date(),
      });
      
      toast({
        title: "Success",
        description: `Password reset email sent to ${employeeForPasswordReset.email}.`,
        variant: 'success',
      });
    } catch (error: any) {
      console.error("Password reset error:", error);
      let errorMessage = "An unknown error occurred.";
      if (error.code === 'auth/user-not-found') {
          errorMessage = 'There is no user corresponding to the given email.';
      } else if (error.code === 'auth/unauthorized-continue-uri') {
          errorMessage = 'The domain of the continue URL is not authorized. Please contact support.';
      }
      toast({ title: "Error", description: errorMessage, variant: "destructive" });
    } finally {
      setIsResetPasswordDialogOpen(false);
      setEmployeeForPasswordReset(null);
    }
  };


  // Handlers for Department/Role management
  const handleAddNewField = async (type: 'department' | 'role') => {
    const name = type === 'department' ? newDepartmentName.trim() : newJobRoleName.trim();
    if (!name) {
      toast({ title: "Error", description: "Name cannot be empty.", variant: "destructive" });
      return;
    }
    setIsSubmittingNewField(true);
    const collectionName = type === 'department' ? 'departments' : 'jobRoles';
    try {
      await addDoc(collection(db, collectionName), { name });
      toast({ title: "Success", description: `${type === 'department' ? 'Department' : 'Job Role'} "${name}" added.`, variant: 'success' });
      if (type === 'department') setNewDepartmentName('');
      else setNewJobRoleName('');
    } catch (err) {
      toast({ title: "Error", description: `Failed to add ${type}.`, variant: "destructive" });
    } finally {
      setIsSubmittingNewField(false);
    }
  };

  const handleOpenEditFieldDialog = (item: Department | JobRole, type: 'department' | 'role') => {
    setFieldToEdit({ ...item, type });
    setEditFieldName(item.name);
  };

  const handleCloseEditFieldDialog = () => {
    setFieldToEdit(null);
    setEditFieldName('');
  };

  const handleSaveFieldEdit = async () => {
    if (!fieldToEdit || !editFieldName.trim()) {
      toast({ title: "Error", description: "Name cannot be empty.", variant: "destructive" });
      return;
    }
    setIsSubmittingFieldEdit(true);
    const collectionName = fieldToEdit.type === 'department' ? 'departments' : 'jobRoles';
    const docRef = doc(db, collectionName, fieldToEdit.id);
    try {
      await updateDoc(docRef, { name: editFieldName });
      toast({ title: "Success", description: `${fieldToEdit.type === 'department' ? 'Department' : 'Job Role'} updated.`, variant: 'success' });
      handleCloseEditFieldDialog();
    } catch (err) {
      toast({ title: "Error", description: `Failed to update ${fieldToEdit.type}.`, variant: "destructive" });
    } finally {
      setIsSubmittingFieldEdit(false);
    }
  };

  const handleOpenDeleteFieldDialog = (item: Department | JobRole, type: 'department' | 'role') => {
    setFieldToDelete({ ...item, type });
  };
  
  const handleCloseDeleteFieldDialog = () => {
    setFieldToDelete(null);
  }

  const handleConfirmDeleteField = async () => {
    if (!fieldToDelete) return;
    setIsSubmittingFieldDelete(true);
    const collectionName = fieldToDelete.type === 'department' ? 'departments' : 'jobRoles';
    const docRef = doc(db, collectionName, fieldToDelete.id);
    try {
      await deleteDoc(docRef);
      toast({ title: "Success", description: `${fieldToDelete.type === 'department' ? 'Department' : 'Job Role'} deleted.`, variant: 'success' });
      handleCloseDeleteFieldDialog();
    } catch (err) {
      toast({ title: "Error", description: `Failed to delete ${fieldToDelete.type}.`, variant: "destructive" });
    } finally {
      setIsSubmittingFieldDelete(false);
    }
  };

  const openPermanentDeleteDialog = (employee: Employee) => {
    setEmployeeToPermanentlyDelete(employee);
    setIsPermanentDeleteDialogOpen(true);
  };

  const handlePermanentDeleteConfirm = async () => {
    if (employeeToPermanentlyDelete) {
      try {
        await deleteDoc(doc(db, "employees", employeeToPermanentlyDelete.id));

        toast({
          title: "Employee Record Deleted",
          description: `${employeeToPermanentlyDelete.name}'s data has been deleted. Remember to delete their login from the Firebase Authentication console.`,
          variant: 'success',
          duration: 7000,
        });
      } catch (err) {
        console.error("Error permanently deleting employee record: ", err);
        toast({
          title: "Error",
          description: "Failed to delete employee record. Please try again.",
          variant: "destructive",
        });
      }
    }
    setIsPermanentDeleteDialogOpen(false);
    setEmployeeToPermanentlyDelete(null);
  };
  
  const openCancelDeletionDialog = (employee: Employee) => {
    setEmployeeToCancelDeletion(employee);
    setIsCancelDeletionDialogOpen(true);
  };

  const handleCancelDeletionConfirm = async () => {
    if (employeeToCancelDeletion) {
      try {
        const employeeRef = doc(db, "employees", employeeToCancelDeletion.id);
        await updateDoc(employeeRef, {
          status: 'Active',
          deletionRequested: false,
          deletionRequestTimestamp: null
        });

        toast({
          title: "Request Cancelled",
          description: `${employeeToCancelDeletion.name}'s account deletion request has been cancelled and their account reactivated.`,
          variant: 'success',
        });
      } catch (err) {
        console.error("Error cancelling deletion request: ", err);
        toast({
          title: "Error",
          description: "Failed to cancel the deletion request. Please try again.",
          variant: "destructive",
        });
      }
    }
    setIsCancelDeletionDialogOpen(false);
    setEmployeeToCancelDeletion(null);
  };

  const openResetEmailDialog = (employee: Employee) => {
    setEmployeeForResetEmail(employee);
    setIsResetEmailDialogOpen(true);
  };

  const handleSendResetEmail = async () => {
      if (!employeeForResetEmail?.email) {
          toast({ title: "Error", description: "Employee does not have a valid email address.", variant: "destructive" });
          return;
      }
      
      try {
        await sendPasswordResetEmail(auth, employeeForResetEmail.email);

        toast({
            title: "Password Reset Email Sent",
            description: `A password reset link has been sent to ${employeeForResetEmail.email} to help them verify access and secure their account.`,
            variant: "success",
        });
      } catch (error: any) {
          console.error("Error sending password reset email:", error);
          toast({
              title: "Error",
              description: "Could not send password reset email. The user's auth account may not exist or there's a configuration issue.",
              variant: "destructive",
          });
      } finally {
          setIsResetEmailDialogOpen(false);
          setEmployeeForResetEmail(null);
      }
  };

  const handleOpenAvatarDialog = (formType: 'add' | 'edit') => {
    setCurrentFormType(formType);
    if (formType === 'add') {
        setSelectedAvatarUrl(addForm.getValues('avatarUrl') || '');
    } else {
        setSelectedAvatarUrl(editForm.getValues('avatarUrl') || '');
    }
    setIsAvatarDialogOpen(true);
  };

  const handleSaveAvatarSelection = () => {
    if (currentFormType === 'add') {
      addForm.setValue('avatarUrl', selectedAvatarUrl);
    } else if (currentFormType === 'edit') {
      editForm.setValue('avatarUrl', selectedAvatarUrl);
    }
    setIsAvatarDialogOpen(false);
  };

  const getAvatarPreview = (formType: 'add' | 'edit') => {
    if (formType === 'add') {
      return addForm.watch('avatarUrl');
    }
    return editForm.watch('avatarUrl');
  };
  

  return (
    <>
      <PageHeader
        icon={<Users className="mr-2 h-7 w-7 text-primary" />}
        title="Employee Directory"
        description="Manage and view all employee information."
        actions={
          <div className="flex items-center gap-2">
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <PlusCircle className="mr-2 h-4 w-4" />
              <span>Add Employee</span>
            </Button>
          </div>
        }
      />

      {isAdmin && pendingDeletions.length > 0 && (
        <Card className="mb-6 border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center text-destructive">
              <ShieldAlert className="mr-2 h-5 w-5" />
              <span>Pending Account Deletions</span>
            </CardTitle>
            <CardDescription>
              The following users have requested to have their accounts and data deleted. Review and process these requests.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingDeletions.map((employee) => (
                <div key={employee.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 rounded-md border bg-muted/50 gap-2">
                  <div className="flex items-center gap-3">
                     <Avatar>
                        <AvatarImage src={employee.avatarUrl} alt={employee.name}  data-ai-hint="employee avatar"/>
                        <AvatarFallback>{(employee.name?.split(' ').length > 1 ? `${employee.name.split(' ')[0][0]}${employee.name.split(' ')[employee.name.split(' ').length - 1][0]}` : employee.name?.substring(0, 2) || '').toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold">{employee.name}</p>
                        <p className="text-sm text-muted-foreground">{employee.email}</p>
                        {employee.deletionRequestTimestamp?.toDate && (
                          <p className="text-xs text-muted-foreground">
                            Requested on: {format(employee.deletionRequestTimestamp.toDate(), 'PPP p')}
                          </p>
                        )}
                      </div>
                  </div>
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                    <Button variant="outline" size="sm" onClick={() => openCancelDeletionDialog(employee)}>
                      <RotateCcw className="mr-2 h-4 w-4" /> <span>Cancel Request</span>
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => openPermanentDeleteDialog(employee)}>
                      <Trash2 className="mr-2 h-4 w-4" /> <span>Process Deletion</span>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-2 items-center">
            <div className="relative flex-grow min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <span className="flex items-center">
                  <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                  <SelectValue placeholder="Filter by Department" />
                </span>
              </SelectTrigger>
              <SelectContent>
                {allDepartmentsForFilter.map(dept => (
                  <SelectItem key={dept.value} value={dept.value}>{dept.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[160px]">
                <span className="flex items-center">
                  <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                  <SelectValue placeholder="Filter by Status" />
                </span>
              </SelectTrigger>
              <SelectContent>
                {employeeStatusesForFilter.map(stat => (
                  <SelectItem key={stat} value={stat}>{stat === 'all' ? 'All Statuses' : stat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => setIsManageFieldsDialogOpen(true)}>
              <SlidersHorizontal className="mr-2 h-4 w-4" />
              <span>Manage Fields</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {error && !isLoading && (
            <div className="p-4 text-center text-destructive-foreground bg-destructive/90 rounded-md">
              <p>{error}</p>
            </div>
          )}
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead className="hidden md:table-cell">Employee ID</TableHead>
                <TableHead>Department</TableHead>
                <TableHead className="hidden sm:table-cell">Job Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Permission Role</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            
            {isLoading ? (
              <TableBody>
                {[...Array(5)].map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="space-y-1">
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-3 w-24 md:hidden" />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell"><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell className="hidden sm:table-cell"><Skeleton className="h-4 w-28" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-24 rounded-full" /></TableCell>
                    <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            ) : (
              <TableBody>
                {!error && filteredEmployees.length > 0 ? (
                  filteredEmployees.map((employee) => {
                    const nameParts = employee.name.split(' ');
                    const initials = (
                      nameParts.length > 1
                        ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}`
                        : employee.name.substring(0, 2)
                    ).toUpperCase();
                    return (
                    <TableRow key={employee.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={employee.avatarUrl} alt={employee.name}  data-ai-hint="employee avatar"/>
                            <AvatarFallback>{initials}</AvatarFallback>
                          </Avatar>
                          <div>
                            <Link href={`/employees/${employee.id}`} className="font-medium hover:underline">{employee.name}</Link>
                            <div className="text-sm text-muted-foreground md:hidden">{employee.employeeId}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">{employee.employeeId}</TableCell>
                      <TableCell>{employee.department}</TableCell>
                      <TableCell className="hidden sm:table-cell">{employee.role}</TableCell>
                      <TableCell>
                        {getStatusBadgeComponent(employee.status)}
                      </TableCell>
                       <TableCell>
                        {employee.permissionRole ? (
                            <Badge variant="secondary">{employee.permissionRole}</Badge>
                        ) : (
                            <Badge variant="outline">Not Set</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEditDialog(employee)}>
                              <Edit3 className="mr-2 h-4 w-4" />
                              <span>Edit Profile</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openResetPasswordDialog(employee)}>
                               <KeyRound className="mr-2 h-4 w-4" />
                               <span>Reset Password</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openResetEmailDialog(employee)}>
                               <Mail className="mr-2 h-4 w-4" />
                               <span>Send Reset/Verify Email</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive focus:bg-destructive/10"
                              onClick={() => openSoftDeleteDialog(employee)}
                            >
                              <UserX className="mr-2 h-4 w-4" />
                              <span>Mark for Deletion</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )})
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center h-24">
                      No employees found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            )}
          </Table>
        </CardContent>
      </Card>

      <AlertDialog open={isSoftDeleteDialogOpen} onOpenChange={setIsSoftDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will mark the employee "{employeeToSoftDelete?.name}" for deletion and move them to the "Pending Deletions" queue for final review. Their account will be deactivated, and they will no longer be able to log in.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setEmployeeToSoftDelete(null)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSoftDeleteConfirm} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              <UserX className="mr-2 h-4 w-4"/>
              <span>Yes, Mark for Deletion</span>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <AlertDialog open={isResetPasswordDialogOpen} onOpenChange={setIsResetPasswordDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset Password</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to send a password reset email to <span className="font-semibold">{employeeForPasswordReset?.email}</span>? This will also log the user out of any active sessions.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setEmployeeForPasswordReset(null)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSendPasswordReset}>
              <Mail className="mr-2 h-4 w-4"/>
              <span>Send Email</span>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <AlertDialog open={isResetEmailDialogOpen} onOpenChange={setIsResetEmailDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Send Password Reset / Verification Email</AlertDialogTitle>
            <AlertDialogDescription>
              This will send a password reset email to <span className="font-semibold">{employeeForResetEmail?.email}</span>. This is the most secure way for an admin to confirm a user has access to their email and prompt them to secure their account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsResetEmailDialogOpen(false)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSendResetEmail}>
              <Mail className="mr-2 h-4 w-4"/>
              <span>Send Email</span>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={isPermanentDeleteDialogOpen} onOpenChange={setIsPermanentDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Process Account Deletion?</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to permanently delete the employee record for <span className="font-semibold">{employeeToPermanentlyDelete?.name}</span>.
              <br /><br />
              <span className="font-bold text-destructive">IMPORTANT:</span> This only deletes the employee data from the application database. You must manually delete the user's login account from the Firebase Authentication console to fully remove them and free up the email. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setEmployeeToPermanentlyDelete(null)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handlePermanentDeleteConfirm} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              <Trash2 className="mr-2 h-4 w-4"/>
              <span>Yes, Delete Record</span>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <AlertDialog open={isCancelDeletionDialogOpen} onOpenChange={setIsCancelDeletionDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Deletion Request?</AlertDialogTitle>
            <AlertDialogDescription>
              This will cancel the account deletion request for <span className="font-semibold">{employeeToCancelDeletion?.name}</span>. Their account will be reactivated, and they will be able to log in again. Are you sure?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setEmployeeToCancelDeletion(null)}><XCircle className="mr-2 h-4 w-4"/>No, Keep Request</AlertDialogCancel>
            <AlertDialogAction onClick={handleCancelDeletionConfirm}>
              <RotateCcw className="mr-2 h-4 w-4"/>
              <span>Yes, Cancel Request</span>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Add Employee Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={(isOpen) => {
        setIsAddDialogOpen(isOpen);
        if (!isOpen) {
          addForm.reset();
          setAddFormStep(1);
        }
      }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add New Employee</DialogTitle>
            <DialogDescription>
              Fill in the employee's details. Step {addFormStep} of 2.
            </DialogDescription>
          </DialogHeader>
          <Form {...addForm}>
            <form id="addEmployeeForm" onSubmit={addForm.handleSubmit(onAddSubmit)} className="flex flex-col overflow-hidden">
              <ScrollArea className="flex-grow pr-6 -mr-6" style={{ maxHeight: '70vh' }}>
                <div className="px-1 py-4">
                  {addFormStep === 1 && (
                    <div className="space-y-4">
                        <div className="flex items-center gap-4">
                        <div className="relative group shrink-0">
                            <Avatar className="h-20 w-20">
                                <AvatarImage src={getAvatarPreview('add')} />
                                <AvatarFallback className="text-2xl">
                                    {(addForm.watch('name')?.split(' ').length > 1
                                        ? `${addForm.watch('name').split(' ')[0][0]}${addForm.watch('name').split(' ')[addForm.watch('name').split(' ').length - 1][0]}`
                                        : addForm.watch('name')?.substring(0, 2) || 'AV'
                                    ).toUpperCase()}
                                </AvatarFallback>
                            </Avatar>
                            <button
                                type="button"
                                onClick={() => handleOpenAvatarDialog('add')}
                                className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <Edit3 className="h-8 w-8 text-white" />
                            </button>
                        </div>
                        <div className="flex-grow space-y-4">
                            <FormField control={addForm.control} name="name" render={({ field }) => ( <FormItem> <FormLabel>Full Name</FormLabel> <FormControl><Input {...field} /></FormControl> <FormMessage /> </FormItem> )}/>
                            <FormField control={addForm.control} name="employeeId" render={({ field }) => ( <FormItem> <FormLabel>Employee ID</FormLabel> <FormControl><Input {...field} placeholder="e.g., EMP001" /></FormControl> <FormMessage /> </FormItem> )}/>
                        </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={addForm.control} name="dateOfBirth" render={({ field }) => ( <FormItem className="flex flex-col"> <FormLabel>Date of Birth</FormLabel> <FormControl><DatePicker date={field.value} onDateChange={field.onChange} buttonClassName="w-full" captionLayout="dropdown-buttons" fromYear={1950} toYear={new Date().getFullYear()} /></FormControl> <FormMessage /> </FormItem> )}/>
                            <FormField control={addForm.control} name="joinDate" render={({ field }) => ( <FormItem className="flex flex-col"> <FormLabel>Join Date</FormLabel> <FormControl><DatePicker date={field.value} onDateChange={field.onChange} buttonClassName="w-full" /></FormControl> <FormMessage /> </FormItem> )}/>
                        </div>
                        <FormField control={addForm.control} name="email" render={({ field }) => ( <FormItem> <FormLabel>Email Address</FormLabel> <FormControl><Input type="email" {...field} /></FormControl><FormDescription>This will be the employee's login username.</FormDescription> <FormMessage /> </FormItem> )}/>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField control={addForm.control} name="password" render={({ field }) => ( <FormItem> <FormLabel>Password</FormLabel> <FormControl><div className="relative"><Input type={showAddPassword ? 'text' : 'password'} {...field} /><Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-0" onClick={() => setShowAddPassword((prev) => !prev)} aria-label={showAddPassword ? "Hide password" : "Show password"}>{showAddPassword ? <EyeOff /> : <Eye />}</Button></div></FormControl>{addPasswordValue && (<div className="mt-2"><Progress value={addPasswordStrength} className={cn("h-2", addPasswordStrength < 50 ? "bg-red-500" : addPasswordStrength < 75 ? "bg-yellow-500" : "bg-green-500")} /><p className={cn("text-xs mt-1", addPasswordStrength < 50 ? "text-red-500" : addPasswordStrength < 75 ? "text-yellow-500" : "text-green-500")}>{addPasswordStrength < 50 ? "Weak" : addPasswordStrength < 75 ? "Medium" : "Strong"}</p></div>)}<FormMessage /> </FormItem> )}/>
                        <FormField control={addForm.control} name="confirmPassword" render={({ field }) => ( <FormItem> <FormLabel>Confirm Password</FormLabel> <FormControl><div className="relative"><Input type={showAddPassword ? 'text' : 'password'} {...field} /><Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-0" onClick={() => setShowAddPassword((prev) => !prev)} aria-label={showAddPassword ? "Hide password" : "Show password"}>{showAddPassword ? <EyeOff /> : <Eye />}</Button></div></FormControl> <FormMessage /> </FormItem> )}/>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField control={addForm.control} name="department" render={({ field }) => ( <FormItem> <FormLabel>Department</FormLabel> <Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger disabled={isLoadingFields}><SelectValue placeholder="Select a department" /></SelectTrigger></FormControl> <SelectContent>{departments.map(d => <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>)}</SelectContent></Select> <FormMessage /> </FormItem> )}/>
                        <FormField control={addForm.control} name="role" render={({ field }) => ( <FormItem> <FormLabel>Job Role</FormLabel> <Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger disabled={isLoadingFields}><SelectValue placeholder="Select a job role" /></SelectTrigger></FormControl> <SelectContent>{jobRoles.map(r => <SelectItem key={r.id} value={r.name}>{r.name}</SelectItem>)}</SelectContent></Select> <FormMessage /> </FormItem> )}/>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField control={addForm.control} name="permissionRole" render={({ field }) => ( <FormItem> <FormLabel>Permission Role</FormLabel> <Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Assign a permission role" /></SelectTrigger></FormControl> <SelectContent><SelectItem value="User">User</SelectItem><SelectItem value="Administrator">Administrator</SelectItem></SelectContent></Select> <FormDescription>System access level.</FormDescription> <FormMessage /> </FormItem> )}/>
                        <FormField control={addForm.control} name="shiftId" render={({ field }) => ( <FormItem> <FormLabel>Work Shift</FormLabel> <Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger disabled={isLoadingFields}><SelectValue placeholder="Select a shift" /></SelectTrigger></FormControl> <SelectContent><SelectItem value="default_shift">Default Shift</SelectItem>{shifts.map(s => <SelectItem key={s.id} value={s.id}>{s.name} ({s.startTime} - {s.endTime})</SelectItem>)}</SelectContent></Select> <FormMessage /> </FormItem> )}/>
                        </div>
                    </div>
                  )}
                  {addFormStep === 2 && (
                    <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={addForm.control} name="status" render={({ field }) => ( <FormItem> <FormLabel>Status</FormLabel> <Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl> <SelectContent> {statuses.map(stat => <SelectItem key={stat} value={stat}>{stat}</SelectItem>)} </SelectContent></Select> <FormMessage /> </FormItem> )}/>
                            <FormField control={addForm.control} name="phone" render={({ field }) => ( <FormItem> <FormLabel>Phone Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                        </div>
                        <FormField control={addForm.control} name="address" render={({ field }) => ( <FormItem> <FormLabel>Address</FormLabel> <FormControl><Textarea {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={addForm.control} name="salary" render={({ field }) => ( <FormItem> <FormLabel>Monthly Salary (PHP)</FormLabel> <FormControl><Input type="number" {...field} value={field.value ?? ''} onChange={e => field.onChange(e.target.value === '' ? undefined : parseFloat(e.target.value))} /></FormControl> <FormMessage /> </FormItem> )}/>
                            <FormField control={addForm.control} name="annualLeaveEntitlement" render={({ field }) => ( <FormItem> <FormLabel>Annual Leave Entitlement</FormLabel> <FormControl><Input type="number" {...field} value={field.value ?? ''} placeholder="e.g., 15" onChange={e => field.onChange(e.target.value === '' ? undefined : parseInt(e.target.value, 10))} /></FormControl> <FormDescription>Total paid annual leave days per year.</FormDescription><FormMessage /> </FormItem> )}/>
                        </div>
                        <FormField control={addForm.control} name="bankAccount" render={({ field }) => ( <FormItem> <FormLabel>Bank Account No.</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <FormField control={addForm.control} name="sssNumber" render={({ field }) => ( <FormItem> <FormLabel>SSS Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                            <FormField control={addForm.control} name="philhealthNumber" render={({ field }) => ( <FormItem> <FormLabel>PhilHealth Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                            <FormField control={addForm.control} name="pagibigNumber" render={({ field }) => ( <FormItem> <FormLabel>Pag-ibig Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                            <FormField control={addForm.control} name="tinNumber" render={({ field }) => ( <FormItem> <FormLabel>TIN Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                        </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
              <DialogFooter className="flex-shrink-0 pt-4 border-t">
                <DialogClose asChild><Button type="button" variant="outline" disabled={isSubmittingAdd}><XCircle className="mr-2 h-4 w-4" /><span>Cancel</span></Button></DialogClose>
                {addFormStep === 1 && (
                    <Button type="button" onClick={handleNextStep}>
                        <span>Next</span> <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                )}
                {addFormStep === 2 && (
                    <div className="flex gap-2">
                        <Button type="button" variant="outline" onClick={() => setAddFormStep(1)}>
                            <ArrowLeft className="mr-2 h-4 w-4" /> <span>Back</span>
                        </Button>
                        <Button type="submit" form="addEmployeeForm" disabled={isSubmittingAdd}>
                            {isSubmittingAdd ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                            <span>Save Employee</span>
                        </Button>
                    </div>
                )}
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Edit Employee Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={(isOpen) => {
        setIsEditDialogOpen(isOpen);
        if (!isOpen) {
          setEditFormStep(1);
        }
      }}>
        <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
                <DialogTitle>Edit Employee Profile</DialogTitle>
                <DialogDescription>
                Make changes to {employeeToEdit?.name}'s profile. Step {editFormStep} of 2.
                </DialogDescription>
            </DialogHeader>
            <Form {...editForm}>
              <form id="editEmployeeForm" onSubmit={editForm.handleSubmit(onEditSubmit)} className="flex flex-col overflow-hidden">
                <ScrollArea className="flex-grow pr-6 -mr-6" style={{ maxHeight: '70vh' }}>
                  <div className="px-1 py-4">
                    {editFormStep === 1 && (
                      <div className="space-y-6">
                        <div className="flex items-center gap-4">
                            <div className="relative group shrink-0">
                                <Avatar className="h-20 w-20">
                                    <AvatarImage src={getAvatarPreview('edit')} />
                                    <AvatarFallback className="text-2xl">
                                        {(editForm.watch('name')?.split(' ').length > 1
                                            ? `${editForm.watch('name').split(' ')[0][0]}${editForm.watch('name').split(' ')[editForm.watch('name').split(' ').length - 1][0]}`
                                            : editForm.watch('name')?.substring(0, 2) || 'AV'
                                        ).toUpperCase()}
                                    </AvatarFallback>
                                </Avatar>
                                <button
                                    type="button"
                                    onClick={() => handleOpenAvatarDialog('edit')}
                                    className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                    <Edit3 className="h-8 w-8 text-white" />
                                </button>
                            </div>
                            <div className="flex-grow space-y-4">
                                <FormField control={editForm.control} name="name" render={({ field }) => (<FormItem><FormLabel>Full Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)} />
                                <FormField control={editForm.control} name="employeeId" render={({ field }) => ( <FormItem><FormLabel>Employee ID</FormLabel><FormControl><Input {...field} disabled /></FormControl><FormDescription>Employee ID cannot be changed.</FormDescription><FormMessage /> </FormItem> )}/>
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={editForm.control} name="dateOfBirth" render={({ field }) => ( <FormItem className="flex flex-col"><FormLabel>Date of Birth</FormLabel><FormControl><DatePicker date={field.value} onDateChange={field.onChange} buttonClassName="w-full" captionLayout="dropdown-buttons" fromYear={1950} toYear={new Date().getFullYear()} /></FormControl><FormMessage /></FormItem> )}/>
                            <FormField control={editForm.control} name="joinDate" render={({ field }) => ( <FormItem className="flex flex-col"><FormLabel>Join Date</FormLabel><FormControl><DatePicker date={field.value} onDateChange={field.onChange} buttonClassName="w-full" /></FormControl><FormMessage /></FormItem> )}/>
                        </div>
                        <FormField control={editForm.control} name="email" render={({ field }) => ( <FormItem><FormLabel>Email Address</FormLabel><div className="flex items-center gap-2"><FormControl><Input type="email" {...field} disabled /></FormControl><Button type="button" variant="outline" size="sm" onClick={() => employeeToEdit && openResetEmailDialog(employeeToEdit)}><Mail className="mr-2 h-4 w-4" /> Send Reset</Button></div><FormDescription>User email cannot be changed by an admin directly.</FormDescription><FormMessage /> </FormItem> )}/>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={editForm.control} name="department" render={({ field }) => ( <FormItem><FormLabel>Department</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={isLoadingFields}><FormControl><SelectTrigger><SelectValue placeholder="Select a department" /></SelectTrigger></FormControl><SelectContent>{departments.map(d => (<SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem>)}/>
                            <FormField control={editForm.control} name="role" render={({ field }) => ( <FormItem><FormLabel>Job Role</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={isLoadingFields}><FormControl><SelectTrigger><SelectValue placeholder="Select a job role" /></SelectTrigger></FormControl><SelectContent>{jobRoles.map(r => (<SelectItem key={r.id} value={r.name}>{r.name}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem> )}/>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField control={editForm.control} name="permissionRole" render={({ field }) => ( <FormItem><FormLabel>Permission Role</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Assign a permission role" /></SelectTrigger></FormControl><SelectContent><SelectItem value="User">User</SelectItem><SelectItem value="Administrator">Administrator</SelectItem></SelectContent></Select><FormDescription>System access level.</FormDescription><FormMessage /></FormItem> )}/>
                            <FormField control={editForm.control} name="shiftId" render={({ field }) => ( <FormItem> <FormLabel>Work Shift</FormLabel> <Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger disabled={isLoadingFields}><SelectValue placeholder="Select a shift" /></SelectTrigger></FormControl> <SelectContent><SelectItem value="default_shift">Default Shift</SelectItem>{shifts.map(s => <SelectItem key={s.id} value={s.id}>{s.name} ({s.startTime} - {s.endTime})</SelectItem>)}</SelectContent></Select> <FormMessage /> </FormItem> )}/>
                        </div>
                      </div>
                    )}
                    {editFormStep === 2 && (
                      <div className="space-y-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <FormField control={editForm.control} name="status" render={({ field }) => ( <FormItem> <FormLabel>Status</FormLabel> <Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Select employee status" /></SelectTrigger></FormControl><SelectContent>{statuses.map(stat => (<SelectItem key={stat} value={stat}>{stat}</SelectItem>))}</SelectContent></Select><FormMessage /> </FormItem> )}/>
                              <FormField control={editForm.control} name="phone" render={({ field }) => ( <FormItem> <FormLabel>Phone Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                          </div>
                          <FormField control={editForm.control} name="address" render={({ field }) => ( <FormItem> <FormLabel>Address</FormLabel> <FormControl><Textarea {...field} value={field.value ?? ''} placeholder="123 Main St, Anytown..." rows={3}/></FormControl> <FormMessage /> </FormItem> )}/>
                          <Separator />
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <FormField control={editForm.control} name="salary" render={({ field }) => ( <FormItem> <FormLabel>Monthly Salary (PHP)</FormLabel> <FormControl><Input type="number" {...field} value={field.value ?? ''} onChange={e => field.onChange(e.target.value === '' ? undefined : parseFloat(e.target.value))} /></FormControl> <FormMessage /> </FormItem> )}/>
                              <FormField control={editForm.control} name="annualLeaveEntitlement" render={({ field }) => ( <FormItem> <FormLabel>Annual Leave Entitlement</FormLabel> <FormControl><Input type="number" {...field} value={field.value ?? ''} placeholder="e.g., 15" onChange={e => field.onChange(e.target.value === '' ? undefined : parseInt(e.target.value, 10))} /></FormControl> <FormDescription>Total paid annual leave days per year.</FormDescription> <FormMessage /> </FormItem> )}/>
                          </div>
                          <FormField control={editForm.control} name="bankAccount" render={({ field }) => ( <FormItem> <FormLabel>Bank Account No.</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                              <FormField control={editForm.control} name="sssNumber" render={({ field }) => ( <FormItem> <FormLabel>SSS Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                              <FormField control={editForm.control} name="philhealthNumber" render={({ field }) => ( <FormItem> <FormLabel>PhilHealth Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                              <FormField control={editForm.control} name="pagibigNumber" render={({ field }) => ( <FormItem> <FormLabel>Pag-ibig Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                              <FormField control={editForm.control} name="tinNumber" render={({ field }) => ( <FormItem> <FormLabel>TIN Number</FormLabel> <FormControl><Input {...field} value={field.value ?? ''} /></FormControl> <FormMessage /> </FormItem> )}/>
                          </div>
                          <Separator />
                          <div className="space-y-2">
                              <h4 className="font-medium text-foreground">Security</h4>
                              <p className="text-sm text-muted-foreground">Manage the employee's login credentials. Email changes require user verification.</p>
                          </div>
                          <div className="flex flex-col sm:flex-row gap-2">
                          <Button type="button" variant="outline" onClick={() => employeeToEdit && openResetEmailDialog(employeeToEdit)}>
                              <Mail className="mr-2 h-4 w-4" />
                              <span>Send Reset/Verify Email</span>
                          </Button>
                          <Button type="button" variant="outline" onClick={() => employeeToEdit && openResetPasswordDialog(employeeToEdit)}>
                              <KeyRound className="mr-2 h-4 w-4" />
                              <span>Send Password Reset</span>
                          </Button>
                          </div>
                      </div>
                    )}
                  </div>
                </ScrollArea>
                <DialogFooter className="flex-shrink-0 pt-4 border-t">
                  {editFormStep === 1 && (
                      <>
                      <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                          <XCircle className="mr-2 h-4 w-4" />
                          <span>Cancel</span>
                      </Button>
                      <Button type="button" onClick={handleEditNextStep}>
                          <span>Next</span>
                          <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                      </>
                  )}
                  {editFormStep === 2 && (
                      <div className="flex w-full justify-between">
                          <Button type="button" variant="outline" onClick={() => setEditFormStep(1)}>
                              <ArrowLeft className="mr-2 h-4 w-4" />
                              <span>Back</span>
                          </Button>
                          <Button type="submit" form="editEmployeeForm" disabled={isSubmittingEdit || isLoadingFields}>
                            {isSubmittingEdit ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                            <span>Save Changes</span>
                          </Button>
                      </div>
                  )}
                </DialogFooter>
              </form>
            </Form>
        </DialogContent>
      </Dialog>
      
      {/* Manage Fields Dialogs */}
      <Dialog open={isManageFieldsDialogOpen} onOpenChange={setIsManageFieldsDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Manage Fields</DialogTitle>
            <DialogDescription>Add, edit, or delete Departments and Job Roles.</DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="departments" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="departments"><Home className="h-4 w-4" /><span>Departments</span></TabsTrigger>
              <TabsTrigger value="roles"><Briefcase className="h-4 w-4" /><span>Job Roles</span></TabsTrigger>
            </TabsList>
            <TabsContent value="departments" className="mt-4">
              <Card>
                <CardContent className="pt-6">
                  <ScrollArea className="h-64 pr-4">
                    <div className="space-y-2">
                      {departments.map(dept => (
                        <div key={dept.id} className="flex items-center justify-between p-2 rounded-md border">
                          <span>{dept.name}</span>
                          <div className="space-x-1">
                            <Button variant="ghost" size="icon" onClick={() => handleOpenEditFieldDialog(dept, 'department')}>
                              <Edit3 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleOpenDeleteFieldDialog(dept, 'department')}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  <div className="mt-4 flex gap-2">
                    <Input value={newDepartmentName} onChange={e => setNewDepartmentName(e.target.value)} placeholder="New department name" />
                    <Button onClick={() => handleAddNewField('department')} disabled={isSubmittingNewField}>
                      {isSubmittingNewField ? <Loader2 className="animate-spin h-4 w-4" /> : <PlusCircle className="mr-2 h-4 w-4" />}
                      <span>Add</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="roles" className="mt-4">
              <Card>
                <CardContent className="pt-6">
                  <ScrollArea className="h-64 pr-4">
                    <div className="space-y-2">
                      {jobRoles.map(role => (
                        <div key={role.id} className="flex items-center justify-between p-2 rounded-md border">
                          <span>{role.name}</span>
                          <div className="space-x-1">
                            <Button variant="ghost" size="icon" onClick={() => handleOpenEditFieldDialog(role, 'role')}>
                              <Edit3 className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleOpenDeleteFieldDialog(role, 'role')}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  <div className="mt-4 flex gap-2">
                    <Input value={newJobRoleName} onChange={e => setNewJobRoleName(e.target.value)} placeholder="New job role name" />
                    <Button onClick={() => handleAddNewField('role')} disabled={isSubmittingNewField}>
                      {isSubmittingNewField ? <Loader2 className="animate-spin h-4 w-4" /> : <PlusCircle className="mr-2 h-4 w-4" />}
                      <span>Add</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          <DialogFooter className="mt-4">
            <DialogClose asChild><Button type="button" variant="outline"><XCircle className="mr-2 h-4 w-4"/><span>Close</span></Button></DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!fieldToEdit} onOpenChange={(open) => !open && handleCloseEditFieldDialog()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit {fieldToEdit?.type === 'department' ? 'Department' : 'Job Role'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-4">
            <Label htmlFor="edit-field-name">Name</Label>
            <Input id="edit-field-name" value={editFieldName} onChange={e => setEditFieldName(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseEditFieldDialog} disabled={isSubmittingFieldEdit}><XCircle className="mr-2 h-4 w-4"/><span>Cancel</span></Button>
            <Button onClick={handleSaveFieldEdit} disabled={isSubmittingFieldEdit}>
              {isSubmittingFieldEdit ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              <span>Save Changes</span>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={!!fieldToDelete} onOpenChange={(open) => !open && handleCloseDeleteFieldDialog()}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the {fieldToDelete?.type} "{fieldToDelete?.name}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSubmittingFieldDelete} onClick={handleCloseDeleteFieldDialog}><XCircle className="mr-2 h-4 w-4"/><span>Cancel</span></AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDeleteField} className="bg-destructive text-destructive-foreground hover:bg-destructive/90" disabled={isSubmittingFieldDelete}>
              {isSubmittingFieldDelete ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
              <span>Delete</span>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Avatar Selection Dialog */}
      <Dialog open={isAvatarDialogOpen} onOpenChange={setIsAvatarDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Select an Avatar</DialogTitle>
            <DialogDescription>Choose a new profile picture from the library.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4 py-4 max-h-[50vh] overflow-y-auto">
            {avatarLibrary.map((url) => (
              <button
                key={url}
                className={cn(
                  "relative aspect-square rounded-full border-2 transition-all",
                  selectedAvatarUrl === url ? "border-primary ring-2 ring-primary ring-offset-2" : "border-transparent"
                )}
                onClick={() => setSelectedAvatarUrl(url)}
              >
                <Image src={url} alt="Avatar option" width={100} height={100} className="rounded-full" />
                {selectedAvatarUrl === url && (
                  <div className="absolute inset-0 bg-primary/70 flex items-center justify-center rounded-full"><Check className="h-8 w-8 text-primary-foreground" /></div>
                )}
              </button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAvatarDialogOpen(false)}><XCircle className="mr-2 h-4 w-4" />Cancel</Button>
            <Button onClick={handleSaveAvatarSelection}><Save className="mr-2 h-4 w-4" />Save Avatar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}









