
'use client';

import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { useAuth } from '@/contexts/auth-context';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/firebase';
import { collection, query, doc, updateDoc, where, onSnapshot, deleteDoc, addDoc } from 'firebase/firestore';
import type { HelpDeskTicket } from '@/types';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { LifeBuoy, Loader2, Eye, Save, XCircle, MoreHorizontal, Trash2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";


const ticketUpdateSchema = z.object({
  adminNotes: z.string().optional(),
  status: z.enum(['Open', 'In Progress', 'Resolved', 'Closed']),
});

type TicketUpdateFormValues = z.infer<typeof ticketUpdateSchema>;

export default function HelpDeskPage() {
  const { employeeProfile, user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';

  const [tickets, setTickets] = useState<HelpDeskTicket[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(true);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<HelpDeskTicket | null>(null);
  const [isSubmittingUpdate, setIsSubmittingUpdate] = useState(false);

  // State for delete functionality
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [ticketToDelete, setTicketToDelete] = useState<HelpDeskTicket | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const form = useForm<TicketUpdateFormValues>({
    resolver: zodResolver(ticketUpdateSchema),
  });

  useEffect(() => {
    if (authLoading || !user) {
      setLoadingTickets(false);
      return;
    }

    setLoadingTickets(true);
    const ticketsCollection = collection(db, "helpDeskTickets");
    let q;
    if (isAdmin) {
      q = query(ticketsCollection);
    } else {
      q = query(ticketsCollection, where("submittedByUserId", "==", user.uid));
    }
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const fetchedTickets = querySnapshot.docs.map(doc => {
        const data = doc.data();
        const createdAtDate = data.createdAt?.toDate ? data.createdAt.toDate() : new Date(0);
        return {
          id: doc.id,
          submittedByUserId: data.submittedByUserId || 'N/A',
          submittedByUserName: data.submittedByUserName || 'Unknown User',
          submittedByUserEmail: data.submittedByUserEmail || 'N/A',
          subject: data.subject || 'No Subject Provided',
          description: data.description || 'No Description Provided',
          status: data.status || 'Open',
          createdAt: createdAtDate,
          adminNotes: data.adminNotes || '',
        } as HelpDeskTicket;
      });

      fetchedTickets.sort((a, b) => {
        const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : 0;
        const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : 0;
        return dateB - dateA;
      });

      setTickets(fetchedTickets);
      setLoadingTickets(false);
    }, (error) => {
      console.error("Error fetching help desk tickets:", error);
      toast({ title: "Error", description: "Could not fetch tickets.", variant: "destructive" });
      setLoadingTickets(false);
    });

    return () => unsubscribe();
  }, [isAdmin, authLoading, user, toast]);

  const handleOpenViewDialog = (ticket: HelpDeskTicket) => {
    setSelectedTicket(ticket);
    if (isAdmin) {
      form.reset({
        adminNotes: ticket.adminNotes || '',
        status: ticket.status || 'Open',
      });
    }
    setIsViewDialogOpen(true);
  };

  const handleUpdateTicket = async (data: TicketUpdateFormValues) => {
    if (!selectedTicket || !isAdmin) return;
    setIsSubmittingUpdate(true);
    try {
      const ticketRef = doc(db, "helpDeskTickets", selectedTicket.id);
      await updateDoc(ticketRef, {
        status: data.status,
        adminNotes: data.adminNotes || '',
      });

      // Create a notification for the user
      const notificationText = `Your support ticket "${selectedTicket.subject}" has been updated to status: ${data.status}.`;
      const notificationData = {
        userId: selectedTicket.submittedByUserId,
        type: 'info' as const,
        text: notificationText,
        timestamp: new Date(),
        isRead: false,
        link: '/help-desk',
      };
      await addDoc(collection(db, "notifications"), notificationData);
      
      toast({ title: "Success", description: "Ticket has been updated and user notified.", variant: 'success' });
      setIsViewDialogOpen(false);
    } catch (error) {
      console.error("Error updating ticket:", error);
      toast({ title: "Error", description: "Failed to update the ticket.", variant: "destructive" });
    } finally {
      setIsSubmittingUpdate(false);
    }
  };

  const handleOpenDeleteDialog = (ticket: HelpDeskTicket) => {
    setTicketToDelete(ticket);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteTicket = async () => {
    if (!ticketToDelete) return;
    setIsDeleting(true);
    try {
      await deleteDoc(doc(db, "helpDeskTickets", ticketToDelete.id));
      toast({ title: "Success", description: "Ticket has been deleted.", variant: 'success' });
      setIsDeleteDialogOpen(false);
      setTicketToDelete(null);
    } catch (error) {
      console.error("Error deleting ticket:", error);
      toast({ title: "Error", description: "Failed to delete the ticket.", variant: "destructive" });
    } finally {
      setIsDeleting(false);
    }
  };


  const getStatusBadge = (status?: HelpDeskTicket['status']) => {
    switch (status) {
      case 'Open':
        return <Badge variant="destructive">Open</Badge>;
      case 'In Progress':
        return <Badge className="border-transparent bg-yellow-100 text-yellow-800 dark:bg-yellow-900/40 dark:text-yellow-300 hover:bg-yellow-100/80 dark:hover:bg-yellow-900/60 whitespace-nowrap">In Progress</Badge>;
      case 'Resolved':
        return <Badge className="border-transparent bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 hover:bg-blue-100/80 dark:hover:bg-blue-900/60">Resolved</Badge>;
      case 'Closed':
        return <Badge variant="outline">Closed</Badge>;
      default:
        return <Badge>{status || 'Unknown'}</Badge>;
    }
  };
  
  if (authLoading) {
    return (
        <div className="flex items-center justify-center h-60">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
    );
  }

  return (
    <>
      <PageHeader
        icon={<LifeBuoy className="h-7 w-7 text-primary" />}
        title="Help Desk Tickets"
        description={isAdmin ? "View and manage user-submitted support tickets and concerns." : "View the status of your submitted support tickets."}
      />
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">Status</TableHead>
                <TableHead>Subject</TableHead>
                {isAdmin && <TableHead>Submitted By</TableHead>}
                <TableHead>Date Submitted</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loadingTickets ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-4/5" /></TableCell>
                    {isAdmin && <TableCell><Skeleton className="h-4 w-32" /></TableCell>}
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : tickets.length > 0 ? (
                tickets.map((ticket) => (
                  <TableRow key={ticket.id}>
                    <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                    <TableCell className="font-medium">{ticket.subject}</TableCell>
                    {isAdmin && (
                      <TableCell>
                        <div>{ticket.submittedByUserName}</div>
                        <div className="text-xs text-muted-foreground">{ticket.submittedByUserEmail}</div>
                      </TableCell>
                    )}
                    <TableCell>{ticket.createdAt ? format(ticket.createdAt, 'PPp') : 'N/A'}</TableCell>
                    <TableCell className="text-right">
                      {isAdmin ? (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleOpenViewDialog(ticket)}>
                              <Eye className="mr-2 h-4 w-4" />
                              <span>View / Edit</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => handleOpenDeleteDialog(ticket)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              <span>Delete</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ) : (
                        <Button variant="outline" size="sm" onClick={() => handleOpenViewDialog(ticket)}>
                          <Eye className="mr-2 h-4 w-4" /> View
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={isAdmin ? 5 : 4} className="h-24 text-center">
                    No help desk tickets found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{selectedTicket?.subject || 'No Subject'}</DialogTitle>
            <DialogDescription>
              Submitted by {selectedTicket?.submittedByUserName || 'Unknown'} on {selectedTicket?.createdAt ? format(selectedTicket.createdAt, 'PPp') : 'N/A'}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[50vh] p-1 pr-4 -mr-4">
            <div className="space-y-4 p-4">
              <div>
                <h4 className="font-semibold mb-1">User's Concern:</h4>
                <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap">{selectedTicket?.description || 'No description provided.'}</p>
              </div>
              
              {isAdmin ? (
                <Form {...form}>
                  <form id="ticket-update-form" onSubmit={form.handleSubmit(handleUpdateTicket)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ticket Status</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Open">Open</SelectItem>
                              <SelectItem value="In Progress">In Progress</SelectItem>
                              <SelectItem value="Resolved">Resolved</SelectItem>
                              <SelectItem value="Closed">Closed</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="adminNotes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Administrator Notes (Optional)</FormLabel>
                          <FormControl>
                            <Textarea {...field} placeholder="Add notes for internal reference..." rows={4} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </form>
                </Form>
              ) : (
                <div>
                  <h4 className="font-semibold mb-1">Administrator Notes:</h4>
                  <p className="text-sm p-3 bg-muted rounded-md whitespace-pre-wrap">{selectedTicket?.adminNotes || 'No notes from admin yet.'}</p>
                </div>
              )}
            </div>
          </ScrollArea>
          <DialogFooter>
            {isAdmin ? (
              <>
                <DialogClose asChild><Button type="button" variant="outline" disabled={isSubmittingUpdate}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button></DialogClose>
                <Button type="submit" form="ticket-update-form" disabled={isSubmittingUpdate}>
                  {isSubmittingUpdate ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>}
                  Update Ticket
                </Button>
              </>
            ) : (
              <DialogClose asChild><Button type="button"><XCircle className="mr-2 h-4 w-4"/>Close</Button></DialogClose>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the ticket
              with the subject: "{ticketToDelete?.subject}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting} onClick={() => setIsDeleteDialogOpen(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteTicket}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
              Delete Ticket
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
