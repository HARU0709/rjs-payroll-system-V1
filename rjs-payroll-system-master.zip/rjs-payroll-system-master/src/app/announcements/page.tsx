
'use client';

import { useState, useEffect, type FormEvent } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, isValid, formatDistanceToNow } from 'date-fns';
import { useRouter, useSearchParams } from 'next/navigation';

import { PageHeader } from '@/components/shared/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth-context';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, query, orderBy, addDoc, doc, updateDoc, deleteDoc, serverTimestamp, getDocs, writeBatch, where, getDoc } from 'firebase/firestore';
import type { Announcement, NotificationItem, AnnouncementComment } from '@/types';
import { Megaphone, PlusCircle, Edit, Trash2, Loader2, Save, XCircle, MessageSquare, Reply, MoreHorizontal, Send } from 'lucide-react';
import { cn } from '@/lib/utils';

const announcementSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters long."),
  content: z.string().min(10, "Content must be at least 10 characters long."),
});
type AnnouncementFormValues = z.infer<typeof announcementSchema>;
type CommentWithReplies = AnnouncementComment & { replies: CommentWithReplies[] };

export default function AnnouncementsPage() {
  const { user, employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [announcementToEdit, setAnnouncementToEdit] = useState<Announcement | null>(null);
  
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [announcementToDelete, setAnnouncementToDelete] = useState<Announcement | null>(null);
  
  const quickEmojis = ['👍', '🎉', '💡', '📢', '✅', '❤️'];

  // State for announcement details dialog
  const [isViewAnnouncementDialogOpen, setIsViewAnnouncementDialogOpen] = useState(false);
  const [selectedAnnouncementForView, setSelectedAnnouncementForView] = useState<Announcement | null>(null);
  const [comments, setComments] = useState<CommentWithReplies[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  
  // State for comment actions
  const [editingComment, setEditingComment] = useState<{ id: string; text: string } | null>(null);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [commentToDelete, setCommentToDelete] = useState<AnnouncementComment | null>(null);
  const [isDeleteCommentDialogOpen, setIsDeleteCommentDialogOpen] = useState(false);

  const form = useForm<AnnouncementFormValues>({
    resolver: zodResolver(announcementSchema),
  });

  const handleEmojiClick = (emoji: string) => {
    const currentContent = form.getValues('content');
    form.setValue('content', `${currentContent || ''}${emoji}`);
  };

  useEffect(() => {
    if (authLoading) return;
    if (!isAdmin) {
      router.push('/dashboard');
      return;
    }

    setLoading(true);
    const q = query(collection(db, "announcements"), orderBy("timestamp", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedAnnouncements = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          timestamp: data.timestamp?.toDate ? data.timestamp.toDate() : new Date(0),
        } as Announcement;
      });
      setAnnouncements(fetchedAnnouncements);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching announcements:", error);
      toast({ title: "Error", description: "Failed to fetch announcements.", variant: "destructive" });
      setLoading(false);
    });

    return () => unsubscribe();
  }, [isAdmin, authLoading, router, toast]);

  useEffect(() => {
    const announcementId = searchParams.get('announcement');
    if (announcementId) {
      const fetchAndShowAnnouncement = async () => {
        try {
          const docRef = doc(db, 'announcements', announcementId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const announcementData = {
              id: docSnap.id,
              ...docSnap.data(),
              timestamp: docSnap.data().timestamp?.toDate ? docSnap.data().timestamp.toDate() : new Date(0),
            } as Announcement;
            handleOpenAnnouncementDialog(announcementData);
          } else {
            toast({ title: "Not Found", description: "The requested announcement does not exist.", variant: "destructive" });
          }
        } catch (error) {
          toast({ title: "Error", description: "Failed to fetch the announcement.", variant: "destructive" });
        } finally {
          router.replace('/announcements', { scroll: false });
        }
      };
      fetchAndShowAnnouncement();
    }
  }, [searchParams, router, toast]);

  const nestComments = (list: AnnouncementComment[]): CommentWithReplies[] => {
      const listWithReplies = list.map(c => ({ ...c, replies: [] as CommentWithReplies[] }));
      const map = new Map(listWithReplies.map(c => [c.id, c]));
      const roots: CommentWithReplies[] = [];
      for (const comment of map.values()) {
          if (comment.parentCommentId && map.has(comment.parentCommentId)) {
              map.get(comment.parentCommentId)!.replies.push(comment);
          } else {
              roots.push(comment);
          }
      }
      return roots;
  };

  useEffect(() => {
    if (!selectedAnnouncementForView) {
        setComments([]);
        return;
    }

    setLoadingComments(true);
    const commentsQuery = query(
        collection(db, 'announcementComments'),
        where('announcementId', '==', selectedAnnouncementForView.id)
    );

    const unsubscribe = onSnapshot(commentsQuery, (snapshot) => {
        const fetchedComments = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            timestamp: doc.data().timestamp?.toDate ? doc.data().timestamp.toDate() : new Date(),
        } as AnnouncementComment));
        
        fetchedComments.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());

        const nested = nestComments(fetchedComments);
        setComments(nested);
        setLoadingComments(false);
    }, (error) => {
        console.error("Error fetching comments:", error);
        toast({ title: "Error", description: "Could not load comments. Check permissions.", variant: "destructive" });
        setLoadingComments(false);
    });

    return () => unsubscribe();
  }, [selectedAnnouncementForView, toast]);

  const handleOpenFormDialog = (announcement: Announcement | null) => {
    setAnnouncementToEdit(announcement);
    if (announcement) {
      form.reset({ title: announcement.title, content: announcement.content });
    } else {
      form.reset({ title: '', content: '' });
    }
    setIsFormDialogOpen(true);
  };
  
  const handleOpenAnnouncementDialog = (announcement: Announcement) => {
    setSelectedAnnouncementForView(announcement);
    setIsViewAnnouncementDialogOpen(true);
  };

  const handleFormSubmit = async (data: AnnouncementFormValues) => {
    if (!employeeProfile) return;
    setIsSubmitting(true);
    try {
      if (announcementToEdit) {
        // Update existing announcement
        const docRef = doc(db, "announcements", announcementToEdit.id);
        await updateDoc(docRef, { ...data });
        toast({ title: "Success", description: "Announcement updated." });
      } else {
        // Create new announcement
        await addDoc(collection(db, "announcements"), {
          ...data,
          authorName: employeeProfile.name,
          authorId: employeeProfile.id,
          timestamp: serverTimestamp(),
          isPublished: false,
        });
        toast({ title: "Success", description: "Announcement created as a draft." });
      }
      setIsFormDialogOpen(false);
    } catch (error) {
      console.error("Error saving announcement:", error);
      toast({ title: "Error", description: "Failed to save announcement.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleTogglePublish = async (announcement: Announcement) => {
    const isPublishing = !announcement.isPublished;
    try {
      const docRef = doc(db, "announcements", announcement.id);
      await updateDoc(docRef, { isPublished: isPublishing });

      if (isPublishing) {
        try {
          const employeesQuery = query(collection(db, "employees"), where("employeeId", "!=", "ADMIN"));
          const employeesSnapshot = await getDocs(employeesQuery);
          
          if (!employeesSnapshot.empty) {
            const batch = writeBatch(db);
            employeesSnapshot.forEach(employeeDoc => {
              const notificationRef = doc(collection(db, "notifications"));
              const notificationData: Omit<NotificationItem, 'id'> = {
                userId: employeeDoc.id,
                type: 'info',
                text: `New Announcement: "${announcement.title}"`,
                timestamp: new Date(),
                isRead: false,
                link: `/dashboard?announcement=${announcement.id}`,
              };
              batch.set(notificationRef, notificationData);
            });
            await batch.commit();
          }
          toast({
            title: "Success",
            description: "Announcement has been published and employees notified.",
            variant: 'success'
          });
        } catch (notificationError) {
          console.error("Failed to send notifications:", notificationError);
          toast({
            title: "Published, but with a warning",
            description: "Announcement published, but failed to send notifications to all users.",
            variant: "warning",
          });
        }
      } else {
        toast({
          title: "Success",
          description: "Announcement has been unpublished.",
          variant: 'success'
        });
      }
    } catch (error) {
      console.error("Error toggling publish state:", error);
      toast({ title: "Error", description: "Failed to update announcement status.", variant: "destructive" });
    }
  };
  
  const handleOpenDeleteDialog = (announcement: Announcement) => {
    setAnnouncementToDelete(announcement);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!announcementToDelete) return;
    setIsSubmitting(true); // Reuse submitting state
    try {
      await deleteDoc(doc(db, "announcements", announcementToDelete.id));
      toast({ title: "Success", description: "Announcement deleted.", variant: 'success' });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Error deleting announcement:", error);
      toast({ title: "Error", description: "Failed to delete announcement.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
      setAnnouncementToDelete(null);
    }
  };
  
  const handleCommentSubmit = async (e: FormEvent, text: string, parentId?: string) => {
    e.preventDefault();
    if (!text.trim() || !user || !employeeProfile || !selectedAnnouncementForView) return;
  
    setIsSubmittingComment(true);
  
    const nameParts = employeeProfile.name.split(' ');
    const initials = (nameParts.length > 1 ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}` : employeeProfile.name.substring(0, 2)).toUpperCase();
  
    const commentData: Omit<AnnouncementComment, 'id'> = {
        announcementId: selectedAnnouncementForView.id,
        userId: user.uid,
        userName: employeeProfile.name,
        userAvatarUrl: employeeProfile.avatarUrl || '',
        userAvatarFallback: initials,
        commentText: text.trim(),
        timestamp: new Date(),
        ...(parentId && { parentCommentId: parentId }),
    };
  
    try {
      await addDoc(collection(db, 'announcementComments'), commentData);
      
      if (parentId) {
          setReplyingTo(null);
          setReplyContent('');
      } else {
          setNewComment('');
      }
    } catch (error) {
      console.error("Error posting comment:", error);
      toast({ title: "Error", description: "Could not post your comment. Check your permissions.", variant: "destructive" });
      setIsSubmittingComment(false);
      return;
    }
  
    try {
        const q = query(collection(db, "employees"), where("permissionRole", "==", "Administrator"));
        const adminsSnapshot = await getDocs(q);

        if (!adminsSnapshot.empty) {
            const batch = writeBatch(db);
            const notificationText = `${employeeProfile.name} commented on the announcement: "${selectedAnnouncementForView.title}"`;
            adminsSnapshot.forEach(adminDoc => {
                const adminId = adminDoc.id;
                if (adminId !== user.uid) { // Don't notify the user who commented
                    const notificationRef = doc(collection(db, "notifications"));
                    batch.set(notificationRef, {
                        userId: adminId,
                        type: 'info',
                        text: notificationText,
                        timestamp: new Date(),
                        isRead: false,
                        link: `/announcements?announcement=${selectedAnnouncementForView.id}`, 
                    });
                }
            });
            await batch.commit();
        }
    } catch (notificationError) {
        console.warn("Comment posted, but failed to notify admins:", notificationError);
    }
  
    setIsSubmittingComment(false);
  };
  
  const handleUpdateComment = async (commentId: string, text: string) => {
    if (!text.trim()) return;
    setIsSubmittingComment(true);
    try {
      const commentRef = doc(db, 'announcementComments', commentId);
      await updateDoc(commentRef, { commentText: text.trim() });
      toast({ title: "Success", description: "Comment updated." });
      setEditingComment(null);
    } catch (error) {
      toast({ title: "Error", description: "Could not update comment.", variant: "destructive" });
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleDeleteComment = async () => {
    if (!commentToDelete) return;
    setIsSubmittingComment(true);
    try {
      const commentRef = doc(db, 'announcementComments', commentToDelete.id);
      await deleteDoc(commentRef);
      toast({ title: "Success", description: "Comment deleted." });
      setCommentToDelete(null);
      setIsDeleteCommentDialogOpen(false);
    } catch (error) {
      toast({ title: "Error", description: "Could not delete comment.", variant: "destructive" });
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const renderComments = (commentsToRender: CommentWithReplies[], level: number = 0) => {
    return commentsToRender.map(comment => (
      <div key={comment.id} className={cn("flex items-start space-x-3", level > 0 && "mt-4 ml-6 pl-4 border-l-2")}>
        <Avatar className="h-8 w-8">
            <AvatarImage src={comment.userAvatarUrl || `https://placehold.co/40x40.png?text=${comment.userAvatarFallback}`} alt={comment.userName} data-ai-hint="employee avatar" />
            <AvatarFallback>{comment.userAvatarFallback}</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
            <div className="bg-muted p-3 rounded-lg">
                <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold">{comment.userName}</p>
                    <p className="text-xs text-muted-foreground">{formatDistanceToNow(comment.timestamp, { addSuffix: true })}</p>
                </div>
                {editingComment?.id === comment.id ? (
                  <form onSubmit={(e) => { e.preventDefault(); handleUpdateComment(comment.id, editingComment.text); }} className="mt-2 space-y-2">
                    <Textarea value={editingComment.text} onChange={(e) => setEditingComment({ ...editingComment, text: e.target.value })} autoFocus className="min-h-[60px]" />
                    <div className="flex justify-end gap-2">
                      <Button type="button" size="sm" variant="ghost" onClick={() => setEditingComment(null)}>Cancel</Button>
                      <Button type="submit" size="sm" disabled={isSubmittingComment}>
                        {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin"/> : "Save"}
                      </Button>
                    </div>
                  </form>
                ) : (
                  <p className="text-sm text-foreground mt-1 whitespace-pre-wrap">{comment.commentText}</p>
                )}
            </div>

            {!editingComment && (
              <div className="flex items-center gap-2">
                <Button variant="link" size="sm" className="p-0 h-auto text-xs" onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}>
                    <Reply className="mr-1 h-3 w-3" /> Reply
                </Button>
                {(user?.uid === comment.userId || isAdmin) && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6"><MoreHorizontal className="h-4 w-4" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        {user?.uid === comment.userId &&
                            <DropdownMenuItem onClick={() => setEditingComment({ id: comment.id, text: comment.commentText })}>
                                <Edit className="mr-2 h-4 w-4" /> Edit
                            </DropdownMenuItem>
                        }
                        <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => { setCommentToDelete(comment); setIsDeleteCommentDialogOpen(true); }}>
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            )}
            
            {replyingTo === comment.id && (
              <form onSubmit={(e) => handleCommentSubmit(e, replyContent, comment.id)} className="flex items-start space-x-2 mt-2">
                  <Avatar className="h-8 w-8"><AvatarImage src={employeeProfile?.avatarUrl || undefined} /><AvatarFallback>{employeeProfile?.name?.charAt(0)}</AvatarFallback></Avatar>
                  <Textarea value={replyContent} onChange={(e) => setReplyContent(e.target.value)} placeholder={`Replying to ${comment.userName}...`} className="min-h-[60px]" />
                  <Button type="submit" size="sm" disabled={isSubmittingComment}>
                      {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : "Post"}
                  </Button>
              </form>
            )}

            {comment.replies && renderComments(comment.replies, level + 1)}
        </div>
      </div>
    ));
  };


  if (loading || authLoading) {
    return (
      <div className="space-y-4">
        <PageHeader title="Announcements" description="Loading..." />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }

  return (
    <>
      <PageHeader
        icon={<Megaphone className="h-7 w-7 text-primary" />}
        title="Manage Announcements"
        description="Create, publish, and manage company-wide announcements."
        actions={<Button onClick={() => handleOpenFormDialog(null)}><PlusCircle className="mr-2 h-4 w-4" /> New Announcement</Button>}
      />
      <div className="space-y-4">
        {announcements.length > 0 ? (
          announcements.map(announcement => (
            <Card key={announcement.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{announcement.title}</CardTitle>
                    <CardDescription>
                      By {announcement.authorName} on {isValid(announcement.timestamp) ? format(announcement.timestamp, 'PPp') : '...'}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={announcement.isPublished ? 'default' : 'secondary'}>
                      {announcement.isPublished ? 'Published' : 'Draft'}
                    </Badge>
                     <Button variant="outline" size="sm" onClick={() => handleOpenAnnouncementDialog(announcement)}>
                        <MessageSquare className="mr-2 h-4 w-4" />
                        View Comments
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleOpenFormDialog(announcement)}><Edit className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleOpenDeleteDialog(announcement)}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="whitespace-pre-wrap">{announcement.content}</p>
                <div className="flex items-center space-x-2">
                  <Switch
                    id={`publish-switch-${announcement.id}`}
                    checked={announcement.isPublished}
                    onCheckedChange={() => handleTogglePublish(announcement)}
                  />
                  <Label htmlFor={`publish-switch-${announcement.id}`}>
                    {announcement.isPublished ? 'Published' : 'Publish this announcement'}
                  </Label>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              No announcements found. Get started by creating one.
            </CardContent>
          </Card>
        )}
      </div>

      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{announcementToEdit ? 'Edit' : 'Create'} Announcement</DialogTitle>
            <DialogDescription>Fill in the details for your announcement.</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form id="announcement-form" onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4 py-2">
              <FormField control={form.control} name="title" render={({ field }) => (
                <FormItem><FormLabel>Title</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="content" render={({ field }) => (
                <FormItem><FormLabel>Content</FormLabel><FormControl><Textarea {...field} rows={5} /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="pt-2">
                <Label className="text-xs text-muted-foreground">Add an emoji:</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {quickEmojis.map((emoji) => (
                    <Button
                      type="button"
                      key={emoji}
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 text-lg"
                      onClick={() => handleEmojiClick(emoji)}
                    >
                      {emoji}
                    </Button>
                  ))}
                </div>
              </div>
            </form>
          </Form>
          <DialogFooter>
            <DialogClose asChild><Button type="button" variant="outline" disabled={isSubmitting}>Cancel</Button></DialogClose>
            <Button type="submit" form="announcement-form" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the announcement "{announcementToDelete?.title}". This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setAnnouncementToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} disabled={isSubmitting} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4"/>} Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={isViewAnnouncementDialogOpen} onOpenChange={setIsViewAnnouncementDialogOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-2xl">{selectedAnnouncementForView?.title}</DialogTitle>
            <DialogDescription>
              Posted by {selectedAnnouncementForView?.authorName} on {selectedAnnouncementForView?.timestamp ? format(selectedAnnouncementForView.timestamp, 'PPp') : ''}
            </DialogDescription>
          </DialogHeader>
          <div className="flex-grow overflow-y-auto pr-6 -mr-6">
            <p className="whitespace-pre-wrap leading-relaxed">{selectedAnnouncementForView?.content}</p>
            <Separator className="my-6" />
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Comments
              </h4>
              {loadingComments ? (
                 <div className="space-y-4">
                    <div className="flex items-start space-x-4"><Skeleton className="h-10 w-10 rounded-full" /><div className="space-y-2"><Skeleton className="h-4 w-[250px]" /><Skeleton className="h-4 w-[200px]" /></div></div>
                    <div className="flex items-start space-x-4"><Skeleton className="h-10 w-10 rounded-full" /><div className="space-y-2"><Skeleton className="h-4 w-[250px]" /><Skeleton className="h-4 w-[200px]" /></div></div>
                 </div>
              ) : comments.length > 0 ? (
                <div className="space-y-4">{renderComments(comments)}</div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No comments yet. Be the first to comment!</p>
              )}
            </div>
          </div>
          <DialogFooter className="border-t pt-4 flex-shrink-0">
            <form onSubmit={(e) => handleCommentSubmit(e, newComment)} className="flex w-full items-center space-x-2">
                <Input
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Write a comment..."
                    disabled={isSubmittingComment}
                />
                <Button type="submit" size="icon" disabled={isSubmittingComment || !newComment.trim()}>
                    {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
            </form>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteCommentDialogOpen} onOpenChange={setIsDeleteCommentDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the comment. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setCommentToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteComment} disabled={isSubmittingComment} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              {isSubmittingComment ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4"/>} Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
