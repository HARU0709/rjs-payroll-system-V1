

'use client';

import { useState, useEffect, useMemo, type FormEvent } from 'react';
import { Button, buttonVariants } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DatePicker } from '@/components/ui/date-picker';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Archive,
  CalendarDays,
  CheckCircle2,
  Eye,
  Filter,
  History,
  Loader2,
  MoreHorizontal,
  PlusCircle,
  RotateCcw,
  Search,
  Send,
  Settings as SettingsIcon,
  Users,
  XCircle,
  ShieldCheck,
  AlertTriangle,
  Trash2,
  TrendingUp,
  TrendingDown,
  Circle,
  Plane,
} from 'lucide-react';
import { format, differenceInCalendarDays, parseISO, isWithinInterval, subDays, isValid, getYear } from "date-fns";
import type { DateRange } from 'react-day-picker';
import type { LeaveRequest, Employee, LeaveSettings } from '@/types';
import { useToast } from "@/hooks/use-toast";
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/auth-context';
import { db } from '@/lib/firebase';
import { collection, addDoc, query, where, getDocs, doc, updateDoc, orderBy, setDoc, writeBatch, deleteDoc, onSnapshot, getDoc } from 'firebase/firestore';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PageHeader } from '@/components/shared/page-header';

// Helper function to calculate duration
const calculateDuration = (startDateStr: string, endDateStr: string): string => {
  if (!startDateStr || !endDateStr) return 'N/A';
  try {
    const start = parseISO(startDateStr);
    const end = parseISO(endDateStr);
    if (!isValid(start) || !isValid(end)) return 'Invalid dates';

    const days = differenceInCalendarDays(end, start) + 1;
    if (days <= 0) return 'Invalid dates';
    return `${days} day${days > 1 ? 's' : ''}`;
  } catch (e) {
    return 'N/A';
  }
};

const getNumericDuration = (startDate: Date | undefined, endDate: Date | undefined): number => {
  if (!startDate || !endDate) return 0;
  try {
    if (!isValid(startDate) || !isValid(endDate)) return 0;
    const days = differenceInCalendarDays(endDate, startDate) + 1;
    return days > 0 ? days : 0;
  } catch {
    return 0;
  }
};


export default function LeaveManagementPage() {
  const { toast } = useToast();
  const { user, employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';

  const [allLeaveRequests, setAllLeaveRequests] = useState<LeaveRequest[]>([]);
  const [allEmployees, setAllEmployees] = useState<Employee[]>([]);
  const [isLoadingAllRequests, setIsLoadingAllRequests] = useState(true);
  const [isLoadingEmployees, setIsLoadingEmployees] = useState(true);

  const [activeTab, setActiveTab] = useState('approveRequests');
  
  // Filters for "Approve Requests" tab
  const [approveRequestsSearchTerm, setApproveRequestsSearchTerm] = useState('');
  const [approveRequestsStatusFilter, setApproveRequestsStatusFilter] = useState('Pending');
  const [showApproveRequestsAdvancedFilters, setShowApproveRequestsAdvancedFilters] = useState(false);
  const [approveRequestsLeaveTypeFilter, setApproveRequestsLeaveTypeFilter] = useState('All');
  const [approveRequestsDurationFilter, setApproveRequestsDurationFilter] = useState('All Durations');
  const [approveRequestsDateRangeFilter, setApproveRequestsDateRangeFilter] = useState<DateRange | undefined>();
  
  // Filters for "All History" tab
  const [allHistorySearchTerm, setAllHistorySearchTerm] = useState('');
  const [allHistoryStatusFilter, setAllHistoryStatusFilter] = useState('All'); 
  const [showAllHistoryAdvancedFilters, setShowAllHistoryAdvancedFilters] = useState(false);
  const [allHistoryLeaveTypeFilter, setAllHistoryLeaveTypeFilter] = useState('All');
  const [allHistoryDurationFilter, setAllHistoryDurationFilter] = useState('All Durations');
  const [allHistoryDateRangeFilter, setAllHistoryDateRangeFilter] = useState<DateRange | undefined>();

  const [selectedRequests, setSelectedRequests] = useState<string[]>([]);
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);

  // New state to track which employee's balance to show
  const [employeeForBalanceView, setEmployeeForBalanceView] = useState<Employee | null>(null);

  const [isRequestLeaveDialogOpen, setIsRequestLeaveDialogOpen] = useState(false);
  
  // State for Archive Settings Dialog
  const [isArchiveSettingsDialogOpen, setIsArchiveSettingsDialogOpen] = useState(false);
  const [leaveSettings, setLeaveSettings] = useState<LeaveSettings>({ archiveOlderThanDays: 365 });
  const [archiveDaysInputValue, setArchiveDaysInputValue] = useState<number>(365);
  const [isLoadingLeaveSettings, setIsLoadingLeaveSettings] = useState(true);
  const [isSubmittingArchiveSettings, setIsSubmittingArchiveSettings] = useState(false);


  // State for Request Leave Dialog
  const [selectedEmployeeForLeave, setSelectedEmployeeForLeave] = useState<string | undefined>(undefined);
  const [leaveType, setLeaveType] = useState('');
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [reason, setReason] = useState('');
  const [isSubmittingLeave, setIsSubmittingLeave] = useState(false);
  const [isDatePopoverOpen, setIsDatePopoverOpen] = useState(false);
  const [tempDateRange, setTempDateRange] = useState<DateRange | undefined>();

  // State for Rejection Dialog
  const [isRejectionDialogOpen, setIsRejectionDialogOpen] = useState(false);
  const [requestToReject, setRequestToReject] = useState<LeaveRequest | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');


  // State for View Details Dialog
  const [isViewDetailsDialogOpen, setIsViewDetailsDialogOpen] = useState(false);
  const [selectedRequestForDetails, setSelectedRequestForDetails] = useState<LeaveRequest | null>(null);

  // State for Archiving Dialogs
  const [isArchivingRecords, setIsArchivingRecords] = useState(false);
  
  // State for Archive All Review Dialog
  const [isArchiveAllReviewDialogOpen, setIsArchiveAllReviewDialogOpen] = useState(false);
  const [recordsForArchiveAllReview, setRecordsForArchiveAllReview] = useState<LeaveRequest[]>([]);
  const [isLoadingArchiveAllReview, setIsLoadingArchiveAllReview] = useState(false);

  // State for Single Record Archiving Dialog
  const [isSingleArchiveDialogOpen, setIsSingleArchiveDialogOpen] = useState(false);
  const [requestToArchive, setRequestToArchive] = useState<LeaveRequest | null>(null);
  
  // State for Deletion Dialog
  const [isDeleteLeaveDialogOpen, setIsDeleteLeaveDialogOpen] = useState(false);
  const [requestToDelete, setRequestToDelete] = useState<LeaveRequest | null>(null);

  const fetchLeaveSettings = async () => {
    setIsLoadingLeaveSettings(true);
    try {
      const settingsDocRef = doc(db, 'companySettings', 'leave');
      const docSnap = await getDoc(settingsDocRef);
      if (docSnap.exists()) {
        const settingsData = docSnap.data() as LeaveSettings;
        setLeaveSettings(settingsData);
        setArchiveDaysInputValue(settingsData.archiveOlderThanDays);
      } else {
        // If no settings exist, use the initial defaults
        setLeaveSettings({ archiveOlderThanDays: 365 });
        setArchiveDaysInputValue(365);
      }
    } catch (error) {
      console.error("Error fetching leave settings:", error);
      toast({ title: "Warning", description: "Could not load leave settings, using defaults.", variant: "default" });
    } finally {
      setIsLoadingLeaveSettings(false);
    }
  };


  useEffect(() => {
    // Make employees real-time
    setIsLoadingEmployees(true);
    const qEmployees = query(collection(db, "employees"), orderBy("name"));
    const unsubscribeEmployees = onSnapshot(qEmployees, (snapshot) => {
      const employeesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee));
      setAllEmployees(employeesData);
      setIsLoadingEmployees(false);
    }, (error) => {
        console.error("Error fetching employees in real-time:", error);
        toast({ title: "Error", description: "Could not fetch employee data.", variant: "destructive" });
        setIsLoadingEmployees(false);
    });

    // Fetch settings (one-time is fine)
    fetchLeaveSettings();

    if (!user) {
      setIsLoadingAllRequests(false);
      // Clean up employee subscription if user logs out
      return () => unsubscribeEmployees();
    }

    // Make leave requests real-time
    setIsLoadingAllRequests(true);
    const qLeaves = query(
      collection(db, "leaveRequests"),
      orderBy("appliedDate", "desc")
    );
    const unsubscribeLeaves = onSnapshot(qLeaves, (querySnapshot) => {
      const requests = querySnapshot.docs.map(doc => {
        const data = doc.data();

        const safeParseDate = (dateVal: any): string => {
          if (!dateVal) return "";
          if (typeof dateVal === 'string') {
            try {
              return format(parseISO(dateVal), 'yyyy-MM-dd');
            } catch { return ""; }
          }
          if (dateVal.toDate && typeof dateVal.toDate === 'function') { // Firestore Timestamp
            try {
              return format(dateVal.toDate(), 'yyyy-MM-dd');
            } catch { return ""; }
          }
          return "";
        };

        return {
          id: doc.id,
          ...data,
          startDate: safeParseDate(data.startDate),
          endDate: safeParseDate(data.endDate),
          appliedDate: safeParseDate(data.appliedDate),
        } as LeaveRequest;
      });
      setAllLeaveRequests(requests);
      setIsLoadingAllRequests(false);
    }, (error) => {
      console.error("Error fetching all leave requests in real-time:", error);
      toast({ title: "Error", description: "Could not fetch leave requests.", variant: "destructive" });
      setIsLoadingAllRequests(false);
    });
    
    // Cleanup subscriptions on unmount
    return () => {
        unsubscribeEmployees();
        unsubscribeLeaves();
    };
  }, [user, toast]);


  useEffect(() => {
    if (isArchiveAllReviewDialogOpen) {
        const fetchRecordsForReview = async () => {
            setIsLoadingArchiveAllReview(true);
            setRecordsForArchiveAllReview([]); // Clear previous
            try {
                // Fetch all 'Approved' and 'Rejected' records first
                const q = query(
                    collection(db, "leaveRequests"),
                    where("status", "in", ["Approved", "Rejected"])
                );
                const querySnapshot = await getDocs(q);
                const allHistoricalRecords = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LeaveRequest));
                
                // Then, filter on the client-side to include records where isArchived is either missing (undefined) or explicitly false.
                // This ensures old records without the field are included for archiving.
                const recordsToArchive = allHistoricalRecords.filter(record => record.isArchived !== true);
                
                setRecordsForArchiveAllReview(recordsToArchive);
            } catch (error) {
                console.error("Error fetching records for archive review:", error);
                toast({ title: "Error", description: "Could not fetch records for review.", variant: "destructive" });
            } finally {
                setIsLoadingArchiveAllReview(false);
            }
        };
        fetchRecordsForReview();
    }
  }, [isArchiveAllReviewDialogOpen, toast]);

  useEffect(() => {
    if (isDatePopoverOpen) {
        setTempDateRange(dateRange);
    }
  }, [isDatePopoverOpen, dateRange]);

  const userVisibleLeaveRequests = useMemo(() => {
    if (authLoading || !user) return [];
    if (isAdmin) return allLeaveRequests;
    return allLeaveRequests.filter(req => req.employeeId === user.uid);
  }, [isAdmin, allLeaveRequests, user, authLoading]);

  const leaveBalance = useMemo(() => {
    if (!employeeForBalanceView) return null;
    const employee = employeeForBalanceView;

    const entitlement = employee.annualLeaveEntitlement ?? 0;
    const currentYear = getYear(new Date());
    
    const usedLeaveDays = allLeaveRequests
      .filter(req => 
        req.employeeId === employee.id &&
        req.status === 'Approved' &&
        isValid(parseISO(req.startDate)) &&
        getYear(parseISO(req.startDate)) === currentYear
      )
      .reduce((total, req) => {
        const duration = getNumericDuration(parseISO(req.startDate), parseISO(req.endDate));
        return total + duration;
      }, 0);

    return {
      employeeName: employee.name,
      entitlement,
      used: usedLeaveDays,
      remaining: entitlement - usedLeaveDays,
    };
  }, [employeeForBalanceView, allLeaveRequests]);


  const getEmployeeNameById = (employeeId: string) => {
    const employee = allEmployees.find(emp => emp.id === employeeId);
    return employee ? employee.name : 'Unknown Employee';
  };

  const applyFilters = (
    requests: LeaveRequest[],
    currentSearchTerm: string,
    currentStatusFilter: string,
    currentLeaveTypeFilter: string,
    currentDurationFilter: string,
    currentDateRangeFilter?: DateRange
  ) => {
    return requests.filter(req => {
        const matchesStatus = currentStatusFilter === 'All' || req.status === currentStatusFilter;
        
        const employeeName = getEmployeeNameById(req.employeeId).toLowerCase();
        const searchLower = currentSearchTerm.toLowerCase();
        const matchesSearch =
          employeeName.includes(searchLower) ||
          req.leaveType.toLowerCase().includes(searchLower);

        const matchesLeaveType = currentLeaveTypeFilter === 'All' || req.leaveType === currentLeaveTypeFilter;

        const reqDurationDays = getNumericDuration(parseISO(req.startDate), parseISO(req.endDate));
        let matchesDuration = currentDurationFilter === 'All Durations';
        if (currentDurationFilter === 'Single Day') matchesDuration = reqDurationDays === 1;
        else if (currentDurationFilter === '2-5 Days') matchesDuration = reqDurationDays >= 2 && reqDurationDays <= 5;
        else if (currentDurationFilter === '6-10 Days') matchesDuration = reqDurationDays >= 6 && reqDurationDays <= 10;
        else if (currentDurationFilter === 'More than 10 days') matchesDuration = reqDurationDays > 10;

        let matchesDateRange = true;
        if (currentDateRangeFilter?.from) {
          const reqStartDate = parseISO(req.startDate);
          const reqEndDate = parseISO(req.endDate);
          if (!isValid(reqStartDate) || !isValid(reqEndDate)) {
             matchesDateRange = false;
          } else {
            const filterStartDate = currentDateRangeFilter.from;
            const filterEndDate = currentDateRangeFilter.to || currentDateRangeFilter.from; 
            matchesDateRange = reqStartDate <= filterEndDate && reqEndDate >= filterStartDate;
          }
        }
        
        return matchesStatus && matchesSearch && matchesLeaveType && matchesDuration && matchesDateRange;
      });
  };

  const filteredApproveRequests = useMemo(() => {
    const archiveDate = subDays(new Date(), leaveSettings.archiveOlderThanDays);
    
    // First, filter out old, completed requests based on archive settings for admins AND archived requests
    const activeRequests = isAdmin ? userVisibleLeaveRequests.filter(req => {
      if (req.isArchived) return false;
      if (req.status === 'Pending') {
        return true; // Always show pending requests
      }
      // For approved/rejected, check if their end date is within the archive period
      const reqEndDate = parseISO(req.endDate);
      if (!isValid(reqEndDate)) return false; // Don't show records with invalid dates here
      return reqEndDate >= archiveDate;
    }) : userVisibleLeaveRequests.filter(req => !req.isArchived); // Users see all their unarchived requests

    return applyFilters(
        activeRequests,
        approveRequestsSearchTerm,
        approveRequestsStatusFilter,
        approveRequestsLeaveTypeFilter,
        approveRequestsDurationFilter,
        approveRequestsDateRangeFilter
    );
  }, [userVisibleLeaveRequests, approveRequestsSearchTerm, approveRequestsStatusFilter, allEmployees, approveRequestsLeaveTypeFilter, approveRequestsDurationFilter, approveRequestsDateRangeFilter, leaveSettings, isAdmin]);
  
  const filteredAllHistoryRequests = useMemo(() => {
    // For admins, history is all non-pending. For users, it's their entire history.
    const historyRequests = isAdmin ? userVisibleLeaveRequests.filter(req => req.status === 'Approved' || req.status === 'Rejected') : userVisibleLeaveRequests;
    return applyFilters(
        historyRequests,
        allHistorySearchTerm,
        allHistoryStatusFilter,
        allHistoryLeaveTypeFilter,
        allHistoryDurationFilter,
        allHistoryDateRangeFilter
    );
  }, [userVisibleLeaveRequests, allHistorySearchTerm, allHistoryStatusFilter, allEmployees, allHistoryLeaveTypeFilter, allHistoryDurationFilter, allHistoryDateRangeFilter, isAdmin]);


  const activeApproveRequestsFilterCount = useMemo(() => {
    let count = 0;
    if (approveRequestsSearchTerm.trim() !== '') count++;
    if (approveRequestsStatusFilter !== 'Pending') count++;
    if (approveRequestsLeaveTypeFilter !== 'All') count++;
    if (approveRequestsDurationFilter !== 'All Durations') count++;
    if (approveRequestsDateRangeFilter?.from) count++;
    return count;
  }, [approveRequestsSearchTerm, approveRequestsStatusFilter, approveRequestsLeaveTypeFilter, approveRequestsDurationFilter, approveRequestsDateRangeFilter]);

  const activeAllHistoryFilterCount = useMemo(() => {
    let count = 0;
    if (allHistorySearchTerm.trim() !== '') count++;
    if (allHistoryStatusFilter !== 'All') count++;
    if (allHistoryLeaveTypeFilter !== 'All') count++;
    if (allHistoryDurationFilter !== 'All Durations') count++;
    if (allHistoryDateRangeFilter?.from) count++;
    return count;
  }, [allHistorySearchTerm, allHistoryStatusFilter, allHistoryLeaveTypeFilter, allHistoryDurationFilter, allHistoryDateRangeFilter]);


  const handleRequestLeaveSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedEmployeeForLeave) {
      toast({ title: "Error", description: "Please select an employee.", variant: "destructive" });
      return;
    }
    const employeeSubmitting = allEmployees.find(emp => emp.id === selectedEmployeeForLeave);
    if (!employeeSubmitting) {
      toast({ title: "Error", description: "Selected employee not found.", variant: "destructive" });
      return;
    }

    if (!leaveType || !dateRange?.from || !reason) {
      toast({ title: "Error", description: "Please fill all required fields (Leave Type, Date Range, Reason).", variant: "destructive" });
      return;
    }

    // Check leave quota for all leave types
    const entitlement = employeeSubmitting.annualLeaveEntitlement ?? 0;
    const currentYear = new Date().getFullYear();
    const usedLeaveDays = allLeaveRequests
        .filter(req => 
            req.employeeId === selectedEmployeeForLeave &&
            req.status === 'Approved' &&
            isValid(parseISO(req.startDate)) &&
            getYear(parseISO(req.startDate)) === currentYear
        )
        .reduce((total, req) => total + getNumericDuration(parseISO(req.startDate), parseISO(req.endDate)), 0);

    const remainingDays = entitlement - usedLeaveDays;
    const requestedDays = getNumericDuration(dateRange.from, dateRange.to);

    if (requestedDays > remainingDays) {
        toast({
            title: "Insufficient Leave Balance",
            description: `${employeeSubmitting.name} has ${remainingDays} leave day(s) remaining, but is requesting ${requestedDays}. Request cannot be submitted.`,
            variant: "destructive",
            duration: 7000
        });
        return;
    }


    setIsSubmittingLeave(true);
    try {
      const submissionStartDate = dateRange.from;
      const submissionEndDate = dateRange.to || dateRange.from; 

      const newRequestData = {
        employeeId: employeeSubmitting.id,
        employeeName: employeeSubmitting.name, 
        leaveType: leaveType as LeaveRequest['leaveType'],
        startDate: format(submissionStartDate, 'yyyy-MM-dd'),
        endDate: format(submissionEndDate, 'yyyy-MM-dd'),
        reason,
        status: 'Pending' as LeaveRequest['status'],
        appliedDate: format(new Date(), 'yyyy-MM-dd'),
        processedBy: isAdmin ? (user?.displayName || "System") : "User Submission",
        processedByRole: isAdmin ? "Admin" : "User",
        isArchived: false,
      };
      await addDoc(collection(db, "leaveRequests"), newRequestData);
      toast({ title: "Success", description: "Leave request submitted.", variant: 'success' });
      setSelectedEmployeeForLeave(user?.uid); 
      setLeaveType('');
      setDateRange(undefined);
      setReason('');
      setIsRequestLeaveDialogOpen(false);
    } catch (error) {
      console.error("Error submitting leave request:", error);
      toast({ title: "Error", description: "Failed to submit leave request.", variant: "destructive" });
    } finally {
      setIsSubmittingLeave(false);
    }
  };

  const handleAdminAction = async (request: LeaveRequest, newStatus: 'Approved' | 'Rejected', comment?: string) => {
    if (!user || !employeeProfile) return false;

    try {
      const requestRef = doc(db, "leaveRequests", request.id);
      
      const updatePayload: { 
        status: 'Approved' | 'Rejected'; 
        processedBy: string; 
        processedByRole: string;
        approverComment?: string;
      } = { 
        status: newStatus,
        processedBy: employeeProfile.name || "System Admin", 
        processedByRole: "Admin" 
      };

      if (newStatus === 'Rejected' && comment && comment.trim() !== '') {
        updatePayload.approverComment = comment.trim();
      }

      await updateDoc(requestRef, updatePayload);

      // Create an activity log item
      const activityText = newStatus === 'Approved' 
        ? `approved a leave request.`
        : `rejected a leave request.`;
      
      const adminName = employeeProfile.name || "Admin";
      const adminNameParts = adminName.split(' ');
      const adminInitials = (
          adminNameParts.length > 1
          ? `${adminNameParts[0][0]}${adminNameParts[adminNameParts.length - 1][0]}`
          : adminName.substring(0, 2)
      ).toUpperCase();

      await addDoc(collection(db, "activityFeedItems"), {
        text: activityText,
        userId: user.uid,
        userName: employeeProfile.name,
        userRole: employeeProfile.permissionRole || "Administrator",
        avatarUrl: employeeProfile.avatarUrl || "",
        avatarFallback: adminInitials,
        timestamp: new Date(),
        relatedEntityType: 'leave',
        relatedEntityId: request.id,
        details: [
          { label: 'Employee', value: request.employeeName },
          { label: 'Leave Type', value: request.leaveType },
          { label: 'Status', value: newStatus }
        ]
      });

      // Create a notification for the user
      let notificationText = `Your leave request for ${format(parseISO(request.startDate), 'MMM d')} to ${format(parseISO(request.endDate), 'MMM d')} has been ${newStatus.toLowerCase()}.`;
      if (newStatus === 'Rejected' && updatePayload.approverComment) {
        notificationText += ` Reason: ${updatePayload.approverComment}`;
      }
      
      const notificationData = {
        userId: request.employeeId,
        type: newStatus === 'Approved' ? 'success' : 'warning',
        text: notificationText,
        timestamp: new Date(),
        isRead: false,
        link: '/leave',
      };
      await addDoc(collection(db, "notifications"), notificationData);

      return true; // Indicate success
    } catch (error) {
      console.error(`Error updating request ${request.id} to ${newStatus}:`, error);
      return false; // Indicate failure
    }
  };

  const confirmRejection = async () => {
    if (!requestToReject) return;
    const success = await handleAdminAction(requestToReject, 'Rejected', rejectionReason);
    if (success) {
      toast({ title: "Success", description: "Request has been rejected.", variant: 'success' });
    } else {
      toast({ title: "Error", description: "Failed to reject request.", variant: "destructive" });
    }
    // Close dialog and reset state regardless of outcome
    setIsRejectionDialogOpen(false);
    setRequestToReject(null);
    setRejectionReason('');
  };


  const handleBulkAction = async (newStatus: 'Approved' | 'Rejected') => {
    if (selectedRequests.length === 0) {
      toast({ title: "No Selection", description: "Please select requests to process." });
      return;
    }
    setIsBulkProcessing(true);
    let successCount = 0;
    let failCount = 0;
    let skippedCount = 0;

    const requestsToProcess = selectedRequests.map(id => allLeaveRequests.find(req => req.id === id)).filter(Boolean) as LeaveRequest[];
    
    const pendingRequestsToProcess = requestsToProcess.filter(req => req.status === 'Pending');
    skippedCount = requestsToProcess.length - pendingRequestsToProcess.length;

    const promises = pendingRequestsToProcess.map(req => handleAdminAction(req, newStatus));
    const results = await Promise.all(promises);

    results.forEach(success => {
      if (success) successCount++;
      else failCount++;
    });

    let toastDescription = `${successCount} request(s) ${newStatus.toLowerCase()}.`;
    if (failCount > 0) toastDescription += ` ${failCount} failed.`;
    if (skippedCount > 0) toastDescription += ` ${skippedCount} skipped (not pending).`;

    toast({
      title: `Bulk Action: ${newStatus}`,
      description: toastDescription,
      variant: failCount > 0 ? "destructive" : "success",
    });

    setSelectedRequests([]);
    setIsBulkProcessing(false);
  };


  const getStatusBadgeComponent = (status: LeaveRequest['status']) => {
    switch (status) {
      case 'Approved': return <Badge className="bg-green-100 text-green-800 dark:bg-green-700/30 dark:text-green-300 hover:bg-green-200/80">Approved</Badge>;
      case 'Pending': return <Badge variant="secondary">Pending</Badge>;
      case 'Rejected': return <Badge variant="destructive">Rejected</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };


  const handleSelectAll = (checked: boolean | 'indeterminate') => {
    if (checked === true) {
      const pendingIds = filteredApproveRequests
        .filter(req => req.status === 'Pending')
        .map(req => req.id);
      setSelectedRequests(pendingIds);
    } else {
      setSelectedRequests([]);
    }
  };
  
  const handleSelectRow = (id: string, checked: boolean | 'indeterminate') => {
    if (checked) {
        setSelectedRequests(prev => [...prev, id]);
    } else {
        setSelectedRequests(prev => prev.filter(reqId => reqId !== id));
    }
  };


  const handleSaveArchiveSettings = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmittingArchiveSettings(true);
    try {
        const settingsToSave: LeaveSettings = {
            archiveOlderThanDays: archiveDaysInputValue,
        };
        const settingsDocRef = doc(db, 'companySettings', 'leave');
        await setDoc(settingsDocRef, settingsToSave, { merge: true });

        setLeaveSettings(settingsToSave); // Update local state immediately
        toast({ title: "Success", description: "Automatic archiving rule saved.", variant: 'success' });
        setIsArchiveSettingsDialogOpen(false);
    } catch (error) {
        console.error("Error saving leave settings:", error);
        toast({ title: "Error", description: "Failed to save settings.", variant: "destructive" });
    } finally {
        setIsSubmittingArchiveSettings(false);
    }
  };

  const handleArchiveAllRecords = async () => {
    setIsArchivingRecords(true);
    try {
      if (recordsForArchiveAllReview.length === 0) {
        toast({ title: "No Records Found", description: "No historical leave records to archive." });
        setIsArchiveAllReviewDialogOpen(false);
        setIsArchivingRecords(false);
        return;
      }
  
      const batch = writeBatch(db);
      recordsForArchiveAllReview.forEach(req => {
        const docRef = doc(db, "leaveRequests", req.id);
        batch.update(docRef, { isArchived: true });
      });
  
      await batch.commit();
      
      toast({ title: "Success", description: `${recordsForArchiveAllReview.length} historical leave record(s) archived successfully.`, variant: 'success' });
      
      setIsArchiveAllReviewDialogOpen(false);
  
    } catch (error) {
      console.error("Error archiving all leave records:", error);
      toast({ title: "Error", description: "Failed to archive all records. Please try again.", variant: "destructive" });
    } finally {
      setIsArchivingRecords(false);
    }
  };
  
  const openSingleArchiveDialog = (request: LeaveRequest) => {
    setRequestToArchive(request);
    setIsSingleArchiveDialogOpen(true);
  };
  
  const confirmArchiveSingleRecord = async () => {
    if (!requestToArchive) return;
    setIsArchivingRecords(true);
    try {
        await updateDoc(doc(db, "leaveRequests", requestToArchive.id), { isArchived: true });
        toast({
            title: "Record Archived",
            description: `Leave request for ${requestToArchive.employeeName} has been archived.`,
            variant: 'success',
        });
    } catch (error) {
        console.error("Error archiving single leave record:", error);
        toast({ title: "Error", description: "Failed to archive record.", variant: "destructive" });
    } finally {
        setIsArchivingRecords(false);
        setIsSingleArchiveDialogOpen(false);
        setRequestToArchive(null);
    }
  };
  
  const openDeleteLeaveDialog = (request: LeaveRequest) => {
    setRequestToDelete(request);
    setIsDeleteLeaveDialogOpen(true);
  };
  
  const confirmDeleteLeaveRecord = async () => {
    if (!requestToDelete) return;
    try {
      await deleteDoc(doc(db, "leaveRequests", requestToDelete.id));
      toast({
        title: "Record Deleted",
        description: `Leave request for ${requestToDelete.employeeName} has been permanently deleted.`,
        variant: 'success',
      });
    } catch (error) {
      console.error("Error deleting leave record:", error);
      toast({ title: "Error", description: "Failed to delete record.", variant: "destructive" });
    } finally {
      setIsDeleteLeaveDialogOpen(false);
      setRequestToDelete(null);
    }
  };


  const handleResetApproveRequestsFilters = () => {
    setApproveRequestsSearchTerm('');
    setApproveRequestsStatusFilter('Pending');
    setApproveRequestsLeaveTypeFilter('All');
    setApproveRequestsDurationFilter('All Durations');
    setApproveRequestsDateRangeFilter(undefined);
    setShowApproveRequestsAdvancedFilters(false);
    toast({ title: "Filters Reset", description: "Filters for 'Approve Requests' have been reset."});
  };
  
  const handleResetAllHistoryFilters = () => {
    setAllHistorySearchTerm('');
    setAllHistoryStatusFilter('All');
    setAllHistoryLeaveTypeFilter('All');
    setAllHistoryDurationFilter('All Durations');
    setAllHistoryDateRangeFilter(undefined);
    setShowAllHistoryAdvancedFilters(false);
    toast({ title: "Filters Reset", description: "Filters for 'All History' have been reset."});
  };

  const pendingRequestsInView = useMemo(() => 
    filteredApproveRequests.filter(req => req.status === 'Pending'), 
    [filteredApproveRequests]
  );
  
  const isAllSelected = pendingRequestsInView.length > 0 && selectedRequests.length === pendingRequestsInView.length && pendingRequestsInView.every(p => selectedRequests.includes(p.id));
  const isSomeSelected = selectedRequests.length > 0 && !isAllSelected;

  const isLoading = authLoading || isLoadingAllRequests || isLoadingEmployees || isLoadingLeaveSettings;

  const leaveTypeOptions = ["All", "Annual", "Sick", "Unpaid", "Maternity", "Paternity", "Personal"];
  const durationOptions = ["All Durations", "Single Day", "2-5 Days", "6-10 Days", "More than 10 days"];

  const handleDoneClick = () => {
      setDateRange(tempDateRange);
      setIsDatePopoverOpen(false);
  };

  const handleCancelClick = () => {
      setIsDatePopoverOpen(false);
  };
  
  const handleEmployeeNameClick = (employeeId: string) => {
    const employee = allEmployees.find(e => e.id === employeeId);
    if(employee) {
        setEmployeeForBalanceView(employee);
    }
  };


  return (
    <>
      <PageHeader
        icon={<Plane className="h-7 w-7 text-primary" />}
        title="Leave Management"
        description={isAdmin ? "Review employee leave applications. Manage your leave requests, view balances, and the company calendar." : "Apply for leave, manage your requests and view your history."}
        actions={
          <div className="flex gap-2">
            {isAdmin && (
              <Button variant="outline" onClick={() => setIsArchiveSettingsDialogOpen(true)}>
                <SettingsIcon className="mr-2 h-4 w-4" /> Auto-Archive Rule
              </Button>
            )}
            <Button onClick={() => {
                setSelectedEmployeeForLeave(user?.uid); 
                setLeaveType('');
                setDateRange(undefined);
                setReason('');
                setIsRequestLeaveDialogOpen(true);
              }}>
              <PlusCircle className="mr-2 h-4 w-4" /> Request Leave
            </Button>
          </div>
        }
      />

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="approveRequests"><CheckCircle2 className="h-4 w-4" />{isAdmin ? "Approve Requests" : "My Requests"}</TabsTrigger>
          <TabsTrigger value="allHistory"><History className="h-4 w-4" />All History</TabsTrigger>
        </TabsList>

        <TabsContent value="approveRequests">
          <Card>
            <CardHeader>
              <div className="flex flex-col gap-4">
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="relative w-full sm:flex-grow">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={isAdmin ? "Search by employee name or leave type..." : "Search by leave type..."}
                      value={approveRequestsSearchTerm}
                      onChange={(e) => setApproveRequestsSearchTerm(e.target.value)}
                      className="pl-10 w-full"
                    />
                  </div>
                  <Button variant="outline" className="w-full sm:w-auto flex items-center" onClick={() => setShowApproveRequestsAdvancedFilters(!showApproveRequestsAdvancedFilters)}>
                    <Filter className="mr-2 h-4 w-4" />
                    <span className="mr-1.5">Filters</span>
                    {activeApproveRequestsFilterCount > 0 && (
                        <Badge
                        variant="default"
                        className="h-5 w-5 p-0 flex items-center justify-center rounded-full text-xs"
                        >
                        {activeApproveRequestsFilterCount}
                        </Badge>
                    )}
                  </Button>
                  <Select value={approveRequestsStatusFilter} onValueChange={setApproveRequestsStatusFilter} >
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pending">Pending</SelectItem>
                      <SelectItem value="Approved">Approved</SelectItem>
                      <SelectItem value="Rejected">Rejected</SelectItem>
                      <SelectItem value="All">All Statuses</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {showApproveRequestsAdvancedFilters && (
                  <div className="pt-4 border-t space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="approveRequestsLeaveTypeFilterAdv">Leave Type</Label>
                        <Select value={approveRequestsLeaveTypeFilter} onValueChange={setApproveRequestsLeaveTypeFilter}>
                          <SelectTrigger id="approveRequestsLeaveTypeFilterAdv">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {leaveTypeOptions.map(opt => (
                              <SelectItem key={opt} value={opt}>{opt === "All" ? "All Leave Types" : opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="approveRequestsDurationFilterAdv">Duration</Label>
                        <Select value={approveRequestsDurationFilter} onValueChange={setApproveRequestsDurationFilter}>
                          <SelectTrigger id="approveRequestsDurationFilterAdv">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {durationOptions.map(opt => (
                              <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="approveRequestsDateRangeFilterAdv">Date Range</Label>
                        <DatePicker
                          id="approveRequestsDateRangeFilterAdv"
                          mode="range"
                          selected={approveRequestsDateRangeFilter}
                          onSelect={setApproveRequestsDateRangeFilter}
                          placeholder="Pick a date range"
                          buttonClassName="w-full"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <Button variant="link" onClick={handleResetApproveRequestsFilters}>
                        <RotateCcw className="mr-2 h-4 w-4" /> Reset Filters
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent> 
               {isAdmin && selectedRequests.length > 0 && (
                <div className="bg-muted/50 p-3 rounded-md my-4 flex flex-col sm:flex-row justify-between items-center gap-3 sm:gap-4">
                  <span className="text-sm font-medium text-foreground">
                    {selectedRequests.length} request(s) selected
                  </span>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedRequests([])}
                      disabled={isBulkProcessing}
                    >
                      <XCircle className="mr-2 h-4 w-4" /> Deselect All
                    </Button>
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => handleBulkAction('Approved')}
                      disabled={isBulkProcessing}
                    >
                      {isBulkProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <ShieldCheck className="mr-2 h-4 w-4" />}
                      Approve Selected
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleBulkAction('Rejected')}
                      disabled={isBulkProcessing}
                    >
                     {isBulkProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <AlertTriangle className="mr-2 h-4 w-4" />}
                      Reject Selected
                    </Button>
                  </div>
                </div>
              )}
              {isLoading ? (
                 <div className="flex items-center justify-center h-60">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <p className="ml-2 text-muted-foreground">Loading requests...</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      {isAdmin && (
                        <TableHead className="w-[50px]">
                          <Checkbox
                            checked={isAllSelected ? true : (isSomeSelected ? 'indeterminate' : false)}
                            onCheckedChange={handleSelectAll}
                            disabled={isBulkProcessing || pendingRequestsInView.length === 0}
                          />
                        </TableHead>
                      )}
                      {isAdmin && <TableHead>Employee</TableHead>}
                      <TableHead>Leave Type</TableHead>
                      <TableHead>Dates</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredApproveRequests.length > 0 ? filteredApproveRequests.map(req => (
                      <TableRow key={req.id}>
                        {isAdmin && (
                            <TableCell>
                            <Checkbox
                                checked={selectedRequests.includes(req.id)}
                                onCheckedChange={(checked) => handleSelectRow(req.id, checked)}
                                disabled={isBulkProcessing || req.status !== 'Pending'}
                            />
                            </TableCell>
                        )}
                        {isAdmin && <TableCell><button className="font-medium text-primary hover:underline" onClick={() => handleEmployeeNameClick(req.employeeId)}>{getEmployeeNameById(req.employeeId)}</button></TableCell>}
                        <TableCell>{req.leaveType}</TableCell>
                        <TableCell>{format(parseISO(req.startDate), "MMM d, yyyy")} - {format(parseISO(req.endDate), "MMM d, yyyy")}</TableCell>
                        <TableCell>{calculateDuration(req.startDate, req.endDate)}</TableCell>
                        <TableCell className="truncate max-w-xs">{req.reason}</TableCell>
                        <TableCell>{getStatusBadgeComponent(req.status)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" disabled={isBulkProcessing}><MoreHorizontal className="h-4 w-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => {
                                    setSelectedRequestForDetails(req);
                                    setIsViewDetailsDialogOpen(true);
                                    }}
                                    disabled={isBulkProcessing}
                                >
                                    <Eye className="mr-2 h-4 w-4" /> View Details
                                </DropdownMenuItem>
                                {isAdmin && req.status === 'Pending' && (
                                    <DropdownMenuItem 
                                        onClick={async () => { 
                                            const success = await handleAdminAction(req, 'Approved'); 
                                            if(success) toast({ title: "Success", description: "Request has been approved.", variant: 'success'});
                                            else toast({ title: "Error", description: "Failed to approve request.", variant: "destructive"});
                                        }}
                                        disabled={isBulkProcessing}
                                    >
                                        <CheckCircle2 className="mr-2 h-4 w-4" /> Approve
                                    </DropdownMenuItem>
                                )}
                                {isAdmin && req.status === 'Pending' && (
                                    <DropdownMenuItem 
                                        onClick={() => {
                                           setRequestToReject(req);
                                           setRejectionReason(''); // Clear previous reason
                                           setIsRejectionDialogOpen(true);
                                        }}
                                        className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                        disabled={isBulkProcessing}
                                    >
                                        <XCircle className="mr-2 h-4 w-4" /> Reject
                                    </DropdownMenuItem>
                                )}
                                {!isAdmin && (
                                  <DropdownMenuItem disabled>No actions available</DropdownMenuItem>
                                )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )) : <TableRow><TableCell colSpan={isAdmin ? 8 : 6} className="text-center h-24">No leave requests found for the current filter.</TableCell></TableRow>}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="allHistory">
           <Card>
            <CardHeader>
               <div className="flex flex-col gap-4">
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="relative w-full sm:flex-grow">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={isAdmin ? "Search by employee name or leave type..." : "Search by leave type..."}
                      value={allHistorySearchTerm}
                      onChange={(e) => setAllHistorySearchTerm(e.target.value)}
                      className="pl-10 w-full"
                    />
                  </div>
                  <Button variant="outline" className="w-full sm:w-auto flex items-center" onClick={() => setShowAllHistoryAdvancedFilters(!showAllHistoryAdvancedFilters)}>
                    <Filter className="mr-2 h-4 w-4" />
                    <span className="mr-1.5">Filters</span>
                    {activeAllHistoryFilterCount > 0 && (
                        <Badge
                        variant="default"
                        className="h-5 w-5 p-0 flex items-center justify-center rounded-full text-xs"
                        >
                        {activeAllHistoryFilterCount}
                        </Badge>
                    )}
                  </Button>
                  <Select value={allHistoryStatusFilter} onValueChange={setAllHistoryStatusFilter} >
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All">All Statuses</SelectItem>
                      <SelectItem value="Approved">Approved</SelectItem>
                      <SelectItem value="Rejected">Rejected</SelectItem>
                      {isAdmin && <SelectItem value="Pending">Pending</SelectItem>}
                    </SelectContent>
                  </Select>
                  {isAdmin && (
                    <Button variant="outline" className="w-full sm:w-auto" onClick={() => setIsArchiveAllReviewDialogOpen(true)}>
                      <Archive className="mr-2 h-4 w-4" />
                      Archive All
                    </Button>
                  )}
                </div>
                {showAllHistoryAdvancedFilters && (
                  <div className="pt-4 border-t space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="allHistoryLeaveTypeFilterAdv">Leave Type</Label>
                        <Select value={allHistoryLeaveTypeFilter} onValueChange={setAllHistoryLeaveTypeFilter}>
                          <SelectTrigger id="allHistoryLeaveTypeFilterAdv">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {leaveTypeOptions.map(opt => (
                              <SelectItem key={opt} value={opt}>{opt === "All" ? "All Leave Types" : opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="allHistoryDurationFilterAdv">Duration</Label>
                        <Select value={allHistoryDurationFilter} onValueChange={setAllHistoryDurationFilter}>
                          <SelectTrigger id="allHistoryDurationFilterAdv">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {durationOptions.map(opt => (
                              <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="allHistoryDateRangeFilterAdv">Date Range</Label>
                        <DatePicker
                          id="allHistoryDateRangeFilterAdv"
                          mode="range"
                          selected={allHistoryDateRangeFilter}
                          onSelect={setAllHistoryDateRangeFilter}
                          placeholder="Pick a date range"
                          buttonClassName="w-full"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <Button variant="link" onClick={handleResetAllHistoryFilters}>
                        <RotateCcw className="mr-2 h-4 w-4" /> Reset Filters
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                 <div className="flex items-center justify-center h-60">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <p className="ml-2 text-muted-foreground">Loading history...</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      {isAdmin && <TableHead>Employee</TableHead>}
                      <TableHead>Leave Type</TableHead>
                      <TableHead>Dates</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Processed By</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAllHistoryRequests.length > 0 ? filteredAllHistoryRequests.map(req => (
                      <TableRow key={req.id}>
                        {isAdmin && <TableCell><button className="font-medium text-primary hover:underline" onClick={() => handleEmployeeNameClick(req.employeeId)}>{getEmployeeNameById(req.employeeId)}</button></TableCell>}
                        <TableCell>{req.leaveType}</TableCell>
                        <TableCell>{format(parseISO(req.startDate), "MMM d, yyyy")} - {format(parseISO(req.endDate), "MMM d, yyyy")}</TableCell>
                        <TableCell>{calculateDuration(req.startDate, req.endDate)}</TableCell>
                        <TableCell className="truncate max-w-xs">{req.reason}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                           {getStatusBadgeComponent(req.status)}
                           {req.isArchived && <Badge variant="outline">Archived</Badge>}
                          </div>
                        </TableCell>
                        <TableCell>
                          {req.processedBy || 'N/A'}
                          {req.processedByRole && <span className="text-muted-foreground text-xs ml-1">({req.processedByRole})</span>}
                        </TableCell>
                        <TableCell className="text-right">
                           <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => {
                                  setSelectedRequestForDetails(req);
                                  setIsViewDetailsDialogOpen(true);
                                }}>
                                  <Eye className="mr-2 h-4 w-4" /> View Details
                                </DropdownMenuItem>
                                {isAdmin && !req.isArchived && (
                                  <DropdownMenuItem
                                    onClick={() => openSingleArchiveDialog(req)}
                                  >
                                    <Archive className="mr-2 h-4 w-4" /> Archive
                                  </DropdownMenuItem>
                                )}
                                {isAdmin && req.isArchived && (
                                  <DropdownMenuItem
                                    className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                    onClick={() => openDeleteLeaveDialog(req)}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete Permanently
                                  </DropdownMenuItem>
                                )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )) : <TableRow><TableCell colSpan={isAdmin ? 8 : 7} className="text-center h-24">No leave history found for the current filter.</TableCell></TableRow>}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Request Leave Dialog */}
      <Dialog open={isRequestLeaveDialogOpen} onOpenChange={setIsRequestLeaveDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Apply for Leave</DialogTitle>
            <DialogDescription>Fill out the form below to request time off.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRequestLeaveSubmit} className="space-y-4 py-2">
            {isAdmin && (
             <div>
                <Label htmlFor="employeeDlg" className="block text-sm font-medium mb-1">Employee</Label>
                <Select
                  value={selectedEmployeeForLeave}
                  onValueChange={setSelectedEmployeeForLeave}
                  disabled={isLoadingEmployees || isSubmittingLeave}
                >
                    <SelectTrigger id="employeeDlg" className="mt-1">
                        <SelectValue placeholder="Select an employee" />
                    </SelectTrigger>
                    <SelectContent>
                      {isLoadingEmployees ? (
                        <SelectItem value="loading" disabled>Loading employees...</SelectItem>
                      ) : (
                        allEmployees.map(emp => (
                          <SelectItem key={emp.id} value={emp.id}>
                            {emp.name} {user?.uid === emp.id ? "(Yourself)" : ""}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                </Select>
             </div>
             )}
             <div>
                <Label htmlFor="leaveTypeDlg" className="block text-sm font-medium mb-1">Leave Type</Label>
                <Select value={leaveType} onValueChange={setLeaveType} disabled={isSubmittingLeave}>
                    <SelectTrigger id="leaveTypeDlg"><SelectValue placeholder="Select leave type" /></SelectTrigger>
                    <SelectContent>
                      {leaveTypeOptions.filter(lt => lt !== "All").map(type => (
                         <SelectItem key={type} value={type}>{type} Leave</SelectItem>
                      ))}
                    </SelectContent>
                </Select>
             </div>
             <div>
                <Label htmlFor="dateRangeDlg" className="block text-sm font-medium mb-1">Date Range</Label>
                <Popover open={isDatePopoverOpen} onOpenChange={setIsDatePopoverOpen}>
                  <PopoverTrigger asChild>
                      <Button
                          id="dateRangeDlg"
                          variant={"outline"}
                          className={cn(
                              "w-full justify-start text-left font-normal",
                              !dateRange && "text-muted-foreground"
                          )}
                          disabled={isSubmittingLeave}
                      >
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {dateRange?.from ? (
                              dateRange.to ? (
                                  <>
                                      {format(dateRange.from, "d LLL, y")} -{" "}
                                      {format(dateRange.to, "d LLL, y")}
                                  </>
                              ) : (
                                  format(dateRange.from, "d LLL, y")
                              )
                          ) : (
                              <span>Pick a date range</span>
                          )}
                      </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                          initialFocus
                          mode="range"
                          defaultMonth={tempDateRange?.from}
                          selected={tempDateRange}
                          onSelect={setTempDateRange}
                          numberOfMonths={2}
                          disabled={{ before: new Date() }}
                      />
                      <div className="flex items-center justify-between p-3 border-t">
                          <p className="text-sm font-medium text-muted-foreground">
                              {tempDateRange?.from && tempDateRange.to ? (
                                  <strong>{`${differenceInCalendarDays(tempDateRange.to, tempDateRange.from) + 1} days`}</strong>
                              ) : tempDateRange?.from ? (
                                  'Select the end date.'
                              ) : (
                                  'Select the start date.'
                              )}
                          </p>
                          <div className="flex gap-2">
                              <Button variant="ghost" onClick={handleCancelClick}>Cancel</Button>
                              <Button onClick={handleDoneClick}>Done</Button>
                          </div>
                      </div>
                  </PopoverContent>
              </Popover>
             </div>
             <div>
                <Label htmlFor="reasonDlg" className="block text-sm font-medium mb-1">Reason</Label>
                <Textarea id="reasonDlg" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Provide a brief reason for your leave request..." rows={3} disabled={isSubmittingLeave} />
             </div>
            <DialogFooter className="pt-2">
                <DialogClose asChild><Button type="button" variant="outline" disabled={isSubmittingLeave}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button></DialogClose>
                <Button type="submit" disabled={isSubmittingLeave || isLoadingEmployees}>
                {isSubmittingLeave ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                {isSubmittingLeave ? 'Submitting...' : 'Submit Request'}
                </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      <Dialog open={!!employeeForBalanceView} onOpenChange={(isOpen) => !isOpen && setEmployeeForBalanceView(null)}>
        <DialogContent>
          {leaveBalance && (
            <>
              <DialogHeader>
                <DialogTitle>Leave Balance for {leaveBalance.employeeName}</DialogTitle>
                <DialogDescription>
                  Annual leave summary for the current year ({getYear(new Date())}).
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center py-4">
                <div className="p-4 rounded-lg bg-blue-100 dark:bg-blue-900/40">
                  <div className="flex items-center justify-center gap-2">
                    <TrendingUp className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Total Entitlement</p>
                  </div>
                  <p className="text-2xl font-bold mt-1">{leaveBalance.entitlement} Days</p>
                </div>
                <div className="p-4 rounded-lg bg-yellow-100 dark:bg-yellow-900/40">
                  <div className="flex items-center justify-center gap-2">
                    <TrendingDown className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                    <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">Leaves Used</p>
                  </div>
                  <p className="text-2xl font-bold mt-1">{leaveBalance.used} Days</p>
                </div>
                <div className="p-4 rounded-lg bg-green-100 dark:bg-green-900/40">
                  <div className="flex items-center justify-center gap-2">
                    <Circle className="h-5 w-5 text-green-600 dark:text-green-400" />
                    <p className="text-sm font-medium text-green-800 dark:text-green-300">Leaves Remaining</p>
                  </div>
                  <p className="text-2xl font-bold mt-1">{leaveBalance.remaining} Days</p>
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" variant="outline">
                    <XCircle className="mr-2 h-4 w-4"/>Close
                  </Button>
                </DialogClose>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>


      {/* Auto-Archive Rule Dialog */}
      <Dialog open={isArchiveSettingsDialogOpen} onOpenChange={setIsArchiveSettingsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Auto-Archive Rule</DialogTitle>
            <DialogDescription>
              This rule automatically hides old, completed leave requests from the main "Approve Requests" view to keep the list tidy. Archived records are always visible in "All History".
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSaveArchiveSettings} className="space-y-4 py-2">
            <div>
              <Label htmlFor="archiveDaysInput" className="text-sm font-medium">Auto-archive leaves completed more than (days ago):</Label>
              <Input
                id="archiveDaysInput"
                type="number"
                value={archiveDaysInputValue}
                onChange={(e) => setArchiveDaysInputValue(parseInt(e.target.value, 10) || 0)}
                className="mt-1"
                min="0"
                disabled={isSubmittingArchiveSettings}
              />
              <p className="mt-1.5 text-xs text-muted-foreground">
                For example, 365 means leaves completed over a year ago will be hidden.
              </p>
            </div>
            <DialogFooter className="pt-2">
              <DialogClose asChild>
                <Button type="button" variant="outline" disabled={isSubmittingArchiveSettings}>
                    <XCircle className="mr-2 h-4 w-4"/>Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSubmittingArchiveSettings || isLoadingLeaveSettings}>
                {isSubmittingArchiveSettings ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <SettingsIcon className="mr-2 h-4 w-4" />}
                {isSubmittingArchiveSettings ? 'Saving...' : 'Save Rule'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Details Dialog */}
      <Dialog open={isViewDetailsDialogOpen} onOpenChange={setIsViewDetailsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Leave Request Details</DialogTitle>
            {selectedRequestForDetails && (
              <DialogDescription>
                Details for {getEmployeeNameById(selectedRequestForDetails.employeeId)}
                {user?.uid === selectedRequestForDetails.employeeId ? " (User)" : ""}'s leave request.
              </DialogDescription>
            )}
          </DialogHeader>
          {selectedRequestForDetails && (
            <div className="space-y-3 py-4">
              <div className="grid grid-cols-[100px_1fr] items-center gap-2">
                <Label className="text-right font-semibold text-muted-foreground">Employee:</Label>
                <span>
                  {getEmployeeNameById(selectedRequestForDetails.employeeId)}
                  {user?.uid === selectedRequestForDetails.employeeId ? " (User)" : ""}
                </span>
              </div>
              <div className="grid grid-cols-[100px_1fr] items-center gap-2">
                <Label className="text-right font-semibold text-muted-foreground">Leave Type:</Label>
                <span>{selectedRequestForDetails.leaveType}</span>
              </div>
              <div className="grid grid-cols-[100px_1fr] items-center gap-2">
                <Label className="text-right font-semibold text-muted-foreground">Dates:</Label>
                <span>
                  {format(parseISO(selectedRequestForDetails.startDate), "MMMM do, yyyy")} to {format(parseISO(selectedRequestForDetails.endDate), "MMMM do, yyyy")}
                </span>
              </div>
              <div className="grid grid-cols-[100px_1fr] items-center gap-2">
                <Label className="text-right font-semibold text-muted-foreground">Duration:</Label>
                <span>{calculateDuration(selectedRequestForDetails.startDate, selectedRequestForDetails.endDate)}</span>
              </div>
              <div className="grid grid-cols-[100px_1fr] items-start gap-2">
                <Label className="text-right font-semibold text-muted-foreground pt-0.5">Reason:</Label>
                <span className="whitespace-pre-wrap">{selectedRequestForDetails.reason}</span>
              </div>
              <div className="grid grid-cols-[100px_1fr] items-center gap-2">
                <Label className="text-right font-semibold text-muted-foreground">Status:</Label>
                <div>{getStatusBadgeComponent(selectedRequestForDetails.status)}</div>
              </div>
               {selectedRequestForDetails.status === 'Rejected' && selectedRequestForDetails.approverComment && (
                 <div className="grid grid-cols-[100px_1fr] items-start gap-2 pt-2 border-t mt-2">
                    <Label className="text-right font-semibold text-destructive/80 pt-0.5">Admin Note:</Label>
                    <p className="whitespace-pre-wrap text-destructive bg-destructive/10 p-2 rounded-md">{selectedRequestForDetails.approverComment}</p>
                  </div>
              )}
            </div>
          )}
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline"><XCircle className="mr-2 h-4 w-4"/>Close</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Archive All Review and Confirmation Dialog */}
      <Dialog open={isArchiveAllReviewDialogOpen} onOpenChange={setIsArchiveAllReviewDialogOpen}>
          <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                  <DialogTitle>Review Records for Archiving</DialogTitle>
                  <DialogDescription>
                      The following {recordsForArchiveAllReview.length > 0 ? recordsForArchiveAllReview.length : ''} historical records (Approved/Rejected) will be archived. They will still be visible in the history view.
                  </DialogDescription>
              </DialogHeader>
              <div className="my-4">
                  {isLoadingArchiveAllReview ? (
                      <div className="flex items-center justify-center h-40">
                          <Loader2 className="h-8 w-8 animate-spin text-primary" />
                          <p className="ml-2 text-muted-foreground">Loading records...</p>
                      </div>
                  ) : recordsForArchiveAllReview.length > 0 ? (
                      <ScrollArea className="h-60 rounded-md border p-2">
                          <ul className="space-y-1">
                              {recordsForArchiveAllReview.map(req => (
                                  <li key={req.id} className="text-sm p-1 rounded flex justify-between items-center">
                                      <span>{getEmployeeNameById(req.employeeId)}: {req.leaveType}</span>
                                      <span className="text-xs text-muted-foreground">{format(parseISO(req.startDate), "MMM d")} - {format(parseISO(req.endDate), "MMM d")}</span>
                                  </li>
                              ))}
                          </ul>
                      </ScrollArea>
                  ) : (
                      <div className="text-center text-muted-foreground py-10">
                          No historical records found to archive.
                      </div>
                  )}
              </div>
              <DialogFooter>
                  <DialogClose asChild>
                      <Button variant="outline" disabled={isArchivingRecords}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button>
                  </DialogClose>
                  <Button
                      variant="destructive"
                      onClick={handleArchiveAllRecords}
                      disabled={isArchivingRecords || isLoadingArchiveAllReview || recordsForArchiveAllReview.length === 0}
                  >
                      {isArchivingRecords ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Archive className="mr-2 h-4 w-4" />}
                      {isArchivingRecords ? 'Archiving...' : `Archive ${recordsForArchiveAllReview.length} Record(s)`}
                  </Button>
              </DialogFooter>
          </DialogContent>
      </Dialog>

      {/* Single Record Archive Confirmation Dialog */}
      <AlertDialog open={isSingleArchiveDialogOpen} onOpenChange={setIsSingleArchiveDialogOpen}>
          <AlertDialogContent>
              <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                      This will archive the leave request for{' '}
                      <span className="font-semibold">{requestToArchive?.employeeName}</span> from{' '}
                      <span className="font-semibold">{requestToArchive ? format(parseISO(requestToArchive.startDate), 'MMM d, yyyy') : ''}</span> to{' '}
                      <span className="font-semibold">{requestToArchive ? format(parseISO(requestToArchive.endDate), 'MMM d, yyyy') : ''}</span>. It will be hidden from the main view but remain in the history.
                  </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setRequestToArchive(null)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                      onClick={confirmArchiveSingleRecord}
                      disabled={isArchivingRecords}
                  >
                      {isArchivingRecords ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Archive className="mr-2 h-4 w-4"/>}
                      Archive
                  </AlertDialogAction>
              </AlertDialogFooter>
          </AlertDialogContent>
      </AlertDialog>
      
      {/* Delete Leave Record Confirmation Dialog */}
      <AlertDialog open={isDeleteLeaveDialogOpen} onOpenChange={setIsDeleteLeaveDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the leave request for{' '}
              <span className="font-semibold">{requestToDelete?.employeeName}</span>. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeleteLeaveDialogOpen(false)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteLeaveRecord}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              <Trash2 className="mr-2 h-4 w-4"/> Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Rejection Reason Dialog */}
      <Dialog open={isRejectionDialogOpen} onOpenChange={(isOpen) => {
        if (!isOpen) {
          setRequestToReject(null);
          setRejectionReason('');
        }
        setIsRejectionDialogOpen(isOpen);
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Leave Request</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting the leave request for <span className="font-semibold">{requestToReject?.employeeName}</span>. This will be visible to the employee.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-2">
            <Label htmlFor="rejectionReason">Rejection Reason (Optional)</Label>
            <Textarea
              id="rejectionReason"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="e.g., Critical project deadline, insufficient staffing..."
              rows={3}
            />
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline"><XCircle className="mr-2 h-4 w-4"/>Cancel</Button>
            </DialogClose>
            <Button variant="destructive" onClick={confirmRejection}>
              <AlertTriangle className="mr-2 h-4 w-4"/> Confirm Rejection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
    
