
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, Trash2, Mail, ArrowLeft, Loader2, DollarSign, Plane, LifeBuoy, Megaphone } from 'lucide-react';
import type { NotificationItem } from '@/types';
import { cn } from '@/lib/utils';
import { db } from '@/lib/firebase';
import { collection, query, orderBy, onSnapshot, writeBatch, doc, deleteDoc, where } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth-context';
import { formatDistanceToNow, isValid } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const notificationsCollection = collection(db, "notifications");
    const q = query(
      notificationsCollection,
      where("userId", "==", user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedNotifications = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as NotificationItem));
      
      fetchedNotifications.sort((a, b) => {
        const timeA = a.timestamp?.toDate ? a.timestamp.toDate().getTime() : 0;
        const timeB = b.timestamp?.toDate ? b.timestamp.toDate().getTime() : 0;
        return timeB - timeA;
      });

      setNotifications(fetchedNotifications);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching notifications:", error);
      toast({
        title: "Error",
        description: "Could not fetch your notifications.",
        variant: "destructive",
      });
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, toast]);

  const markAllAsRead = async () => {
    if (!user) return;
    const unreadNotifications = notifications.filter(n => !n.isRead);
    if (unreadNotifications.length === 0) return;

    const batch = writeBatch(db);
    unreadNotifications.forEach(notification => {
      const docRef = doc(db, "notifications", notification.id);
      batch.update(docRef, { isRead: true });
    });

    try {
      await batch.commit();
      toast({ title: "Success", description: "All notifications marked as read.", variant: 'success' });
    } catch (error) {
       console.error("Error marking all as read:", error);
       toast({ title: "Error", description: "Could not mark all notifications as read.", variant: "destructive" });
    }
  };

  const clearAll = async () => {
    if (!user || notifications.length === 0) return;
    
    const batch = writeBatch(db);
    notifications.forEach(notification => {
        const notificationRef = doc(db, 'notifications', notification.id);
        batch.delete(notificationRef);
    });

    try {
      await batch.commit();
      toast({ title: "Success", description: "All your notifications have been cleared.", variant: 'success' });
    } catch (error) {
      console.error("Error clearing notifications:", error);
      toast({ title: "Error", description: "Could not clear all notifications.", variant: "destructive" });
    }
  };
  
  const handleNotificationClick = async (notification: NotificationItem) => {
    if (!notification.isRead) {
      try {
        await doc(db, "notifications", notification.id).update({ isRead: true });
      } catch (error) {
        console.warn("Could not mark notification as read on click:", error);
      }
    }
    if (notification.link) {
      router.push(notification.link);
    }
  };

  const formatTimestamp = (timestamp: any): string => {
    if (!timestamp) return 'Just now';
    let date: Date;
    if (timestamp?.toDate && typeof timestamp.toDate === 'function') {
      date = timestamp.toDate();
    } else {
      date = new Date(timestamp);
    }
    
    if (!isValid(date)) return 'Invalid date';

    return formatDistanceToNow(date, { addSuffix: true });
  };
  
  const getNotificationIcon = (link?: string) => {
    const iconClass = "h-5 w-5 text-white";
    if (link?.includes('announcement')) {
      return <Megaphone className={iconClass} />;
    }
    switch (link) {
      case '/payroll':
        return <DollarSign className={iconClass} />;
      case '/leave':
        return <Plane className={iconClass} />;
      case '/help-desk':
        return <LifeBuoy className={iconClass} />;
      default:
        return <Bell className={iconClass} />;
    }
  };

  const getIconBgClass = (type: NotificationItem['type']) => {
    switch (type) {
      case 'success':
        return "bg-green-500";
      case 'warning':
        return "bg-amber-500";
      case 'info':
      default:
        return "bg-blue-500";
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <>
      <PageHeader
        icon={<Bell className="h-7 w-7 text-primary" />}
        title="All Notifications"
        description="View and manage all your past notifications."
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => router.back()}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            <Button variant="outline" onClick={markAllAsRead} disabled={unreadCount === 0 || loading}>
              <Mail className="mr-2 h-4 w-4" /> Mark All as Read
            </Button>
            <Button variant="destructive" onClick={clearAll} disabled={notifications.length === 0 || loading}>
              <Trash2 className="mr-2 h-4 w-4" /> Clear All
            </Button>
          </div>
        }
      />
      <Card>
        <CardContent className="p-0">
          {loading ? (
             <ul className="divide-y divide-border">
              {[...Array(5)].map((_, i) => (
                <li key={i} className="p-4 flex items-start gap-4">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <div className="flex-grow space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-3 w-1/4" />
                  </div>
                </li>
              ))}
            </ul>
          ) : notifications.length > 0 ? (
            <ul className="divide-y divide-border">
              {notifications.map(notification => (
                <li
                  key={notification.id}
                  className={cn(
                    "flex items-start gap-4 p-4 transition-colors",
                    !notification.isRead && "bg-primary/5",
                    notification.link && "cursor-pointer hover:bg-muted/50"
                  )}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <div className={cn(
                        "flex h-8 w-8 shrink-0 items-center justify-center rounded-full mt-1",
                        getIconBgClass(notification.type)
                      )}>
                    {getNotificationIcon(notification.link)}
                  </div>
                  <div className="flex-grow">
                    <p className={cn("text-sm", !notification.isRead && "font-semibold")}>{notification.text}</p>
                    <p className={cn("text-xs mt-1", !notification.isRead ? 'text-primary' : 'text-muted-foreground')}>
                      {formatTimestamp(notification.timestamp)}
                    </p>
                  </div>
                  {!notification.isRead && (
                    <div className="h-2.5 w-2.5 rounded-full bg-primary mt-2" />
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center p-12 text-muted-foreground">
              <Bell className="mx-auto h-12 w-12 mb-4" />
              <p className="font-semibold">No notifications</p>
              <p>You're all caught up!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
