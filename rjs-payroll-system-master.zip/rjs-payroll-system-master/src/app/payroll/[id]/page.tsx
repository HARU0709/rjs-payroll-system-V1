

'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { PageHeader } from '@/components/shared/page-header';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Loader2, Eye, MoreHorizontal, Printer, Mail, Archive, Trash2, XCircle, DollarSign, FileText, AlertTriangle } from 'lucide-react';
import type { Employee, Payslip, PayrollSettings } from '@/types';
import { format, parseISO } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/firebase';
import { collection, query, where, orderBy, onSnapshot, doc, updateDoc, deleteDoc, getDoc } from 'firebase/firestore';
import { useAuth } from '@/contexts/auth-context';
import { cn } from '@/lib/utils';

const formatCurrency = (amount: number | undefined | null, currencySymbol = 'PHP') => {
  if (amount === undefined || amount === null) return 'N/A';
  return new Intl.NumberFormat('en-PH', { style: 'currency', currency: currencySymbol }).format(amount);
};

export default function PayslipHistoryPage() {
  const params = useParams();
  const router = useRouter();
  const employeeId = params.id as string;
  const { toast } = useToast();
  const { user, employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';

  const [employee, setEmployee] = useState<Employee | null>(null);
  const [payslips, setPayslips] = useState<Payslip[]>([]);
  const [loading, setLoading] = useState(true);

  // State for View Payslips Dialog
  const [showArchivedPayslips, setShowArchivedPayslips] = useState(false);
  
  // State for Archive Payslip Confirmation Dialog
  const [isArchivePayslipDialogOpen, setIsArchivePayslipDialogOpen] = useState(false);
  const [payslipToArchive, setPayslipToArchive] = useState<Payslip | null>(null);
  
  // State for Delete Payslip Confirmation Dialog
  const [isDeletePayslipDialogOpen, setIsDeletePayslipDialogOpen] = useState(false);
  const [payslipToDelete, setPayslipToDelete] = useState<Payslip | null>(null);

  // State for Payslip Detail Dialog
  const [isPayslipDetailDialogOpen, setIsPayslipDetailDialogOpen] = useState(false);
  const [payslipForDetailView, setPayslipForDetailView] = useState<Payslip | null>(null);
  const [detailedEmployeeForPayslip, setDetailedEmployeeForPayslip] = useState<Employee | null>(null);
  const [payslipDetailAction, setPayslipDetailAction] = useState<'view' | 'print' | null>(null);
  const [payrollSettings, setPayrollSettings] = useState<PayrollSettings | null>(null);

  const canViewPage = isAdmin || user?.uid === employeeId;

  useEffect(() => {
    if (authLoading) return;
    if (!canViewPage) {
      router.push('/payroll');
      return;
    }
    setLoading(true);
    let unsubEmployee: (() => void) | undefined;
    let unsubPayslips: (() => void) | undefined;
    
    // Fetch employee details
    const employeeDocRef = doc(db, 'employees', employeeId);
    unsubEmployee = onSnapshot(employeeDocRef, (docSnap) => {
        if (docSnap.exists()) {
            setEmployee({ id: docSnap.id, ...docSnap.data() } as Employee);
        }
    });

    // Fetch payslips for this employee
    const payslipsQuery = query(collection(db, 'payslips'), where("employeeId", "==", employeeId), orderBy("runDate", "desc"));
    unsubPayslips = onSnapshot(payslipsQuery, (querySnapshot) => {
      setPayslips(querySnapshot.docs.map(d => ({id: d.id, ...d.data()}) as Payslip));
      setLoading(false);
    }, (error) => {
      console.error("Error fetching payslips:", error);
      toast({ title: "Error", description: "Could not fetch payslips.", variant: "destructive" });
      setLoading(false);
    });

     // Fetch payroll settings for printing
    const fetchSettings = async () => {
        const settingsDocRef = doc(db, 'companySettings', 'payroll');
        const docSnap = await getDoc(settingsDocRef);
        if (docSnap.exists()) {
            setPayrollSettings(docSnap.data() as PayrollSettings);
        }
    };
    fetchSettings();
    
    return () => {
      if (unsubEmployee) unsubEmployee();
      if (unsubPayslips) unsubPayslips();
    };
  }, [employeeId, authLoading, canViewPage, router, toast]);

  const monthNameToIndex = (monthName: string): number => {
    const months = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    return months.findIndex(m => m.toLowerCase() === monthName.toLowerCase());
  };

  const sortedPayslips = useMemo(() => {
    return payslips
      .filter(p => showArchivedPayslips || !p.isArchived)
      .sort((a, b) => {
        if (b.payrollYear !== a.payrollYear) return b.payrollYear - a.payrollYear;
        const monthA = monthNameToIndex(a.payrollMonth);
        const monthB = monthNameToIndex(b.payrollMonth);
        if (monthB !== monthA) return monthB - monthA;
        const periodPrecedence = { 'fullMonth': 0, '16th-end': 1, '1st-15th': 2 };
        const precedenceA = periodPrecedence[a.payrollPeriod as keyof typeof periodPrecedence] ?? 99;
        const precedenceB = periodPrecedence[b.payrollPeriod as keyof typeof periodPrecedence] ?? 99;
        if (precedenceA !== precedenceB) return precedenceA - precedenceB;
        return b.runDate.localeCompare(a.runDate);
      });
  }, [payslips, showArchivedPayslips]);
  
  useEffect(() => {
    if (payslipForDetailView) {
      setDetailedEmployeeForPayslip(employee);
    } else {
      setDetailedEmployeeForPayslip(null);
    }
  }, [payslipForDetailView, employee]);

  const handleViewPayslipDetail = (payslip: Payslip) => {
    setPayslipForDetailView(payslip);
    setPayslipDetailAction('view');
    setIsPayslipDetailDialogOpen(true);
  };
  
  const handlePrintPayslip = (payslip: Payslip) => {
    setPayslipForDetailView(payslip);
    setPayslipDetailAction('print');
    setIsPayslipDetailDialogOpen(true);
     setTimeout(() => { 
        if (typeof window !== 'undefined') window.print();
    }, 100);
  };

  const openArchivePayslipDialog = (payslip: Payslip) => {
    setPayslipToArchive(payslip);
    setIsArchivePayslipDialogOpen(true);
  };
  
  const confirmArchivePayslip = async () => {
    if (!payslipToArchive) return;
    try {
      await updateDoc(doc(db, "payslips", payslipToArchive.id), { isArchived: true });
      toast({ title: "Payslip Archived", description: `Payslip for ${payslipToArchive.payrollMonth} ${payslipToArchive.payrollYear} has been archived.`, variant: 'success' });
    } catch (error) {
      console.error("Error archiving payslip:", error);
      toast({ title: "Error", description: "Failed to archive payslip.", variant: "destructive" });
    } finally {
      setIsArchivePayslipDialogOpen(false);
      setPayslipToArchive(null);
    }
  };

  const openDeletePayslipDialog = (payslip: Payslip) => {
    setPayslipToDelete(payslip);
    setIsDeletePayslipDialogOpen(true);
  };
  
  const confirmDeletePayslip = async () => {
    if (!payslipToDelete) return;
    try {
      await deleteDoc(doc(db, "payslips", payslipToDelete.id));
      toast({ title: "Payslip Deleted", description: `Payslip for ${payslipToDelete.payrollMonth} ${payslipToDelete.payrollYear} has been permanently deleted.`, variant: 'success' });
    } catch (error) {
      console.error("Error deleting payslip:", error);
      toast({ title: "Error", description: "Failed to delete payslip.", variant: "destructive" });
    } finally {
      setIsDeletePayslipDialogOpen(false);
      setPayslipToDelete(null);
    }
  };


  if (loading) {
    return (
        <div className="space-y-4">
            <Skeleton className="h-10 w-1/2" />
            <Skeleton className="h-6 w-3/4" />
            <Card>
                <CardHeader>
                    <Skeleton className="h-6 w-1/4" />
                </CardHeader>
                <CardContent>
                    <Skeleton className="h-40 w-full" />
                </CardContent>
            </Card>
        </div>
    );
  }
  
  if (!employee) {
    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center text-destructive">
                    <AlertTriangle className="mr-2 h-5 w-5" /> Error
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p>Employee not found.</p>
                <Button onClick={() => router.back()} className="mt-4">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
                </Button>
            </CardContent>
        </Card>
    );
  }

  return (
    <>
      <PageHeader
        icon={<FileText className="h-7 w-7 text-primary" />}
        title={`Payslip History: ${employee.name}`}
        description="View and manage all generated payslips for this employee."
        actions={
          <Button variant="outline" onClick={() => router.push('/payroll')}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Payroll
          </Button>
        }
      />
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Switch
              id="show-archived"
              checked={showArchivedPayslips}
              onCheckedChange={setShowArchivedPayslips}
            />
            <Label htmlFor="show-archived">Show Archived Payslips</Label>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Period</TableHead>
                <TableHead className="text-right">Gross Pay</TableHead>
                <TableHead className="text-right">Deductions</TableHead>
                <TableHead className="text-right">Net Pay</TableHead>
                <TableHead className="text-center hidden sm:table-cell">Run Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedPayslips.length > 0 ? (
                sortedPayslips.map((payslip) => (
                  <TableRow key={payslip.id}>
                    <TableCell>
                      <div className="font-medium">{payslip.payrollMonth} {payslip.payrollYear}</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-2">
                        {payslip.payrollPeriod}
                        {payslip.isArchived && <Badge variant="outline">Archived</Badge>}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(payslip.grossPay, payslip.currency)}</TableCell>
                    <TableCell className="text-right text-destructive">{formatCurrency(payslip.totalDeductions, payslip.currency)}</TableCell>
                    <TableCell className="text-right font-semibold text-primary">{formatCurrency(payslip.netPay, payslip.currency)}</TableCell>
                    <TableCell className="text-center hidden sm:table-cell text-xs">{format(parseISO(payslip.runDate), 'MMM dd, yyyy')}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewPayslipDetail(payslip)}>
                            <Eye className="mr-2 h-4 w-4 text-primary" />
                            <span className="text-primary">View Details</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handlePrintPayslip(payslip)}>
                            <Printer className="mr-2 h-4 w-4 text-muted-foreground" />
                            <span>Print</span>
                          </DropdownMenuItem>
                          {isAdmin && (
                            <>
                              <DropdownMenuSeparator />
                              {!payslip.isArchived && (
                                <DropdownMenuItem onClick={() => openArchivePayslipDialog(payslip)}>
                                  <Archive className="mr-2 h-4 w-4 text-amber-600 dark:text-amber-500" />
                                  <span>Archive</span>
                                </DropdownMenuItem>
                              )}
                              {payslip.isArchived && (
                                <DropdownMenuItem
                                  className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                  onClick={() => openDeletePayslipDialog(payslip)}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  <span>Delete Permanently</span>
                                </DropdownMenuItem>
                              )}
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center h-24">
                    No payslips found for this employee.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Payslip Detail Dialog */}
      <Dialog open={isPayslipDetailDialogOpen} onOpenChange={(isOpen) => {
        setIsPayslipDetailDialogOpen(isOpen);
        if (!isOpen) setPayslipDetailAction(null); // Reset action on close
      }}>
        <DialogContent className="sm:max-w-lg print:max-w-none print:shadow-none print:border-0" id="payslip-print-wrapper">
          <DialogHeader className={cn("no-print", payslipDetailAction === 'print' && 'sr-only')}>
             <DialogTitle>
               Payslip: {payslipForDetailView?.employeeName} - {payslipForDetailView?.payrollMonth} {payslipForDetailView?.payrollYear}
             </DialogTitle>
             <DialogDescription>
               Detailed breakdown for period: {payslipForDetailView?.payrollPeriod}. Run on: {payslipForDetailView?.runDate ? format(parseISO(payslipForDetailView.runDate), 'MMM dd, yyyy') : 'N/A'}.
             </DialogDescription>
          </DialogHeader>
          
          {payslipDetailAction === 'print' && payrollSettings && (
            <>
              <div className="payslip-company-header text-center mb-4">
                {payrollSettings.payslipCompanyName && <h2>{payrollSettings.payslipCompanyName}</h2>}
                {payrollSettings.payslipCompanyAddress && <p>{payrollSettings.payslipCompanyAddress}</p>}
                {payrollSettings.payslipCompanyContact && <p>{payrollSettings.payslipCompanyContact}</p>}
                {payrollSettings.payslipCompanyWebsite && payrollSettings.payslipCompanyWebsite.trim() !== '' && (
                    <p>
                        <a 
                            href={payrollSettings.payslipCompanyWebsite.startsWith('http') ? payrollSettings.payslipCompanyWebsite : `https://${payrollSettings.payslipCompanyWebsite}`}
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary hover:underline"
                        >
                        {payrollSettings.payslipCompanyWebsite}
                        </a>
                    </p>
                )}
              </div>
              <h3 className="payslip-title text-lg font-semibold text-center my-2">PAYSLIP</h3>
            </>
          )}

          {payslipForDetailView && (
            <ScrollArea className="max-h-[60vh] my-4 pr-3 print:max-h-none print:overflow-visible">
              <div className="payslip-container space-y-3 text-sm">
                
                <div className="payslip-period-info space-y-0.5 mb-3">
                    <p><span className="font-semibold">Employee Name:</span> {payslipForDetailView.employeeName}</p>
                    {detailedEmployeeForPayslip?.dateOfBirth && (
                      <p><span className="font-semibold">Date of Birth:</span> {format(parseISO(detailedEmployeeForPayslip.dateOfBirth), 'MMMM dd, yyyy')}</p>
                    )}
                    <p><span className="font-semibold">Employee ID:</span> {payslipForDetailView.humanReadableEmployeeId || payslipForDetailView.employeeId}</p>
                    {detailedEmployeeForPayslip && (
                        <>
                            <p><span className="font-semibold">Department:</span> {detailedEmployeeForPayslip.department || 'N/A'}</p>
                            <p><span className="font-semibold">Role:</span> {detailedEmployeeForPayslip.role || 'N/A'}</p>
                        </>
                    )}
                    <p><span className="font-semibold">Pay Period:</span> {payslipForDetailView.payrollMonth} {payslipForDetailView.payrollYear} ({payslipForDetailView.payrollPeriod})</p>
                    <p><span className="font-semibold">Pay Date / Run Date:</span> {payslipForDetailView.runDate ? format(parseISO(payslipForDetailView.runDate), 'MMMM dd, yyyy') : 'N/A'}</p>
                </div>
                <Separator />

                {detailedEmployeeForPayslip && (
                  <div className="payslip-section mt-2">
                    <h4 className="font-semibold mb-1">Other Employee Details:</h4>
                    <div className="payslip-other-details space-y-0.5 text-xs">
                        <p><span className="font-medium">SSS No.:</span> {detailedEmployeeForPayslip.sssNumber || 'N/A'}</p>
                        <p><span className="font-medium">PhilHealth No.:</span> {detailedEmployeeForPayslip.philhealthNumber || 'N/A'}</p>
                        <p><span className="font-medium">Pag-IBIG No.:</span> {detailedEmployeeForPayslip.pagibigNumber || 'N/A'}</p>
                        <p><span className="font-medium">TIN:</span> {detailedEmployeeForPayslip.tinNumber || 'N/A'}</p>
                        <p><span className="font-medium">Bank Acct No.:</span> {detailedEmployeeForPayslip.bankAccount || 'N/A'}</p>
                    </div>
                  </div>
                )}
                <Separator className="my-2"/>
                
                <div className="payslip-section">
                  <h4 className="font-semibold mb-1">Earnings:</h4>
                  <div className="payslip-item flex justify-between"><span>Basic Salary (for period):</span> <span>{formatCurrency(payslipForDetailView.basicSalaryForPeriod, payslipForDetailView.currency)}</span></div>
                  {(payslipForDetailView.appliedOtherRates || []).map((rate, idx) => (
                    <div key={`rate-${idx}`} className="payslip-item flex justify-between ml-2">
                      <span>{rate.name} ({rate.type === 'percentage' ? `${rate.originalValue}%` : 'Fixed'}){rate.detail ? ` - ${rate.detail}` : ''}:</span>
                      <span>+ {formatCurrency(rate.calculatedAmount, payslipForDetailView.currency)}</span>
                    </div>
                  ))}
                  <Separator className="my-1" />
                  <div className="payslip-total-item flex justify-between font-semibold"><span>Gross Pay:</span> <span>{formatCurrency(payslipForDetailView.grossPay, payslipForDetailView.currency)}</span></div>
                </div>
                <Separator className="my-2"/>
                <div className="payslip-section">
                  <h4 className="font-semibold mb-1">Deductions:</h4>
                  {(payslipForDetailView.appliedDeductions || []).map((deduction, idx) => (
                     <div key={`deduction-${idx}`} className="payslip-item flex justify-between ml-2">
                      <span>{deduction.name} ({deduction.type === 'percentage_basic' ? `${deduction.originalValue}% of basic` : (deduction.type === 'fixed_amount' && deduction.detail ? deduction.detail : 'Fixed') }):</span>
                      <span>- {formatCurrency(deduction.calculatedAmount, payslipForDetailView.currency)}</span>
                    </div>
                  ))}
                   {(payslipForDetailView.appliedLoans || []).map((loan, idx) => (
                     <div key={`loan-${idx}`} className="payslip-item flex justify-between ml-2">
                      <span>Loan Repayment ({loan.loanType}):</span>
                      <span>- {formatCurrency(loan.deductionAmount, payslipForDetailView.currency)}</span>
                    </div>
                  ))}
                  <Separator className="my-1" />
                  <div className="payslip-total-item flex justify-between font-semibold"><span>Total Deductions:</span> <span>{formatCurrency(payslipForDetailView.totalDeductions, payslipForDetailView.currency)}</span></div>
                </div>
                <Separator className="my-2"/>
                <div className="payslip-net-pay flex justify-between font-bold text-lg text-primary mt-2">
                  <span>Net Pay:</span> 
                  <span>{formatCurrency(payslipForDetailView.netPay, payslipForDetailView.currency)}</span>
                </div>

                {payslipDetailAction === 'print' && (
                  <div 
                    className="payslip-footer-note mt-8 pt-4 text-center text-xs italic text-muted-foreground print:pt-6 whitespace-pre-wrap"
                  >
                   {payrollSettings?.customFooter || ''}
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
          <DialogFooter className="pt-4 no-print">
            <DialogClose asChild>
              <Button variant="outline"><XCircle className="mr-2 h-4 w-4"/>Close</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      {/* Archive Payslip Confirmation Dialog */}
      <AlertDialog open={isArchivePayslipDialogOpen} onOpenChange={setIsArchivePayslipDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to archive this payslip?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will hide the payslip from the default view. It can be viewed later by enabling "Show Archived".
              This payslip is for {' '}{payslipToArchive?.employeeName} for the period {payslipToArchive?.payrollMonth} {payslipToArchive?.payrollYear} ({payslipToArchive?.payrollPeriod}).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsArchivePayslipDialogOpen(false)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmArchivePayslip}>
              <Archive className="mr-2 h-4 w-4"/> Archive Payslip
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Delete Payslip Confirmation Dialog */}
      <AlertDialog open={isDeletePayslipDialogOpen} onOpenChange={setIsDeletePayslipDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will permanently delete the payslip for{' '}
              <span className="font-semibold">{payslipToDelete?.employeeName}</span> for the period {payslipToDelete?.payrollMonth} {payslipToDelete?.payrollYear}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeletePayslipDialogOpen(false)}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeletePayslip} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              <Trash2 className="mr-2 h-4 w-4"/> Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
