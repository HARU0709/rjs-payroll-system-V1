

'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, addMonths, parse, isWeekend, eachDayOfInterval, isWithinInterval, getDay, differenceInCalendarDays, isValid, startOfDay, parseISO, getYear } from 'date-fns';

import { PageHeader } from '@/components/shared/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Settings, PlayCircle, Users, Eye, Loader2, PlusCircle, Trash2, Save, XCircle, AlertTriangle, CheckCircle, FileText, MoreHorizontal, Printer, Edit, TrendingDown, Landmark, TrendingUp, Palette, Percent, Archive, Mail, DollarSign, Moon, Download } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Form, FormField, FormItem, FormControl, FormMessage, FormLabel, FormDescription } from '@/components/ui/form';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';

import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

import type { Employee, PayrollSettings, PayrollDeductionSetting, DeductionType, PayrollRateSetting, RateType, Payslip, AttendanceRecord, AttendanceSettings, LeaveRequest, TaxBracket, Loan, Benefit, AttendanceEvent, Shift } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/firebase';
import { collection, query, orderBy, onSnapshot, doc, getDoc, setDoc, getDocs, deleteDoc, where, updateDoc, addDoc, writeBatch, documentId, queryEqual, whereIn } from 'firebase/firestore';
import { useAuth } from '@/contexts/auth-context';
import { cn } from '@/lib/utils';
import { useRouter } from 'next/navigation';
import { DatePicker } from '@/components/ui/date-picker';
import type { DateRange } from 'react-day-picker';

const initialPayrollSettings: PayrollSettings = {
  deductions: [
    { id: 'sss_contrib_initial', name: 'SSS Contribution', type: 'percentage_basic', value: 4.5, description: 'Social Security System monthly contribution.' },
    { id: 'philhealth_contrib_initial', name: 'PhilHealth Contribution', type: 'fixed_amount', value: 200, description: 'National Health Insurance Program monthly premium.' },
    { id: 'pagibig_contrib_initial', name: 'Pag-IBIG Contribution', type: 'fixed_amount', value: 100, description: 'Home Development Mutual Fund monthly contribution.' },
  ],
  otherRates: [
    { id: 'default_bonus_initial', name: 'Default Bonus Rate', type: 'percentage', rate: 5, description: 'Default percentage of salary for bonuses.' },
    { id: 'overtime_std_initial', name: 'Overtime Rate', type: 'percentage', rate: 125, description: 'Percentage of hourly rate for overtime work (e.g., 125% = 1.25x).' },
    { id: 'night_diff_initial', name: 'Night Differential', type: 'percentage', rate: 10, description: 'Premium for hours worked between 10 PM and 6 AM.' },
  ],
  taxRates: [],
  payslipCompanyName: "RJS Payroll System Inc.",
  payslipCompanyAddress: "123 Innovation Drive, Tech City, PH",
  payslipCompanyContact: "contact@rjspayroll.com | (02) 8888-7777",
  payslipCompanyWebsite: "www.rjspayroll.com",
  customFooter: "This being a computer generated payslip, no signature required.",
};

const numberPreprocess = (val: unknown) => (val === "" || val === undefined || val === null || Number.isNaN(parseFloat(String(val))) ? undefined : parseFloat(String(val)));
const nullableNumberPreprocess = (val: unknown) => (val === "" || val === undefined || val === null || Number.isNaN(parseFloat(String(val))) ? null : parseFloat(String(val)));


const deductionSettingSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Deduction name is required."),
  type: z.enum(['percentage_basic', 'fixed_amount']),
  value: z.preprocess(numberPreprocess, z.number().min(0, "Value must be non-negative.").default(0)),
  description: z.string().optional(),
});

const payrollRateSettingSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Rate name is required."),
  type: z.enum(['percentage', 'fixed_amount']),
  rate: z.preprocess(numberPreprocess, z.number().min(0, "Rate must be non-negative.").default(0)),
  description: z.string().optional(),
});

const taxBracketSchema = z.object({
  id: z.string(),
  from: z.preprocess(numberPreprocess, z.number().min(0, "Must be non-negative.").default(0)),
  to: z.preprocess(nullableNumberPreprocess, z.number().min(0, "Must be non-negative.").nullable()),
  rate: z.preprocess(numberPreprocess, z.number().min(0, "Rate must be non-negative.").max(100, "Rate cannot exceed 100%.").default(0)),
  baseAmount: z.preprocess(numberPreprocess, z.number().min(0, "Base amount must be non-negative.").default(0)),
  description: z.string().optional(),
});


const payrollSettingsSchema = z.object({
  deductions: z.array(deductionSettingSchema),
  otherRates: z.array(payrollRateSettingSchema),
  taxRates: z.array(taxBracketSchema),
  payslipCompanyName: z.string().optional(),
  payslipCompanyAddress: z.string().optional(),
  payslipCompanyContact: z.string().optional(),
  payslipCompanyWebsite: z.string().url({ message: "Please enter a valid URL (e.g., https://example.com) or leave blank." }).optional().or(z.literal('')),
  customFooter: z.string().optional(),
});
type PayrollSettingsFormValues = z.infer<typeof payrollSettingsSchema>;


const formatCurrency = (amount: number | undefined | null, currencySymbol = 'PHP') => {
  if (amount === undefined || amount === null) return 'N/A';
  return new Intl.NumberFormat('en-PH', { style: 'currency', currency: currencySymbol }).format(amount);
};

const generateMonthYearOptions = (numMonthsPast = 6, numMonthsFuture = 18) => {
  const options = [];
  const currentDate = new Date();
  for (let i = -numMonthsPast; i <= numMonthsFuture; i++) {
    const dateOption = addMonths(currentDate, i);
    options.push({
      value: format(dateOption, 'MMMM yyyy'),
      label: format(dateOption, 'MMMM yyyy'),
    });
  }
  return options;
};

const monthNameToIndex = (monthName: string): number => {
  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const index = months.findIndex(m => m.toLowerCase() === monthName.toLowerCase());
  return index > -1 ? index : 0; // Default to January if not found
};

type EmployeeReviewItem = {
  employee: Employee;
  issues: string[];
};

// Helper to parse HH:mm string to minutes from midnight
const timeToMinutes = (timeStr: string | null | undefined): number | null => {
  if (!timeStr || !/^\d{2}:\d{2}$/.test(timeStr)) return null;
  const [hours, minutes] = timeStr.split(':').map(Number);
  return hours * 60 + minutes;
};

// Helper to get pay period start and end dates and number of weekdays
const getPayPeriodDatesAndWeekdays = (payrollMonthYear: string, payrollPayPeriod: string): { startDate: string; endDate: string; numberOfWeekdays: number } => {
  const [monthName, yearStr] = payrollMonthYear.split(' ');
  const year = parseInt(yearStr);
  const month = monthNameToIndex(monthName);

  let startDateObj: Date;
  let endDateObj: Date;

  if (payrollPayPeriod === '1st-15th') {
    startDateObj = new Date(year, month, 1);
    endDateObj = new Date(year, month, 15);
  } else if (payrollPayPeriod === '16th-end') {
    startDateObj = new Date(year, month, 16);
    endDateObj = new Date(year, month + 1, 0); // Last day of current month
  } else { // fullMonth
    startDateObj = new Date(year, month, 1);
    endDateObj = new Date(year, month + 1, 0);
  }

  let weekdays = 0;
  if (startDateObj <= endDateObj && isValid(startDateObj) && isValid(endDateObj)) { 
    const daysInPeriod = eachDayOfInterval({ start: startDateObj, end: endDateObj });
    weekdays = daysInPeriod.filter(day => !isWeekend(day)).length;
  }
  
  return {
    startDate: format(startDateObj, 'yyyy-MM-dd'),
    endDate: format(endDateObj, 'yyyy-MM-dd'),
    numberOfWeekdays: weekdays
  };
};

const PAID_LEAVE_TYPES: LeaveRequest['leaveType'][] = ['Annual', 'Sick', 'Maternity', 'Paternity', 'Personal']; // Define which leave types are considered paid


export default function PayrollPage() {
  const { toast } = useToast();
  const { user, employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>('all');
  const [isLoadingEmployees, setIsLoadingEmployees] = useState(true);
  const [isSettingsDialogOpen, setIsSettingsDialogOpen] = useState(false);
  const [isLoadingSettings, setIsLoadingSettings] = useState(true); // Changed initial to true
  const [isSubmittingSettings, setIsSubmittingSettings] = useState(false);
  const [activeSettingsTab, setActiveSettingsTab] = useState('deductions');
  const [currentPayrollSettings, setCurrentPayrollSettings] = useState<PayrollSettings | null>(null);

  const [allPayslips, setAllPayslips] = useState<Payslip[]>([]);
  const [isLoadingPayslips, setIsLoadingPayslips] = useState(true);

  // State for "Add New Deduction/Rate" forms
  const [newDeductionName, setNewDeductionName] = useState('');
  const [newDeductionType, setNewDeductionType] = useState<DeductionType>('fixed_amount');
  const [newDeductionValue, setNewDeductionValue] = useState<number | ''>('');
  const [newDeductionDescription, setNewDeductionDescription] = useState('');
  const [newRateName, setNewRateName] = useState('');
  const [newRateType, setNewRateType] = useState<RateType>('fixed_amount');
  const [newRateValue, setNewRateValue] = useState<number | ''>('');
  const [newRateDescription, setNewRateDescription] = useState('');

  // State for adding new tax bracket
  const [newTaxBracketFrom, setNewTaxBracketFrom] = useState<number | ''>('');
  const [newTaxBracketTo, setNewTaxBracketTo] = useState<number | ''>('');
  const [newTaxBracketRate, setNewTaxBracketRate] = useState<number | ''>('');
  const [newTaxBracketBase, setNewTaxBracketBase] = useState<number | ''>('');


  // State for the first "Run Payroll" dialog
  const [isRunPayrollDialogOpen, setIsRunPayrollDialogOpen] = useState(false);
  const [payrollTargetEmployeeOption, setPayrollTargetEmployeeOption] = useState<string>('allActive');
  const [payrollMonthYear, setPayrollMonthYear] = useState<string>(format(new Date(), 'MMMM yyyy'));
  const [payrollPayPeriod, setPayrollPayPeriod] = useState<string>('1st-15th');
  const [isProcessingPayroll, setIsProcessingPayroll] = useState(false);

  // State for the second "Payroll Review" dialog
  const [isPayrollReviewDialogOpen, setIsPayrollReviewDialogOpen] = useState(false);
  const [employeesForReview, setEmployeesForReview] = useState<EmployeeReviewItem[]>([]);

  // State for View Payslips (now handled by a dedicated page)
  const router = useRouter();


  // State for Payslip Detail Dialog
  const [isPayslipDetailDialogOpen, setIsPayslipDetailDialogOpen] = useState(false);
  const [payslipForDetailView, setPayslipForDetailView] = useState<Payslip | null>(null);
  const [detailedEmployeeForPayslip, setDetailedEmployeeForPayslip] = useState<Employee | null>(null);
  const [payslipDetailAction, setPayslipDetailAction] = useState<'view' | 'print' | null>(null);
  
  // State for Bulk Export Dialog
  const [isBulkExportDialogOpen, setIsBulkExportDialogOpen] = useState(false);
  const [bulkExportEmployeeId, setBulkExportEmployeeId] = useState<string>('');
  const [bulkExportYear, setBulkExportYear] = useState<string>(getYear(new Date()).toString());
  const [bulkExportMonth, setBulkExportMonth] = useState<string>('all');
  const [bulkExportPeriod, setBulkExportPeriod] = useState<string>('all');
  const [isGeneratingExport, setIsGeneratingExport] = useState(false);
  const [exportAction, setExportAction] = useState<'print' | 'download' | null>(null);
  const [isPrintWarningDialogOpen, setIsPrintWarningDialogOpen] = useState(false);


  const monthYearOptions = useMemo(() => generateMonthYearOptions(), []);
  const payPeriodOptions = [
    { value: '1st-15th', label: '1st - 15th' },
    { value: '16th-end', label: '16th - End of Month' },
    { value: 'fullMonth', label: 'Full Month' },
  ];
  
  const payrollTargetOptions = useMemo(() => {
    const baseOptions = [
      { value: 'allActive', label: 'All Active Employees' },
      { value: 'allEmployees', label: 'All Employees (including Inactive)' },
    ];
    if (isLoadingEmployees || !employees || employees.length === 0) {
      return baseOptions;
    }
    const activeEmployeeOptions = employees
      .filter(emp => emp.status === 'Active')
      .map(emp => ({ value: emp.id, label: `${emp.name} (${emp.employeeId})` }));
    return [...baseOptions, ...activeEmployeeOptions];
  }, [employees, isLoadingEmployees]);


  const settingsForm = useForm<PayrollSettingsFormValues>({
    resolver: zodResolver(payrollSettingsSchema),
    defaultValues: currentPayrollSettings || initialPayrollSettings
  });

  const { fields: deductionFields, append: appendDeduction, remove: removeDeduction } = useFieldArray({
    control: settingsForm.control,
    name: "deductions",
  });

  const { fields: otherRateFields, append: appendOtherRate, remove: removeOtherRate } = useFieldArray({
    control: settingsForm.control,
    name: "otherRates",
  });

  const { fields: taxRateFields, append: appendTaxRate, remove: removeTaxRate } = useFieldArray({
    control: settingsForm.control,
    name: "taxRates",
  });

  const fetchPayslips = useCallback(async () => {
    setIsLoadingPayslips(true);
    try {
      const payslipsCollection = collection(db, "payslips");
      let qPayslips;

      if (isAdmin) {
        qPayslips = query(payslipsCollection, orderBy("runDate", "desc"));
      } else if (user) {
        qPayslips = query(payslipsCollection, where("employeeId", "==", user.uid));
      } else {
        setIsLoadingPayslips(false);
        return;
      }

      const querySnapshot = await getDocs(qPayslips);
      const fetchedPayslips = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Payslip));
      
      // Sort client-side if not admin because Firestore requires a composite index for where + orderBy
      if (!isAdmin) {
        fetchedPayslips.sort((a,b) => b.runDate.localeCompare(a.runDate));
      }

      setAllPayslips(fetchedPayslips);
    } catch (error) {
      console.error("Error fetching payslips:", error);
      toast({ title: "Error", description: "Could not fetch payslip data.", variant: "destructive" });
    } finally {
      setIsLoadingPayslips(false);
    }
  }, [toast, isAdmin, user]);

  const loadInitialPayrollSettings = useCallback(async () => {
    setIsLoadingSettings(true);
    try {
      const settingsDocRef = doc(db, 'companySettings', 'payroll');
      const docSnap = await getDoc(settingsDocRef);
      if (docSnap.exists()) {
        const settings = docSnap.data() as PayrollSettings;
        setCurrentPayrollSettings(settings);
        settingsForm.reset(settings); // Also reset form when settings are loaded
      } else {
        setCurrentPayrollSettings(initialPayrollSettings);
        settingsForm.reset(initialPayrollSettings); // Reset form with defaults
      }
    } catch (error) {
      console.error("Error fetching payroll settings:", error);
      toast({ title: "Error", description: "Could not load payroll settings. Using defaults.", variant: "destructive" });
      setCurrentPayrollSettings(initialPayrollSettings);
      settingsForm.reset(initialPayrollSettings);
    } finally {
      setIsLoadingSettings(false);
    }
  }, [toast, settingsForm]);


  useEffect(() => {
    setIsLoadingEmployees(true);
    const employeesCollection = collection(db, "employees");
    const q = query(employeesCollection, orderBy("name"));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedEmployees = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee));
      setEmployees(fetchedEmployees.filter(emp => emp.employeeId !== 'ADMIN'));
      setIsLoadingEmployees(false);
    }, (error) => {
      console.error("Error fetching employees for payroll:", error);
      toast({ title: "Error", description: "Could not fetch employees.", variant: "destructive" });
      setIsLoadingEmployees(false);
    });

    fetchPayslips();
    loadInitialPayrollSettings(); // Load settings on mount
    return () => unsubscribe();
  }, [toast, fetchPayslips, loadInitialPayrollSettings]);

  useEffect(() => {
    if (payslipForDetailView) {
      const foundEmployee = employees.find(emp => emp.id === payslipForDetailView.employeeId);
      setDetailedEmployeeForPayslip(foundEmployee || null);
    } else {
      setDetailedEmployeeForPayslip(null);
    }
  }, [payslipForDetailView, employees]);


  const handleOpenSettingsDialog = () => {
    settingsForm.reset(currentPayrollSettings || initialPayrollSettings);
    setNewDeductionName('');
    setNewDeductionType('fixed_amount');
    setNewDeductionValue('');
    setNewDeductionDescription('');
    setNewRateName('');
    setNewRateType('fixed_amount');
    setNewRateValue('');
    setNewRateDescription('');
    setIsSettingsDialogOpen(true);
  };

  const filteredEmployees = useMemo(() => {
    if (!isAdmin && user) {
      return employees.filter(emp => emp.id === user.uid);
    }
    if (selectedEmployeeId === 'all') {
      return employees;
    }
    return employees.filter(emp => emp.id === selectedEmployeeId);
  }, [employees, selectedEmployeeId, isAdmin, user]);

  const handleOpenRunPayrollDialog = () => {
    setPayrollTargetEmployeeOption('allActive');
    setPayrollMonthYear(format(new Date(), 'MMMM yyyy'));
    setPayrollPayPeriod('1st-15th');
    setIsRunPayrollDialogOpen(true);
  };

  const prepareAndShowPayrollReview = async () => {
    let employeesToProcess: Employee[] = [];
    if (payrollTargetEmployeeOption === 'allActive') {
        employeesToProcess = employees.filter(emp => emp.status === 'Active');
    } else if (payrollTargetEmployeeOption === 'allEmployees') {
        employeesToProcess = employees;
    } else {
        const specificEmployee = employees.find(emp => emp.id === payrollTargetEmployeeOption);
        if (specificEmployee) employeesToProcess = [specificEmployee];
    }

    const [monthNameStr, yearStr] = payrollMonthYear.split(' ');
    const payrollYearNum = parseInt(yearStr);
    let existingPayslipFound = false;

    for (const emp of employeesToProcess) {
        const payslipDocId = `${emp.id}_${payrollYearNum}_${monthNameStr}_${payrollPayPeriod.replace(/\s|-/g, '')}`;
        if (allPayslips.some(p => p.id === payslipDocId)) {
            existingPayslipFound = true;
            break;
        }
    }

    if (existingPayslipFound) {
        toast({
            title: "Payroll Already Run",
            description: `Payroll for ${payrollMonthYear} (${payrollPayPeriod}) has already been run for some or all selected employees. Please check existing payslips or delete them if you wish to re-run.`,
            variant: "default", 
            duration: 7000,
        });
        return; 
    }

    const reviewItems: EmployeeReviewItem[] = employeesToProcess.map(emp => {
        const issues: string[] = [];
        if (!emp.salary || emp.salary <= 0) {
            issues.push("Missing or invalid salary");
        }
        return { employee: emp, issues };
    });

    setEmployeesForReview(reviewItems);
    setIsRunPayrollDialogOpen(false);
    setIsPayrollReviewDialogOpen(true);
  };
  
  const handleProceedFromReview = () => {
    setIsPayrollReviewDialogOpen(false);
    executePayrollRun();
  };

  const executePayrollRun = async () => {
    setIsProcessingPayroll(true);
    let processedCount = 0;
    const employeesProcessedNames: string[] = [];
    const skippedEmployees: { name: string; reason: string }[] = [];
    let processingErrorCount = 0;
  
    try {
      const activePayrollSettings = currentPayrollSettings || initialPayrollSettings;
      if (!currentPayrollSettings) {
        toast({ title: "Warning", description: "Payroll settings not fully loaded. Using initial defaults for this run.", variant: "default" });
      }
  
      const attendanceSettingsDocRef = doc(db, 'companySettings', 'attendance');
      const attendanceSettingsSnap = await getDoc(attendanceSettingsDocRef);
      const allShifts: Shift[] = attendanceSettingsSnap.exists() ? (attendanceSettingsSnap.data().shifts || []) : [];
      const defaultAttendanceSettings: AttendanceSettings = attendanceSettingsSnap.exists()
        ? attendanceSettingsSnap.data() as AttendanceSettings
        : {
            expectedMorningIn: '08:00', requiredWorkHours: 8, lateGracePeriod: 15,
            expectedLunchOut: '12:00', expectedLunchIn: '13:00', expectedAfternoonOut: '17:00',
            earlyLeaveThreshold: 15, shifts: [],
          };
      
      const holidaysQuery = query(collection(db, "attendanceEvents"), where("status", "==", "Holiday"));
      const holidaysSnap = await getDocs(holidaysQuery);
      const companyHolidays = holidaysSnap.docs.map(d => (d.data().date?.toDate ? d.data().date.toDate() : new Date(0))).filter(d => isValid(d));
  
      if (!attendanceSettingsSnap.exists()) {
        toast({ title: "Warning", description: "Attendance settings not found. Using defaults for calculations.", variant: "default" });
      }
  
      let employeesToProcess: Employee[] = [];
      if (payrollTargetEmployeeOption === 'allActive') {
        employeesToProcess = employees.filter(emp => emp.status === 'Active' && emp.salary && emp.salary > 0);
      } else if (payrollTargetEmployeeOption === 'allEmployees') {
        employeesToProcess = employees.filter(emp => emp.salary && emp.salary > 0);
      } else {
        const specificEmployee = employees.find(emp => emp.id === payrollTargetEmployeeOption);
        if (specificEmployee && specificEmployee.salary && specificEmployee.salary > 0) {
          employeesToProcess = [specificEmployee];
        } else if (specificEmployee) {
          skippedEmployees.push({ name: specificEmployee.name, reason: "Missing or invalid salary" });
        }
      }
  
      const [monthNameStr, yearStr] = payrollMonthYear.split(' ');
      const payrollYearNum = parseInt(yearStr);
      const { startDate: periodStartDateStr, endDate: periodEndDateStr, numberOfWeekdays: expectedWorkdaysInPayPeriod } = getPayPeriodDatesAndWeekdays(payrollMonthYear, payrollPayPeriod);
      
      const preTaxDeductionNames = ['sss', 'philhealth', 'pag-ibig'];
  
      for (const employee of employeesToProcess) {
        const batch = writeBatch(db);
        try {
          // Fetch all necessary data for the employee for the period
          const attendanceQuery = query(collection(db, "attendanceRecords"), where("employeeId", "==", employee.id), where("date", ">=", periodStartDateStr), where("date", "<=", periodEndDateStr));
          const leaveQuery = query(collection(db, "leaveRequests"), where("employeeId", "==", employee.id), where("status", "==", "Approved"));
          const loanQuery = query(collection(db, "loans"), where("employeeId", "==", employee.id), where("status", "==", "Active"));
          const benefitQuery = query(collection(db, "benefits"), where("employeeId", "==", employee.id));
          
          const [attendanceSnap, leaveSnap, loanSnap, benefitSnap] = await Promise.all([
            getDocs(attendanceQuery),
            getDocs(leaveQuery),
            getDocs(loanQuery),
            getDocs(benefitQuery),
          ]);
          
          const employeeAttendanceRecords = attendanceSnap.docs.map(d => d.data() as AttendanceRecord);
          const employeeLeaveRequests = leaveSnap.docs.map(d => ({id:d.id, ...d.data()}) as LeaveRequest);
          const employeeActiveLoans = loanSnap.docs.map(d => ({id: d.id, ...d.data()}) as Loan);
          const employeeBenefits = benefitSnap.docs.map(d => d.data() as Benefit);

          const basicSalaryForPeriod = payrollPayPeriod === 'fullMonth'
            ? (employee.salary || 0)
            : (employee.salary || 0) / 2;
            
          let totalMinutesWorkedInPeriod = 0;
          let totalUndertimeMinutesInPeriod = 0;
          let totalLatenessMinutesInPeriod = 0;
          let totalNightShiftMinutes = 0;
          let totalOvertimeHours = 0;
          const uniqueDatesWithAttendance = new Set<string>();
  
          employeeAttendanceRecords.forEach(ar => {
            uniqueDatesWithAttendance.add(ar.date);
            
            const shiftId = ar.shiftId || employee.shiftId;
            const dailyShift = allShifts.find(s => s.id === shiftId);
            const dailyRequiredHours = dailyShift ? ((timeToMinutes(dailyShift.endTime) || 0) - (timeToMinutes(dailyShift.startTime) || 0)) / 60 : defaultAttendanceSettings.requiredWorkHours;
            const dailyExpectedIn = timeToMinutes(dailyShift?.startTime || defaultAttendanceSettings.expectedMorningIn);

            // Calculate Lateness
            const actualIn = timeToMinutes(ar.morningIn);
            if (actualIn && dailyExpectedIn && actualIn > (dailyExpectedIn + defaultAttendanceSettings.lateGracePeriod)) {
                totalLatenessMinutesInPeriod += actualIn - dailyExpectedIn;
            }
            
            let dailyWorkMinutes = 0;
            const morningInMin = timeToMinutes(ar.morningIn);
            const afternoonOutMin = timeToMinutes(ar.afternoonOut);
            if (morningInMin !== null && afternoonOutMin !== null) {
              dailyWorkMinutes = (afternoonOutMin > morningInMin) ? (afternoonOutMin - morningInMin) : (1440 - morningInMin + afternoonOutMin);
            }
            totalMinutesWorkedInPeriod += dailyWorkMinutes;
            
            const dailyRequiredMinutes = dailyRequiredHours * 60;
            if (dailyWorkMinutes > 0) {
              if (dailyWorkMinutes < dailyRequiredMinutes) {
                  totalUndertimeMinutesInPeriod += dailyRequiredMinutes - dailyWorkMinutes;
              } else if (dailyWorkMinutes > dailyRequiredMinutes) {
                  totalOvertimeHours += (dailyWorkMinutes - dailyRequiredMinutes) / 60;
              }
            }

            // Night differential calculation
            if (morningInMin !== null && afternoonOutMin !== null) {
                const nightStart = 22 * 60; // 10 PM
                const nightEnd = 6 * 60; // 6 AM

                let nightMinutes = 0;
                if (afternoonOutMin > morningInMin) { // Same day shift
                    const start = Math.max(morningInMin, nightStart);
                    const end = afternoonOutMin;
                    if (end > start) nightMinutes += end - start;
                } else { // Overnight shift
                    // From clock-in to midnight
                    let start = Math.max(morningInMin, nightStart);
                    nightMinutes += 1440 - start;
                    // From midnight to clock-out
                    let end = Math.min(afternoonOutMin, nightEnd);
                    if (end > 0) nightMinutes += end;
                }
                totalNightShiftMinutes += nightMinutes;
            }
          });
  
          const daysPresentCount = uniqueDatesWithAttendance.size;
          // ** Corrected Rate Calculation **
          const dailyRate = (employee.salary || 0) / 22; // Standard 22 working days
          const baseHourlyRate = defaultAttendanceSettings.requiredWorkHours > 0 && dailyRate > 0 ? dailyRate / defaultAttendanceSettings.requiredWorkHours : 0;
  
          let paidLeaveDaysInPeriod = 0;
          const periodStartObj = parseISO(periodStartDateStr);
          const periodEndObj = parseISO(periodEndDateStr);

          let paidHolidayDaysInPeriod = 0;
          const daysInPeriod = eachDayOfInterval({ start: periodStartObj, end: periodEndObj });
          daysInPeriod.forEach(day => {
            if (!isWeekend(day) && companyHolidays.some(h => startOfDay(h).getTime() === startOfDay(day).getTime())) {
                paidHolidayDaysInPeriod++;
            }
          });
  
          employeeLeaveRequests.forEach(lr => {
            if (PAID_LEAVE_TYPES.includes(lr.leaveType)) {
              const leaveStartObj = parseISO(lr.startDate);
              const leaveEndObj = parseISO(lr.endDate);
              const overlapStart = leaveStartObj > periodStartObj ? leaveStartObj : periodStartObj;
              const overlapEnd = leaveEndObj < periodEndObj ? leaveEndObj : periodEndObj;
              if (overlapStart <= overlapEnd) {
                const daysInOverlap = eachDayOfInterval({ start: overlapStart, end: overlapEnd });
                daysInOverlap.forEach(dayInLeave => {
                  if (!isWeekend(dayInLeave) && !uniqueDatesWithAttendance.has(format(dayInLeave, 'yyyy-MM-dd'))) {
                    paidLeaveDaysInPeriod++;
                  }
                });
              }
            }
          });

          let unpaidLeaveDaysInPeriod = 0;
           employeeLeaveRequests.forEach(lr => {
            if (lr.leaveType === 'Unpaid') {
              const leaveStartObj = parseISO(lr.startDate);
              const leaveEndObj = parseISO(lr.endDate);
              const overlapStart = leaveStartObj > periodStartObj ? leaveStartObj : periodStartObj;
              const overlapEnd = leaveEndObj < periodEndObj ? leaveEndObj : periodEndObj;
              if (overlapStart <= overlapEnd) {
                const daysInOverlap = eachDayOfInterval({ start: overlapStart, end: overlapEnd });
                daysInOverlap.forEach(dayInLeave => {
                  if (!isWeekend(dayInLeave) && !uniqueDatesWithAttendance.has(format(dayInLeave, 'yyyy-MM-dd'))) {
                    unpaidLeaveDaysInPeriod++;
                  }
                });
              }
            }
          });
  
          const unpaidAbsentDays = Math.max(0, expectedWorkdaysInPayPeriod - daysPresentCount - paidLeaveDaysInPeriod - paidHolidayDaysInPeriod - unpaidLeaveDaysInPeriod);
          const totalUnpaidDays = unpaidAbsentDays + unpaidLeaveDaysInPeriod;
          
          let currentEarnings = basicSalaryForPeriod;
          const appliedOtherRates: Payslip['appliedOtherRates'] = [];
          
          const overtimeRateSetting = activePayrollSettings.otherRates.find(r => r.name.toLowerCase().includes('overtime'));
          if (totalOvertimeHours > 0 && overtimeRateSetting && baseHourlyRate > 0) {
            const overtimePayAmount = totalOvertimeHours * baseHourlyRate * (overtimeRateSetting.rate / 100);
            currentEarnings += overtimePayAmount;
            appliedOtherRates.push({ name: overtimeRateSetting.name, type: overtimeRateSetting.type, originalValue: overtimeRateSetting.rate, calculatedAmount: overtimePayAmount, detail: `${totalOvertimeHours.toFixed(2)} OT hrs at ${overtimeRateSetting.rate}%` });
          }

          // Night Differential Pay
          const nightDiffRateSetting = activePayrollSettings.otherRates.find(r => r.name.toLowerCase().includes('night differential'));
          if (totalNightShiftMinutes > 0 && nightDiffRateSetting && baseHourlyRate > 0) {
              const nightHours = totalNightShiftMinutes / 60;
              const nightDiffAmount = nightHours * baseHourlyRate * (nightDiffRateSetting.rate / 100);
              currentEarnings += nightDiffAmount;
              appliedOtherRates.push({ name: nightDiffRateSetting.name, type: nightDiffRateSetting.type, originalValue: nightDiffRateSetting.rate, calculatedAmount: nightDiffAmount, detail: `${nightHours.toFixed(2)} hrs at ${nightDiffRateSetting.rate}%` });
          }
  
          (activePayrollSettings.otherRates || []).filter(r => !r.name.toLowerCase().includes('overtime') && !r.name.toLowerCase().includes('night differential')).forEach(rate => {
            let calculatedAmount = rate.type === 'fixed_amount' ? rate.rate : basicSalaryForPeriod * (rate.rate / 100);
            currentEarnings += calculatedAmount;
            appliedOtherRates.push({ name: rate.name, type: rate.type, originalValue: rate.rate, calculatedAmount });
          });
          
          const grossPay = currentEarnings;
          
          let totalDeductions = 0;
          const appliedDeductions: Payslip['appliedDeductions'] = [];
          const appliedLoans: Payslip['appliedLoans'] = [];
  
          const deductionForUnpaidAbsenceAmount = totalUnpaidDays * dailyRate;
          const deductionForUndertimeAmount = (totalUndertimeMinutesInPeriod / 60) * baseHourlyRate;
          const deductionForLatenessAmount = (totalLatenessMinutesInPeriod / 60) * baseHourlyRate;
          
          const totalUnpaidTimeDeduction = deductionForUnpaidAbsenceAmount + deductionForUndertimeAmount;

          if (totalUnpaidTimeDeduction > 0) {
              let details: string[] = [];
              if (totalUnpaidDays > 0) details.push(`${totalUnpaidDays} absent day(s)`);
              if (totalUndertimeMinutesInPeriod > 0) details.push(`${(totalUndertimeMinutesInPeriod / 60).toFixed(2)} undertime hr(s)`);
              
              appliedDeductions.push({ 
                  name: 'Deduction for Unpaid Time', 
                  type: 'fixed_amount', 
                  originalValue: 0,
                  calculatedAmount: totalUnpaidTimeDeduction, 
                  detail: details.join(' & ') 
              });
              totalDeductions += totalUnpaidTimeDeduction;
          }
          
          if (deductionForLatenessAmount > 0) {
            appliedDeductions.push({
              name: 'Deduction for Lateness',
              type: 'fixed_amount',
              originalValue: totalLatenessMinutesInPeriod,
              calculatedAmount: deductionForLatenessAmount,
              detail: `${totalLatenessMinutesInPeriod.toFixed(0)} minute(s) late`
            });
            totalDeductions += deductionForLatenessAmount;
          }
  
          const preTaxStatutoryDeductions = (activePayrollSettings.deductions || []).filter(d => preTaxDeductionNames.some(name => d.name.toLowerCase().includes(name)));
          let preTaxStatutoryDeductionsAmount = 0;
          preTaxStatutoryDeductions.forEach(deduction => {
            let calculatedAmount = 0;
            if (deduction.type === 'fixed_amount') {
              calculatedAmount = (payrollPayPeriod !== 'fullMonth') ? deduction.value / 2 : deduction.value;
            } else { // percentage_basic
              calculatedAmount = basicSalaryForPeriod * (deduction.value / 100);
            }
            appliedDeductions.push({ name: deduction.name, type: deduction.type, originalValue: deduction.value, calculatedAmount, detail: (deduction.type === 'fixed_amount' && payrollPayPeriod !== 'fullMonth') ? 'Semi-monthly' : 'Monthly' });
            preTaxStatutoryDeductionsAmount += calculatedAmount;
          });
          totalDeductions += preTaxStatutoryDeductionsAmount;
  
          const taxableIncome = Math.max(0, grossPay - totalUnpaidTimeDeduction - deductionForLatenessAmount - preTaxStatutoryDeductionsAmount);
          let incomeTax = 0;
          const sortedTaxBrackets = [...(activePayrollSettings.taxRates || [])].sort((a, b) => a.from - b.from);
          for (const bracket of sortedTaxBrackets) {
            if (taxableIncome > bracket.from) {
              if (bracket.to === null || taxableIncome <= bracket.to) {
                incomeTax = bracket.baseAmount + ((taxableIncome - bracket.from) * (bracket.rate / 100));
                break;
              }
            }
          }
          if (incomeTax > 0) {
            appliedDeductions.push({ name: "Income Tax", type: 'fixed_amount', originalValue: 0, calculatedAmount: incomeTax, detail: `On taxable income of ${formatCurrency(taxableIncome)}` });
            totalDeductions += incomeTax;
          }
  
          // Post-tax, non-statutory deductions
          const postTaxDeductions = (activePayrollSettings.deductions || []).filter(d => !preTaxDeductionNames.some(name => d.name.toLowerCase().includes(name)));
          postTaxDeductions.forEach(deduction => {
            let calculatedAmount = deduction.type === 'fixed_amount' ? deduction.value : basicSalaryForPeriod * (deduction.value / 100);
            appliedDeductions.push({ name: deduction.name, type: deduction.type, originalValue: deduction.value, calculatedAmount });
            totalDeductions += calculatedAmount;
          });

          // Benefit Contributions
          employeeBenefits.forEach(benefit => {
            if (benefit.monthlyContribution > 0) {
                const contribution = payrollPayPeriod === 'fullMonth' ? benefit.monthlyContribution : benefit.monthlyContribution / 2;
                appliedDeductions.push({ name: `${benefit.benefitType} Contribution (${benefit.provider})`, type: 'benefit_contribution', originalValue: benefit.monthlyContribution, calculatedAmount: contribution });
                totalDeductions += contribution;
            }
          });
          
          // Loan Repayments
          employeeActiveLoans.forEach(loan => {
            const deductionAmount = payrollPayPeriod === 'fullMonth' ? loan.monthlyDeduction : loan.monthlyDeduction / 2;
            appliedLoans.push({ loanId: loan.id, loanType: loan.loanType, deductionAmount });
            totalDeductions += deductionAmount;

            // Prepare to update the loan document
            const loanRef = doc(db, 'loans', loan.id);
            const newAmountPaid = loan.amountPaid + deductionAmount;
            const newStatus = newAmountPaid >= loan.totalAmount ? 'Paid Off' : 'Active';
            batch.update(loanRef, { amountPaid: newAmountPaid, status: newStatus });
          });

          const netPay = grossPay - totalDeductions;
          const payslipDocId = `${employee.id}_${payrollYearNum}_${monthNameStr}_${payrollPayPeriod.replace(/\s|-/g, '')}`;
  
          const payslipData: Omit<Payslip, 'id'> = {
            employeeId: employee.id, humanReadableEmployeeId: employee.employeeId, employeeName: employee.name,
            payrollMonth: monthNameStr, payrollYear: payrollYearNum, payrollPeriod: payrollPayPeriod,
            runDate: format(new Date(), 'yyyy-MM-dd'), basicSalaryForPeriod,
            grossPay, totalDeductions, netPay, 
            appliedOtherRates,
            appliedDeductions, 
            appliedLoans, 
            currency: 'PHP',
            isArchived: false,
          };
          
          const payslipRef = doc(db, "payslips", payslipDocId);
          batch.set(payslipRef, payslipData);
          
          const notificationData = {
            userId: employee.id,
            type: 'success' as const,
            text: `Your payslip for ${payslipData.payrollMonth} ${payslipData.payrollYear} (${payslipData.payrollPeriod}) is now available.`,
            timestamp: new Date(),
            isRead: false,
            link: '/payroll',
          };
          const notificationRef = doc(collection(db, "notifications"));
          batch.set(notificationRef, notificationData);

          await batch.commit();

          processedCount++;
          employeesProcessedNames.push(employee.name);
  
        } catch (empError) {
          console.error(`Error processing payroll for ${employee.name}:`, empError);
          skippedEmployees.push({ name: employee.name, reason: `Processing error - ${empError instanceof Error ? empError.message : 'Unknown error'}` });
          processingErrorCount++;
        }
      }
  
      let summaryParts: string[] = [];
      if (processedCount > 0) {
        summaryParts.push(`${processedCount} employee(s) processed successfully.`);
      }
      if (skippedEmployees.length > 0) {
        summaryParts.push(`${skippedEmployees.length} employee(s) were skipped.`);
      }
      
      const adminName = employeeProfile?.name || "Admin";
      const adminNameParts = adminName.split(' ');
      const adminInitials = (adminNameParts.length > 1 ? `${adminNameParts[0][0]}${adminNameParts[adminNameParts.length - 1][0]}` : adminName.substring(0, 2)).toUpperCase();
      
      await addDoc(collection(db, "activityFeedItems"), {
        text: `ran payroll for ${payrollMonthYear} (${payrollPayPeriod}).`,
        userId: user?.uid,
        userName: employeeProfile?.name || "Admin",
        userRole: employeeProfile?.permissionRole || "Administrator",
        avatarUrl: employeeProfile?.avatarUrl || "",
        avatarFallback: adminInitials,
        timestamp: new Date(),
        relatedEntityType: 'payroll',
        details: [
          { label: 'Processed', value: `${processedCount} employees` },
          { label: 'Skipped/Errors', value: `${skippedEmployees.length} employees` },
        ]
      });
  
      toast({
        title: "Payroll Run Complete",
        description: summaryParts.join(' '),
        variant: processingErrorCount > 0 ? "destructive" : "success",
        duration: 7000,
      });
  
    } catch (runError) {
      console.error("Critical error during payroll run:", runError);
      toast({ title: "Payroll Run Failed", description: "An unexpected error occurred. Check console for details.", variant: "destructive" });
    } finally {
      setIsProcessingPayroll(false);
      fetchPayslips();
    }
  };


  const onSavePayrollSettings = async (data: PayrollSettingsFormValues) => {
    setIsSubmittingSettings(true);
    try {
      const settingsToSave: PayrollSettings = {
        deductions: data.deductions.map(d => ({ ...d, value: Number(d.value) })),
        otherRates: data.otherRates.map(r => ({ ...r, type: r.type as RateType, rate: Number(r.rate) })),
        taxRates: data.taxRates.map(t => ({...t, to: t.to === null ? null : Number(t.to)})),
        payslipCompanyName: data.payslipCompanyName || "",
        payslipCompanyAddress: data.payslipCompanyAddress || "",
        payslipCompanyContact: data.payslipCompanyContact || "",
        payslipCompanyWebsite: data.payslipCompanyWebsite || "",
        customFooter: data.customFooter || "",
      };
      const settingsDocRef = doc(db, 'companySettings', 'payroll');
      await setDoc(settingsDocRef, settingsToSave, { merge: true });
      setCurrentPayrollSettings(settingsToSave); // Update local state
      
      const adminName = employeeProfile?.name || "Admin";
      const adminNameParts = adminName.split(' ');
      const adminInitials = (adminNameParts.length > 1 ? `${adminNameParts[0][0]}${adminNameParts[adminNameParts.length - 1][0]}` : adminName.substring(0, 2)).toUpperCase();
      
      await addDoc(collection(db, "activityFeedItems"), {
        text: `updated the payroll settings.`,
        userId: user?.uid,
        userName: employeeProfile?.name || "Admin",
        userRole: employeeProfile?.permissionRole || "Administrator",
        avatarUrl: employeeProfile?.avatarUrl || "",
        avatarFallback: adminInitials,
        timestamp: new Date(),
        relatedEntityType: 'settings'
      });

      toast({ title: "Success", description: "Payroll settings saved.", variant: 'success' });
      setIsSettingsDialogOpen(false);
    } catch (error) {
      console.error("Error saving payroll settings:", error);
      toast({ title: "Error", description: "Failed to save payroll settings.", variant: "destructive" });
    } finally {
      setIsSubmittingSettings(false);
    }
  };
  
  const handleAddNewDeduction = () => {
    if (!newDeductionName.trim()) {
      toast({ title: "Validation Error", description: "Deduction name is required.", variant: "destructive" });
      return;
    }
    if (newDeductionValue === '' || newDeductionValue < 0) {
      toast({ title: "Validation Error", description: "Deduction value must be a non-negative number.", variant: "destructive" });
      return;
    }
    appendDeduction({
      id: `deduction_${Date.now()}`,
      name: newDeductionName,
      type: newDeductionType,
      value: Number(newDeductionValue),
      description: newDeductionDescription,
    });
    setNewDeductionName('');
    setNewDeductionType('fixed_amount');
    setNewDeductionValue('');
    setNewDeductionDescription('');
    toast({ title: "Deduction Staged", description: `${newDeductionName} added to the list. Save settings to persist.`});
  };

  const handleAddNewRate = () => {
    if (!newRateName.trim()) {
      toast({ title: "Validation Error", description: "Rate name is required.", variant: "destructive" });
      return;
    }
    if (newRateValue === '' || newRateValue < 0) {
      toast({ title: "Validation Error", description: "Rate value must be a non-negative number.", variant: "destructive" });
      return;
    }
    appendOtherRate({
      id: `rate_${Date.now()}`,
      name: newRateName,
      type: newRateType,
      rate: Number(newRateValue),
      description: newRateDescription,
    });
    setNewRateName('');
    setNewRateType('fixed_amount');
    setNewRateValue('');
    setNewRateDescription('');
    toast({ title: "Rate Staged", description: `${newRateName} added to the list. Save settings to persist.`});
  };

  const handleAddNewTaxBracket = () => {
    const fromVal = typeof newTaxBracketFrom === 'number' ? newTaxBracketFrom : -1;
    const rateVal = typeof newTaxBracketRate === 'number' ? newTaxBracketRate : -1;
    const baseVal = typeof newTaxBracketBase === 'number' ? newTaxBracketBase : -1;

    if (fromVal < 0 || rateVal < 0 || baseVal < 0) {
      toast({ title: "Validation Error", description: "From, Rate, and Base Tax must be non-negative numbers.", variant: "destructive" });
      return;
    }

    appendTaxRate({
        id: `tax_bracket_${Date.now()}`,
        from: fromVal,
        to: newTaxBracketTo === '' ? null : Number(newTaxBracketTo),
        rate: rateVal,
        baseAmount: baseVal,
        description: "",
    });
    
    setNewTaxBracketFrom('');
    setNewTaxBracketTo('');
    setNewTaxBracketRate('');
    setNewTaxBracketBase('');
    toast({ title: "Tax Bracket Staged", description: `New bracket starting from ${fromVal} added. Save settings to persist.`});
  };
  
  const handleBulkExport = async (action: 'print' | 'download') => {
    if (action === 'print') {
        setIsPrintWarningDialogOpen(true);
        return;
    }
    executeBulkExport(action);
  };

  const executeBulkExport = async (action: 'print' | 'download') => {
    if (!bulkExportEmployeeId) {
        toast({ title: 'Error', description: 'Please select an employee.', variant: 'destructive' });
        return;
    }
    setExportAction(action);
    setIsGeneratingExport(true);

    try {
        const year = parseInt(bulkExportYear, 10);
        let payslipQueryConstraints: any[] = [
            where('employeeId', '==', bulkExportEmployeeId),
            where('payrollYear', '==', year),
            orderBy('runDate', 'desc')
        ];
        
        if (bulkExportMonth !== 'all') {
            payslipQueryConstraints.push(where('payrollMonth', '==', bulkExportMonth));
        }

        if (bulkExportPeriod !== 'all') {
            payslipQueryConstraints.push(where('payrollPeriod', '==', bulkExportPeriod));
        }

        const q = query(collection(db, 'payslips'), ...payslipQueryConstraints);

        const payslipsSnap = await getDocs(q);
        let payslipsToExport = payslipsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Payslip));
        
        // Manual client-side sort for month/period as Firestore requires indexes for complex queries
        payslipsToExport.sort((a,b) => {
            if (a.payrollYear !== b.payrollYear) return a.payrollYear - b.payrollYear;
            const monthAIdx = monthNameToIndex(a.payrollMonth);
            const monthBIdx = monthNameToIndex(b.payrollMonth);
            if(monthAIdx !== monthBIdx) return monthAIdx - monthBIdx;
            const periodA = a.payrollPeriod === '1st-15th' ? 1 : a.payrollPeriod === '16th-end' ? 2 : 3;
            const periodB = b.payrollPeriod === '1st-15th' ? 1 : b.payrollPeriod === '16th-end' ? 2 : 3;
            return periodA - periodB;
        });

        if (payslipsToExport.length === 0) {
            toast({ title: 'No Payslips Found', description: 'No payslips were found for the selected criteria.', variant: 'default' });
            setIsGeneratingExport(false);
            return;
        }

        const employee = employees.find(e => e.id === bulkExportEmployeeId);
        const pdf = new jsPDF('p', 'mm', 'a4');
        let currentY = 10;
        const pageHeight = pdf.internal.pageSize.getHeight();
        const payslipHeight = 135; // Approximate height for one payslip with margin

        for (let i = 0; i < payslipsToExport.length; i++) {
            const payslip = payslipsToExport[i];
            
            if (currentY + payslipHeight > pageHeight && i > 0) {
                pdf.addPage();
                currentY = 10;
            }
            
            const uniqueId = `payslip-render-${payslip.id}`;

            const earningsRows = `
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 2px 0;">Basic Salary (for period)</td>
                    <td style="text-align: right; padding: 2px 0;">${formatCurrency(payslip.basicSalaryForPeriod, payslip.currency)}</td>
                </tr>
                ${payslip.appliedOtherRates.map(rate => `
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 2px 0; padding-left: 10px;">${rate.name} ${rate.detail ? `(${rate.detail})` : ''}</td>
                    <td style="text-align: right; padding: 2px 0;">+ ${formatCurrency(rate.calculatedAmount, payslip.currency)}</td>
                </tr>`).join('')}
            `;
            
            const deductionsRows = `
                ${payslip.appliedDeductions.map(deduction => `
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 2px 0; padding-left: 10px;">${deduction.name} ${deduction.detail ? `(${deduction.detail})` : ''}</td>
                    <td style="text-align: right; padding: 2px 0; color: #dc2626;">- ${formatCurrency(deduction.calculatedAmount, payslip.currency)}</td>
                </tr>`).join('')}
                ${(payslip.appliedLoans || []).map(loan => `
                <tr style="border-bottom: 1px solid #eee;">
                    <td style="padding: 2px 0; padding-left: 10px;">Loan Repayment (${loan.loanType})</td>
                    <td style="text-align: right; padding: 2px 0; color: #dc2626;">- ${formatCurrency(loan.deductionAmount, payslip.currency)}</td>
                </tr>`).join('')}
            `;
            
            const htmlContent = `
              <div id="${uniqueId}" style="width: 190mm; padding: 1cm; box-sizing: border-box; font-family: Arial, sans-serif; font-size: 9pt; color: #333;">
                <div style="text-align: center; border-bottom: 1px solid #ccc; padding-bottom: 4px; margin-bottom: 8px;">
                  <h2 style="font-size: 14pt; margin: 0; font-weight: bold;">${currentPayrollSettings?.payslipCompanyName || 'Company'}</h2>
                  <p style="font-size: 8pt; margin: 1px 0;">${currentPayrollSettings?.payslipCompanyAddress || ''}</p>
                  <p style="font-size: 8pt; margin: 1px 0;">${currentPayrollSettings?.payslipCompanyContact || ''}</p>
                  ${currentPayrollSettings?.payslipCompanyWebsite ? `<p style="font-size: 8pt; margin: 1px 0;">${currentPayrollSettings.payslipCompanyWebsite}</p>` : ''}
                </div>
                <h3 style="text-align: center; font-size: 12pt; margin: 4px 0 8px 0; font-weight: bold;">PAYSLIP</h3>
                
                <table style="width: 100%; border-collapse: collapse; margin-bottom: 8px; font-size: 8pt;">
                  <tbody>
                    <tr>
                        <td style="vertical-align: top; padding-right: 8px; width: 50%;">
                            <p style="margin:1.5px 0;"><strong>Employee:</strong> ${employee?.name || payslip.employeeName}</p>
                            ${employee?.dateOfBirth ? `<p style="margin:1.5px 0;"><strong>Date of Birth:</strong> ${format(parseISO(employee.dateOfBirth), 'MMMM dd, yyyy')}</p>` : ''}
                            <p style="margin:1.5px 0;"><strong>Employee ID:</strong> ${employee?.employeeId || payslip.humanReadableEmployeeId}</p>
                            <p style="margin:1.5px 0;"><strong>SSS No.:</strong> ${employee?.sssNumber || 'N/A'}</p>
                            <p style="margin:1.5px 0;"><strong>PhilHealth No.:</strong> ${employee?.philhealthNumber || 'N/A'}</p>
                            <p style="margin:1.5px 0;"><strong>Pag-IBIG No.:</strong> ${employee?.pagibigNumber || 'N/A'}</p>
                            <p style="margin:1.5px 0;"><strong>TIN:</strong> ${employee?.tinNumber || 'N/A'}</p>
                        </td>
                        <td style="vertical-align: top; padding-left: 8px; width: 50%;">
                            <p style="margin:1.5px 0;"><strong>Department:</strong> ${employee?.department || 'N/A'}</p>
                            <p style="margin:1.5px 0;"><strong>Role:</strong> ${employee?.role || 'N/A'}</p>
                            <p style="margin:1.5px 0;"><strong>Pay Period:</strong> ${payslip.payrollMonth} ${payslip.payrollYear} (${payslip.payrollPeriod})</p>
                            <p style="margin:1.5px 0;"><strong>Pay Date:</strong> ${payslip.runDate ? format(parseISO(payslip.runDate), 'MMMM dd, yyyy') : 'N/A'}</p>
                            <p style="margin:1.5px 0;"><strong>Bank Account:</strong> ${employee?.bankAccount || 'N/A'}</p>
                        </td>
                    </tr>
                  </tbody>
                </table>
                
                <table style="width: 100%; border-collapse: collapse; font-size: 9pt; margin-top: 8px;">
                  <thead>
                    <tr><th style="text-align: left; padding-bottom: 4px; font-weight: bold; border-bottom: 1px solid #999;">Earnings</th><th style="border-bottom: 1px solid #999;"></th></tr>
                  </thead>
                  <tbody>
                    ${earningsRows}
                    <tr style="font-weight: bold;">
                      <td style="padding-top: 4px;">Gross Pay</td>
                      <td style="text-align: right; padding-top: 4px;">${formatCurrency(payslip.grossPay, payslip.currency)}</td>
                    </tr>
                  </tbody>
                </table>

                <table style="width: 100%; border-collapse: collapse; font-size: 9pt; margin-top: 10px;">
                  <thead>
                    <tr><th style="text-align: left; padding-bottom: 4px; font-weight: bold; border-bottom: 1px solid #999;">Deductions</th><th style="border-bottom: 1px solid #999;"></th></tr>
                  </thead>
                  <tbody>
                    ${deductionsRows}
                    <tr style="font-weight: bold;">
                      <td style="padding-top: 4px;">Total Deductions</td>
                      <td style="text-align: right; padding-top: 4px; color: #dc2626;">${formatCurrency(payslip.totalDeductions, payslip.currency)}</td>
                    </tr>
                  </tbody>
                </table>

                <div style="font-weight: bold; font-size: 11pt; display: flex; justify-content: space-between; color: #0000FF; border-top: 2px solid #333; margin-top: 10px; padding-top: 4px;">
                  <span>Net Pay:</span>
                  <span>${formatCurrency(payslip.netPay, payslip.currency)}</span>
                </div>
              </div>
            `;

            
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = htmlContent;
            tempDiv.style.width = '210mm'; // A4 width
            tempDiv.style.position = 'absolute';
            tempDiv.style.left = '-9999px'; // Render off-screen
            document.body.appendChild(tempDiv);
            
            const payslipElement = document.getElementById(uniqueId);
            if (!payslipElement) throw new Error(`Could not find element with ID ${uniqueId}`);

            const canvas = await html2canvas(payslipElement, { scale: 2 });
            const imgData = canvas.toDataURL('image/png');
            
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const imgHeight = (canvas.height * pdfWidth) / canvas.width;
            
            pdf.addImage(imgData, 'PNG', 0, currentY, pdfWidth, imgHeight);
            currentY += imgHeight + 5; // Add a 5mm margin between payslips
            
            document.body.removeChild(tempDiv);
        }
        
        const filename = `payslip_report_${employee?.name.replace(/ /g, '_')}_${bulkExportYear}.pdf`;

        if (action === 'print') {
            pdf.autoPrint();
            window.open(pdf.output('bloburl'), '_blank');
        } else { // download
            pdf.save(filename);
        }

    } catch (error) {
        console.error("Error generating bulk payslip report:", error);
        toast({ title: 'Error', description: 'Failed to generate the report.', variant: 'destructive' });
    } finally {
        setIsGeneratingExport(false);
        setExportAction(null);
    }
  };


  const isLoading = isLoadingEmployees || isLoadingPayslips || isLoadingSettings || authLoading;

  return (
    <>
      <PageHeader
        icon={<DollarSign className="h-7 w-7 text-primary" />}
        title="Employee Payroll"
        description={isAdmin ? "View individual employee payroll history, run payroll, or configure payroll settings." : "View your personal payroll history and payslips."}
        actions={
          isAdmin && (
            <div className="flex gap-2 shrink-0">
                <Button variant="outline" onClick={() => setIsBulkExportDialogOpen(true)}>
                    <Download className="mr-2 h-4 w-4" /> Bulk Export
                </Button>
                <Button onClick={handleOpenSettingsDialog}>
                    <Settings className="mr-2 h-4 w-4" /> Payroll Settings
                </Button>
                <Button onClick={handleOpenRunPayrollDialog} className="bg-green-600 hover:bg-green-700 text-white">
                    <PlayCircle className="mr-2 h-4 w-4" /> Run Payroll
                </Button>
            </div>
          )
        }
      />
      
      <Card>
          <CardHeader>
            {isAdmin && (
                <div className="mt-4 pt-4">
                    <Label className="text-base font-semibold">Filter Employee</Label>
                    <Select value={selectedEmployeeId} onValueChange={setSelectedEmployeeId} disabled={isLoadingEmployees}>
                        <SelectTrigger className="w-full md:w-[280px] mt-2">
                            <span className="flex items-center">
                                <Users className="mr-2 h-4 w-4 text-muted-foreground" />
                                <SelectValue placeholder="Select Employee" />
                            </span>
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Employees</SelectItem>
                            {employees.map(emp => (
                                <SelectItem key={emp.id} value={emp.id}>{emp.name} ({emp.employeeId})</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            )}
          </CardHeader>
          <CardContent>
          {isLoading ? ( 
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="shadow-md">
                  <CardContent className="p-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4 flex-grow">
                      <Skeleton className="h-14 w-14 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-5 w-32" />
                        <Skeleton className="h-4 w-48" />
                      </div>
                    </div>
                    <div className="flex items-center gap-x-4 shrink-0">
                      <div className="text-right min-w-[140px] space-y-2">
                        <Skeleton className="h-5 w-24 ml-auto" />
                        <Skeleton className="h-4 w-20 ml-auto" />
                      </div>
                      <Skeleton className="h-10 w-28" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !isLoadingEmployees && filteredEmployees.length === 0 ? ( 
            <Card>
                <CardContent className="p-6 text-center text-muted-foreground">
                    {selectedEmployeeId === 'all' && employees.length === 0 ? 'No employees found in the system.' : 'No employee found for the selected filter.'}
                </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredEmployees.map((employee) => {
                const employeeLatestPayslip = allPayslips
                     .filter(p => p.employeeId === employee.id && !p.isArchived)
                     .sort((a, b) => {
                         if (b.payrollYear !== a.payrollYear) {
                             return b.payrollYear - a.payrollYear;
                         }
                         const monthAidx = monthNameToIndex(a.payrollMonth);
                         const monthBidx = monthNameToIndex(b.payrollMonth);
                         if (monthBidx !== monthAidx) {
                             return monthBidx - monthAidx;
                         }
                         const periodPrecedence = { 'fullMonth': 0, '16th-end': 1, '1st-15th': 2 }; 
                         const precedenceA = periodPrecedence[a.payrollPeriod as keyof typeof periodPrecedence] ?? 99;
                         const precedenceB = periodPrecedence[b.payrollPeriod as keyof typeof periodPrecedence] ?? 99;
                         if (precedenceA !== precedenceB) {
                             return precedenceA - precedenceB; 
                         }
                         return b.runDate.localeCompare(a.runDate);
                      })[0];

                const nameParts = employee.name.split(' ');
                const initials = (
                  nameParts.length > 1
                    ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}`
                    : employee.name.substring(0, 2)
                ).toUpperCase();

                return (
                  <Card key={employee.id} className="shadow-md hover:shadow-lg transition-shadow duration-200">
                    <CardContent className="p-4 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4 flex-grow">
                        <Avatar className="h-14 w-14">
                          <AvatarImage src={employee.avatarUrl || `https://placehold.co/80x80.png?text=${initials}`} alt={employee.name} data-ai-hint="employee avatar"/>
                          <AvatarFallback>{initials}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-lg font-semibold text-foreground">{employee.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {employee.department} • ID: {employee.employeeId}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-x-4 shrink-0">
                        <div className="text-right min-w-[140px]">
                          {isLoadingPayslips && !employeeLatestPayslip ? (
                            <>
                              <Skeleton className="h-5 w-24 mb-1" />
                              <Skeleton className="h-4 w-20" />
                            </>
                          ) : employeeLatestPayslip ? (
                            <>
                              <p className="text-md font-semibold text-green-600 dark:text-green-400">
                                {formatCurrency(employeeLatestPayslip.netPay, employeeLatestPayslip.currency)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {`${employeeLatestPayslip.payrollMonth} ${employeeLatestPayslip.payrollYear} (${employeeLatestPayslip.payrollPeriod})`}
                              </p>
                            </>
                          ) : (
                            <p className="text-sm text-muted-foreground">No payroll data</p>
                          )}
                        </div>
                        <Button variant="outline" onClick={() => router.push(`/payroll/${employee.id}`)} className="shrink-0">
                           <Eye className="mr-0 md:mr-2 h-4 w-4" />
                           <span className="hidden md:inline">View Payslips</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isSettingsDialogOpen} onOpenChange={setIsSettingsDialogOpen}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>Payroll Settings</DialogTitle>
            <DialogDescription>Configure deductions, tax rates, payslip appearance, and other payroll parameters.</DialogDescription>
          </DialogHeader>
          {isLoadingSettings ? (
            <div className="flex items-center justify-center h-40">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
              <p className="ml-2">Loading settings...</p>
            </div>
          ) : (
            <Form {...settingsForm}>
              <form onSubmit={settingsForm.handleSubmit(onSavePayrollSettings)}>
                <Tabs value={activeSettingsTab} onValueChange={setActiveSettingsTab} className="mt-4">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="deductions"><TrendingDown className="h-4 w-4" />Deductions</TabsTrigger>
                    <TabsTrigger value="taxRates"><Landmark className="h-4 w-4" />Tax Rates</TabsTrigger>
                    <TabsTrigger value="otherRates"><TrendingUp className="h-4 w-4" />Other Rates</TabsTrigger>
                    <TabsTrigger value="appearance"><Palette className="h-4 w-4" />Appearance</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="deductions" className="mt-6">
                    <ScrollArea className="h-[400px] pr-3">
                      <h3 className="text-lg font-medium mb-2 mt-4">Current Deductions:</h3>
                      {deductionFields.length === 0 && <p className="text-muted-foreground text-center py-4">No deductions configured yet.Add one below.</p>}
                      <div className="space-y-4">
                        {deductionFields.map((item, index) => (
                          <Card key={item.id} className="p-4 bg-muted/30">
                            <FormItem>
                              <div className="flex justify-between items-start mb-3">
                                 <FormField
                                  control={settingsForm.control}
                                  name={`deductions.${index}.name`}
                                  render={({ field }) => (
                                    <FormItem className="flex-grow mr-2">
                                      <FormLabel className="sr-only">Deduction Name</FormLabel>
                                       <FormControl><Input {...field} placeholder="Deduction Name" className="text-md font-semibold" /></FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                <Button type="button" variant="ghost" size="icon" onClick={() => removeDeduction(index)} className="text-destructive hover:bg-destructive/10 h-7 w-7">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                                <FormField
                                  control={settingsForm.control}
                                  name={`deductions.${index}.type`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Type</FormLabel>
                                      <Select onValueChange={field.onChange} value={field.value as DeductionType}>
                                        <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                                        <SelectContent>
                                          <SelectItem value="percentage_basic">Percentage of Basic</SelectItem>
                                          <SelectItem value="fixed_amount">Fixed Amount (PHP)</SelectItem>
                                        </SelectContent>
                                      </Select>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                <FormField
                                  control={settingsForm.control}
                                  name={`deductions.${index}.value`}
                                  render={({ field }) => (
                                    <FormItem className="relative">
                                      <FormLabel>Value</FormLabel>
                                      <FormControl><Input type="number" {...field} onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)} className="pr-10" /></FormControl>
                                      <span className="absolute right-3 top-1/2 mt-2.5 text-sm text-muted-foreground">{settingsForm.watch(`deductions.${index}.type`) === 'percentage_basic' ? '%' : 'PHP'}</span>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                               <FormField
                                control={settingsForm.control}
                                name={`deductions.${index}.description`}
                                render={({ field }) => (
                                  <FormItem className="mt-3">
                                    <FormLabel>Description</FormLabel>
                                    <FormControl><Textarea {...field} placeholder="Brief description" className="text-sm" rows={2} /></FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </FormItem>
                          </Card>
                        ))}
                      </div>
                       <Card className="p-4 mt-6 bg-background shadow">
                        <CardTitle className="text-md font-semibold mb-3">Add New Deduction</CardTitle>
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="newDeductionName">Deduction Name</Label>
                            <Input id="newDeductionName" value={newDeductionName} onChange={(e) => setNewDeductionName(e.target.value)} placeholder="e.g., SSS Contribution" />
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <Label htmlFor="newDeductionType">Type</Label>
                              <Select value={newDeductionType} onValueChange={(value) => setNewDeductionType(value as DeductionType)}>
                                <SelectTrigger id="newDeductionType"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="percentage_basic">Percentage of Basic</SelectItem>
                                  <SelectItem value="fixed_amount">Fixed Amount (PHP)</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="relative">
                              <Label htmlFor="newDeductionValue">Value</Label>
                              <Input id="newDeductionValue" type="number" value={newDeductionValue} onChange={(e) => setNewDeductionValue(e.target.value === '' ? '' : parseFloat(e.target.value))} placeholder="Amount or %" className="pr-10"/>
                              <span className="absolute right-3 top-1/2 mt-2.5 text-sm text-muted-foreground">{newDeductionType === 'percentage_basic' ? '%' : 'PHP'}</span>
                            </div>
                           </div>
                          <div>
                            <Label htmlFor="newDeductionDescription">Description (Optional)</Label>
                            <Textarea id="newDeductionDescription" value={newDeductionDescription} onChange={(e) => setNewDeductionDescription(e.target.value)} placeholder="Briefly describe this deduction" rows={2} />
                          </div>
                          <Button type="button" onClick={handleAddNewDeduction} className="w-full sm:w-auto">
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Deduction to List
                          </Button>
                        </div>
                      </Card>
                    </ScrollArea>
                  </TabsContent>
                  <TabsContent value="taxRates" className="mt-6">
                    <ScrollArea className="h-[400px] pr-3">
                        <h3 className="text-lg font-medium mb-2 mt-4">Current Tax Brackets:</h3>
                        {taxRateFields.length === 0 && <p className="text-muted-foreground text-center py-4">No tax brackets configured. Add one below.</p>}
                        <div className="space-y-4">
                            {taxRateFields.map((item, index) => (
                                <Card key={item.id} className="p-4 bg-muted/30">
                                <FormItem>
                                    <div className="flex justify-end">
                                    <Button type="button" variant="ghost" size="icon" onClick={() => removeTaxRate(index)} className="text-destructive hover:bg-destructive/10 h-7 w-7">
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                    </div>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 items-start">
                                    <FormField control={settingsForm.control} name={`taxRates.${index}.from`} render={({ field }) => (<FormItem><FormLabel>From (PHP)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)} />
                                    <FormField control={settingsForm.control} name={`taxRates.${index}.to`} render={({ field }) => (<FormItem><FormLabel>To (PHP)</FormLabel><FormControl><Input type="number" {...field} placeholder="Infinity" /></FormControl><FormMessage /></FormItem>)} />
                                    <FormField control={settingsForm.control} name={`taxRates.${index}.rate`} render={({ field }) => (<FormItem><FormLabel>Rate (%)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)} />
                                    <FormField control={settingsForm.control} name={`taxRates.${index}.baseAmount`} render={({ field }) => (<FormItem><FormLabel>Base Tax (PHP)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>)} />
                                    </div>
                                </FormItem>
                                </Card>
                            ))}
                        </div>
                        <Card className="p-4 mt-6 bg-background shadow">
                            <CardTitle className="text-md font-semibold mb-3">Add New Tax Bracket</CardTitle>
                            <div className="space-y-3">
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    <div><Label htmlFor="newTaxBracketFrom">From (PHP)</Label><Input id="newTaxBracketFrom" type="number" value={newTaxBracketFrom} onChange={e => setNewTaxBracketFrom(e.target.value === '' ? '' : parseFloat(e.target.value))} placeholder="e.g., 250000" /></div>
                                    <div><Label htmlFor="newTaxBracketTo">To (PHP)</Label><Input id="newTaxBracketTo" type="number" value={newTaxBracketTo} onChange={e => setNewTaxBracketTo(e.target.value === '' ? '' : parseFloat(e.target.value))} placeholder="Leave blank for infinity" /></div>
                                    <div><Label htmlFor="newTaxBracketRate">Rate (%)</Label><Input id="newTaxBracketRate" type="number" value={newTaxBracketRate} onChange={e => setNewTaxBracketRate(e.target.value === '' ? '' : parseFloat(e.target.value))} placeholder="e.g., 20" /></div>
                                    <div><Label htmlFor="newTaxBracketBase">Base Tax (PHP)</Label><Input id="newTaxBracketBase" type="number" value={newTaxBracketBase} onChange={e => setNewTaxBracketBase(e.target.value === '' ? '' : parseFloat(e.target.value))} placeholder="e.g., 22500" /></div>
                                </div>
                                <Button type="button" onClick={handleAddNewTaxBracket} className="w-full sm:w-auto"><PlusCircle className="mr-2 h-4 w-4" /> Add Bracket</Button>
                            </div>
                        </Card>
                    </ScrollArea>
                  </TabsContent>
                  <TabsContent value="otherRates" className="mt-6">
                    <ScrollArea className="h-[400px] pr-3">
                      <h3 className="text-lg font-medium mb-2 mt-4">Current Rates:</h3>
                      {otherRateFields.length === 0 && <p className="text-muted-foreground text-center py-4">No other rates configured. Add one below.</p>}
                      <div className="space-y-4">
                        {otherRateFields.map((item, index) => (
                          <Card key={item.id} className="p-4 bg-muted/30">
                             <FormItem>
                              <div className="flex justify-between items-start mb-3">
                                <FormField
                                  control={settingsForm.control}
                                  name={`otherRates.${index}.name`}
                                  render={({ field }) => (
                                    <FormItem className="flex-grow mr-2">
                                      <FormLabel className="sr-only">Rate Name</FormLabel>
                                       <FormControl><Input {...field} placeholder="Rate Name" className="text-md font-semibold" /></FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                <Button type="button" variant="ghost" size="icon" onClick={() => removeOtherRate(index)} className="text-destructive hover:bg-destructive/10 h-7 w-7">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                                <FormField
                                  control={settingsForm.control}
                                  name={`otherRates.${index}.type`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Type</FormLabel>
                                      <Select onValueChange={field.onChange} value={field.value as RateType}>
                                        <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                                        <SelectContent>
                                          <SelectItem value="percentage">Percentage</SelectItem>
                                          <SelectItem value="fixed_amount">Fixed Amount (PHP)</SelectItem>
                                        </SelectContent>
                                      </Select>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                <FormField
                                  control={settingsForm.control}
                                  name={`otherRates.${index}.rate`}
                                  render={({ field }) => (
                                    <FormItem className="relative">
                                      <FormLabel>Value</FormLabel>
                                      <FormControl><Input type="number" {...field} onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)} className="pr-10" /></FormControl>
                                      <span className="absolute right-3 top-1/2 mt-2.5 text-sm text-muted-foreground">{settingsForm.watch(`otherRates.${index}.type`) === 'percentage' ? '%' : 'PHP'}</span>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                              <FormField
                                control={settingsForm.control}
                                name={`otherRates.${index}.description`}
                                render={({ field }) => (
                                  <FormItem className="mt-3">
                                    <FormLabel>Description</FormLabel>
                                    <FormControl><Textarea {...field} placeholder="Brief description" className="text-sm" rows={2} /></FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                            </FormItem>
                          </Card>
                        ))}
                      </div>
                       <Card className="p-4 mt-6 bg-background shadow">
                        <CardTitle className="text-md font-semibold mb-3">Add New Rate</CardTitle>
                        <div className="space-y-3">
                          <div>
                            <Label htmlFor="newRateName">Rate Name</Label>
                            <Input id="newRateName" value={newRateName} onChange={(e) => setNewRateName(e.target.value)} placeholder="e.g., Night Differential" />
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                                <Label htmlFor="newRateType">Type</Label>
                                <Select value={newRateType} onValueChange={(value) => setNewRateType(value as RateType)}>
                                    <SelectTrigger id="newRateType"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                    <SelectItem value="percentage">Percentage</SelectItem>
                                    <SelectItem value="fixed_amount">Fixed Amount (PHP)</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="relative">
                                <Label htmlFor="newRateValue">Value</Label>
                                <Input id="newRateValue" type="number" value={newRateValue} onChange={(e) => setNewRateValue(e.target.value === '' ? '' : parseFloat(e.target.value))} placeholder="Amount or %" className="pr-10"/>
                                <span className="absolute right-3 top-1/2 mt-2.5 text-sm text-muted-foreground">{newRateType === 'percentage' ? '%' : 'PHP'}</span>
                            </div>
                           </div>
                          <div>
                            <Label htmlFor="newRateDescription">Description (Optional)</Label>
                            <Textarea id="newRateDescription" value={newRateDescription} onChange={(e) => setNewRateDescription(e.target.value)} placeholder="Briefly describe this rate" rows={2} />
                          </div>
                          <Button type="button" onClick={handleAddNewRate} className="w-full sm:w-auto">
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Rate to List
                          </Button>
                        </div>
                      </Card>
                    </ScrollArea>
                  </TabsContent>
                  <TabsContent value="appearance" className="mt-6">
                    <ScrollArea className="h-[400px] pr-3">
                      <div className="space-y-6 px-2">
                        <FormField
                          control={settingsForm.control}
                          name="payslipCompanyName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-base">Company Name (for print)</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="e.g., Your Company LLC"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                This name will appear at the top of the printed payslip.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="payslipCompanyAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-base">Company Address (for print)</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="e.g., 123 Main St, Anytown, ST 12345"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                The company's physical or mailing address.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="payslipCompanyContact"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-base">Company Contact (for print)</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="e.g., contact@example.com | (555) 123-4567"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Email and/or phone number for company inquiries.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="payslipCompanyWebsite"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-base">Company Website (Optional, for print)</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="e.g., https://www.example.com"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Your company's official website.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="customFooter"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-base">Payslip Footer (for print)</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="e.g., This is a computer-generated document and requires no signature. For inquiries, contact HR."
                                  rows={3}
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                This content will appear at the bottom of each printed payslip.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </ScrollArea>
                  </TabsContent>
                </Tabs>
                <DialogFooter className="mt-6 pt-4 border-t">
                  <DialogClose asChild>
                    <Button type="button" variant="outline">
                      <XCircle className="mr-2 h-4 w-4" /> Cancel
                    </Button>
                  </DialogClose>
                  <Button type="submit" formNoValidate disabled={isSubmittingSettings}>
                    {isSubmittingSettings ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                    Save Settings
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isRunPayrollDialogOpen} onOpenChange={setIsRunPayrollDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Generate Payroll</DialogTitle>
            <DialogDescription>
              Select target employee(s), month, and period. Payroll will be
              generated for the selection. Deductions based on current
              settings. Currency: PHP.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="payrollTargetEmployeeOption">For</Label>
              <Select value={payrollTargetEmployeeOption} onValueChange={setPayrollTargetEmployeeOption} disabled={isProcessingPayroll}>
                <SelectTrigger id="payrollTargetEmployeeOption">
                  <SelectValue placeholder="Select target employees" />
                </SelectTrigger>
                <SelectContent>
                  {payrollTargetOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="payrollMonthYear">Month</Label>
              <Select value={payrollMonthYear} onValueChange={setPayrollMonthYear} disabled={isProcessingPayroll}>
                <SelectTrigger id="payrollMonthYear">
                  <SelectValue placeholder="Select month and year" />
                </SelectTrigger>
                <SelectContent>
                  {monthYearOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="payrollPayPeriod">Period</Label>
              <Select value={payrollPayPeriod} onValueChange={setPayrollPayPeriod} disabled={isProcessingPayroll}>
                <SelectTrigger id="payrollPayPeriod">
                  <SelectValue placeholder="Select pay period" />
                </SelectTrigger>
                <SelectContent>
                  {payPeriodOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" disabled={isProcessingPayroll}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button>
            </DialogClose>
            <Button onClick={prepareAndShowPayrollReview} disabled={isProcessingPayroll || isLoadingEmployees}>
              {isLoadingEmployees ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlayCircle className="mr-2 h-4 w-4" />}
              Review Payroll
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isPayrollReviewDialogOpen} onOpenChange={setIsPayrollReviewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Payroll Run Review</DialogTitle>
            <DialogDescription>
              Review the employees to be processed for {payrollMonthYear} ({payrollPayPeriod}).
              Employees with issues will be skipped during the actual payroll run.
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh] my-4 pr-3">
            <div className="space-y-3">
              {employeesForReview.length === 0 && (
                <p className="text-muted-foreground text-center py-4">No employees selected for this payroll run.</p>
              )}
              {employeesForReview.map(({ employee, issues }) => (
                <Card key={employee.id} className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                         <AvatarImage src={employee.avatarUrl || `https://placehold.co/40x40.png?text=${employee.name.charAt(0)}`} alt={employee.name} data-ai-hint="employee avatar"/>
                         <AvatarFallback>{(employee.name?.split(' ').length > 1 ? `${employee.name.split(' ')[0][0]}${employee.name.split(' ')[employee.name.split(' ').length - 1][0]}` : employee.name?.substring(0, 2) || '').toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-xs text-muted-foreground">ID: {employee.employeeId}</p>
                      </div>
                    </div>
                    {issues.length > 0 ? (
                      <Badge variant="destructive" className="flex items-center gap-1.5">
                        <AlertTriangle className="h-3.5 w-3.5" />
                        {issues.join(', ')}
                      </Badge>
                    ) : (
                      <Badge variant="default" className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700">
                        <CheckCircle className="h-3.5 w-3.5" />
                        Ready
                      </Badge>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </ScrollArea>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPayrollReviewDialogOpen(false)} disabled={isProcessingPayroll}>
              <XCircle className="mr-2 h-4 w-4"/>Cancel
            </Button>
            <Button onClick={handleProceedFromReview} disabled={isProcessingPayroll || employeesForReview.filter(e => e.issues.length === 0).length === 0}>
              {isProcessingPayroll ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlayCircle className="mr-2 h-4 w-4" />}
              Proceed with Payroll
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Bulk Export Dialog */}
      <Dialog open={isBulkExportDialogOpen} onOpenChange={setIsBulkExportDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
                <DialogTitle>Bulk Export Payslips</DialogTitle>
                <DialogDescription>
                  Select an employee and the desired period to generate a printable report of their payslips.
                </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="bulk-export-employee">Employee</Label>
                  <Select value={bulkExportEmployeeId} onValueChange={setBulkExportEmployeeId} disabled={isGeneratingExport}>
                      <SelectTrigger id="bulk-export-employee">
                        <SelectValue placeholder="Select an employee" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map(emp => (
                            <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
                        ))}
                      </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                      <Label htmlFor="bulk-export-year">Year</Label>
                      <Select value={bulkExportYear} onValueChange={setBulkExportYear} disabled={isGeneratingExport}>
                          <SelectTrigger id="bulk-export-year"><SelectValue /></SelectTrigger>
                          <SelectContent>
                              {Array.from({ length: 10 }, (_, i) => getYear(new Date()) - i).map(year => (
                                  <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                              ))}
                          </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="bulk-export-month">Month</Label>
                      <Select value={bulkExportMonth} onValueChange={setBulkExportMonth} disabled={isGeneratingExport}>
                          <SelectTrigger id="bulk-export-month"><SelectValue /></SelectTrigger>
                          <SelectContent>
                              <SelectItem value="all">All Months</SelectItem>
                              {["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"].map(month => (
                                <SelectItem key={month} value={month}>{month}</SelectItem>
                              ))}
                          </SelectContent>
                      </Select>
                  </div>
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="bulk-export-period">Pay Period</Label>
                    <Select value={bulkExportPeriod} onValueChange={setBulkExportPeriod} disabled={isGeneratingExport || bulkExportMonth === 'all'}>
                        <SelectTrigger id="bulk-export-period"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Periods</SelectItem>
                            <SelectItem value="1st-15th">1st-15th</SelectItem>
                            <SelectItem value="16th-end">16th-end</SelectItem>
                            <SelectItem value="fullMonth">Full Month</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>
            <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline" disabled={isGeneratingExport}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button>
                </DialogClose>
                <Button variant="secondary" onClick={() => executeBulkExport('download')} disabled={isGeneratingExport || !bulkExportEmployeeId}>
                  {exportAction === 'download' && isGeneratingExport ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                  Download
                </Button>
                <Button onClick={() => handleBulkExport('print')} disabled={isGeneratingExport || !bulkExportEmployeeId}>
                  {exportAction === 'print' && isGeneratingExport ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Printer className="mr-2 h-4 w-4" />}
                  Print
                </Button>
            </DialogFooter>
          </DialogContent>
      </Dialog>
      <AlertDialog open={isPrintWarningDialogOpen} onOpenChange={setIsPrintWarningDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Printing Recommendation</AlertDialogTitle>
            <AlertDialogDescription>
                Some payslips might cut off depending on your printer's margins. If the layout is incorrect on A4, try printing with Letter size paper instead.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsPrintWarningDialogOpen(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              setIsPrintWarningDialogOpen(false);
              executeBulkExport('print');
            }}>
              Proceed to Print
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
