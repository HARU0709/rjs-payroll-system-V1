

'use client';

import { useState, useEffect, useMemo, type FormEvent, type FC } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, UserCheck, CalendarClock, DollarSign, ListChecks, Loader2, MessageSquareText, Sun, Moon, LogIn, LogOut, Coffee, Home as HomeIcon, AlertCircle, Briefcase, Plane, UserX, CalendarOff, AlarmClock, LayoutDashboard, Megaphone, ArrowRight, Send, MessageSquare, Edit, Trash2, Reply, MoreHorizontal, XCircle, ChevronLeft, ChevronRight, FileText, Globe, History, Fingerprint } from 'lucide-react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { db } from '@/lib/firebase';
import { collection, query, where, onSnapshot, Timestamp, orderBy, limit as firestoreLimit, doc, setDoc, getDoc, addDoc, limit, getDocs, writeBatch, updateDoc, deleteDoc } from 'firebase/firestore';
import type { Employee, LeaveRequest, ActivityFeedItem as ActivityFeedItemType, AttendanceRecord, AttendanceSettings, Announcement, AnnouncementComment } from '@/types';
import { format, endOfMonth, isValid, isWithinInterval, startOfDay, parseISO, formatDistanceToNow } from 'date-fns';
import { useAuth } from '@/contexts/auth-context';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader } from '@/components/shared/page-header';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

type CommentWithReplies = AnnouncementComment & { replies: CommentWithReplies[] };


function UserDashboard() {
  const { user, employeeProfile } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  const { toast } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [time, setTime] = useState('');
  const [period, setPeriod] = useState('');
  const [todaysRecord, setTodaysRecord] = useState<Partial<AttendanceRecord> | null>(null);
  const [loadingRecord, setLoadingRecord] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [allAnnouncements, setAllAnnouncements] = useState<Announcement[]>([]);
  const [currentAnnouncementIndex, setCurrentAnnouncementIndex] = useState(0);
  const [loadingAnnouncement, setLoadingAnnouncement] = useState(true);

  // State for announcement details dialog
  const [isViewAnnouncementDialogOpen, setIsViewAnnouncementDialogOpen] = useState(false);
  const [selectedAnnouncementForView, setSelectedAnnouncementForView] = useState<Announcement | null>(null);
  const [comments, setComments] = useState<CommentWithReplies[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  
  // State for comment actions
  const [editingComment, setEditingComment] = useState<{ id: string; text: string } | null>(null);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [commentToDelete, setCommentToDelete] = useState<AnnouncementComment | null>(null);
  const [isDeleteCommentDialogOpen, setIsDeleteCommentDialogOpen] = useState(false);


  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setTime(format(now, 'hh:mm:ss'));
      setPeriod(format(now, 'a').toUpperCase());
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  
  useEffect(() => {
    if (!user) return;
    setLoadingRecord(true);
    const dateStr = format(new Date(), 'yyyy-MM-dd');
    const docId = `${user.uid}_${dateStr}`;
    const docRef = doc(db, 'attendanceRecords', docId);

    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        setTodaysRecord(docSnap.data());
      } else {
        setTodaysRecord({}); // No record for today yet
      }
      setLoadingRecord(false);
    }, (error) => {
      console.error("Error fetching attendance:", error);
      setLoadingRecord(false);
    });
    
    setLoadingAnnouncement(true);
    const q = query(collection(db, 'announcements'), where("isPublished", "==", true));
    const unsubAnnouncement = onSnapshot(q, (snapshot) => {
      const fetchedAnnouncements = snapshot.docs.map(doc => {
          const data = doc.data();
          return {
            id: doc.id,
            ...data,
            timestamp: data.timestamp?.toDate ? data.timestamp.toDate() : new Date(0),
          } as Announcement;
      });
      
      fetchedAnnouncements.sort((a,b) => b.timestamp.getTime() - a.timestamp.getTime());
      
      setAllAnnouncements(fetchedAnnouncements);
      setCurrentAnnouncementIndex(0);
      setLoadingAnnouncement(false);
    }, (error) => {
      console.error("Error fetching latest announcement for user:", error);
      setLoadingAnnouncement(false);
      toast({ title: 'Error', description: 'Could not fetch announcements.', variant: 'destructive' });
    });

    return () => {
      unsubscribe();
      unsubAnnouncement();
    };
  }, [user, toast]);

  useEffect(() => {
    const announcementId = searchParams.get('announcement');
    if (announcementId) {
      const fetchAndShowAnnouncement = async () => {
        try {
          const docRef = doc(db, 'announcements', announcementId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const announcementData = {
              id: docSnap.id,
              ...docSnap.data(),
              timestamp: docSnap.data().timestamp?.toDate ? docSnap.data().timestamp.toDate() : new Date(0),
            } as Announcement;
            handleOpenAnnouncementDialog(announcementData);
          } else {
            toast({ title: "Not Found", description: "The requested announcement does not exist.", variant: "destructive" });
          }
        } catch (error) {
          toast({ title: "Error", description: "Failed to fetch the announcement.", variant: "destructive" });
        } finally {
          router.replace('/dashboard', { scroll: false });
        }
      };
      fetchAndShowAnnouncement();
    }
  }, [searchParams, router, toast]);
  
  const handleNextAnnouncement = () => {
    if (currentAnnouncementIndex < allAnnouncements.length - 1) {
      setCurrentAnnouncementIndex(prev => prev + 1);
    }
  };
  const handlePrevAnnouncement = () => {
    if (currentAnnouncementIndex > 0) {
      setCurrentAnnouncementIndex(prev => prev - 1);
    }
  };

  const nestComments = (list: AnnouncementComment[]): CommentWithReplies[] => {
      const listWithReplies = list.map(c => ({ ...c, replies: [] as CommentWithReplies[] }));
      const map = new Map(listWithReplies.map(c => [c.id, c]));
      const roots: CommentWithReplies[] = [];
      for (const comment of map.values()) {
          if (comment.parentCommentId && map.has(comment.parentCommentId)) {
              map.get(comment.parentCommentId)!.replies.push(comment);
          } else {
              roots.push(comment);
          }
      }
      return roots;
  };

  useEffect(() => {
    if (!selectedAnnouncementForView) {
        setComments([]);
        return;
    }

    setLoadingComments(true);
    const commentsQuery = query(
        collection(db, 'announcementComments'),
        where('announcementId', '==', selectedAnnouncementForView.id)
    );

    const unsubscribe = onSnapshot(commentsQuery, (snapshot) => {
        const fetchedComments = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            timestamp: doc.data().timestamp?.toDate ? doc.data().timestamp.toDate() : new Date(),
        } as AnnouncementComment));
        
        fetchedComments.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());

        const nested = nestComments(fetchedComments);
        setComments(nested);
        setLoadingComments(false);
    }, (error) => {
        console.error("Error fetching comments:", error);
        toast({ title: "Error", description: "Could not load comments. Check permissions.", variant: "destructive" });
        setLoadingComments(false);
    });

    return () => unsubscribe();
  }, [selectedAnnouncementForView, toast]);


  const handleClockEvent = async (eventType: 'morningIn' | 'lunchOut' | 'lunchIn' | 'afternoonOut') => {
    if (!user || !employeeProfile) return;
    setIsProcessing(true);
    const timeStr = format(new Date(), 'HH:mm');
    const dateStr = format(new Date(), 'yyyy-MM-dd');
    const docId = `${user.uid}_${dateStr}`;
    const docRef = doc(db, 'attendanceRecords', docId);

    const nameParts = employeeProfile.name.split(' ');
    const initials = (
      nameParts.length > 1
        ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}`
        : employeeProfile.name.substring(0, 2)
    ).toUpperCase();

    try {
        const updateData: Partial<AttendanceRecord> = {
            employeeId: user.uid,
            date: dateStr,
            [eventType]: timeStr
        };

        // If clocking in for the morning, stamp the current shift ID onto the record.
        if (eventType === 'morningIn') {
            updateData.shiftId = employeeProfile.shiftId || null;
        }

      await setDoc(docRef, updateData, { merge: true });

      const eventTextMap = {
        morningIn: 'clocked in for the morning.',
        lunchOut: 'clocked out for lunch.',
        lunchIn: 'clocked back in from lunch.',
        afternoonOut: 'clocked out for the day.'
      };
      
       await addDoc(collection(db, "activityFeedItems"), {
        text: eventTextMap[eventType],
        userId: user.uid,
        userName: employeeProfile.name,
        userRole: employeeProfile.permissionRole || "User",
        avatarUrl: employeeProfile.avatarUrl || "",
        avatarFallback: initials,
        timestamp: new Date(),
        relatedEntityType: 'profile',
        relatedEntityId: user.uid,
      });

    } catch (error) {
      console.error("Clock-in error:", error);
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleOpenAnnouncementDialog = (announcement: Announcement | null) => {
    if (!announcement) return;
    setSelectedAnnouncementForView(announcement);
    setIsViewAnnouncementDialogOpen(true);
  };
  
  const handleCommentSubmit = async (e: FormEvent, text: string, parentId?: string) => {
    e.preventDefault();
    if (!text.trim() || !user || !employeeProfile || !selectedAnnouncementForView) return;
  
    setIsSubmittingComment(true);
  
    const nameParts = employeeProfile.name.split(' ');
    const initials = (nameParts.length > 1 ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}` : employeeProfile.name.substring(0, 2)).toUpperCase();
  
    const commentData: Omit<AnnouncementComment, 'id'> = {
        announcementId: selectedAnnouncementForView.id,
        userId: user.uid,
        userName: employeeProfile.name,
        userAvatarUrl: employeeProfile.avatarUrl || '',
        userAvatarFallback: initials,
        commentText: text.trim(),
        timestamp: new Date(),
        ...(parentId && { parentCommentId: parentId }),
    };
  
    try {
      await addDoc(collection(db, 'announcementComments'), commentData);
      
      if (parentId) {
          setReplyingTo(null);
          setReplyContent('');
      } else {
          setNewComment('');
      }
    } catch (error) {
      console.error("Error posting comment:", error);
      toast({ title: "Error", description: "Could not post your comment. Check your permissions.", variant: "destructive" });
      setIsSubmittingComment(false);
      return;
    }
  
    // This runs after successfully posting a comment.
    try {
        const q = query(collection(db, "employees"), where("permissionRole", "==", "Administrator"));
        const adminsSnapshot = await getDocs(q);

        if (!adminsSnapshot.empty) {
            const batch = writeBatch(db);
            const notificationText = `${employeeProfile.name} commented on the announcement: "${selectedAnnouncementForView.title}"`;
            adminsSnapshot.forEach(adminDoc => {
                const adminId = adminDoc.id;
                if (adminId !== user.uid) { // Don't notify the user who commented
                    const notificationRef = doc(collection(db, "notifications"));
                    batch.set(notificationRef, {
                        userId: adminId,
                        type: 'info',
                        text: notificationText,
                        timestamp: new Date(),
                        isRead: false,
                        link: `/announcements?announcement=${selectedAnnouncementForView.id}`, 
                    });
                }
            });
            await batch.commit();
        }
    } catch (notificationError) {
        // Log this warning but don't show an error to the user, as their primary action (commenting) was successful.
        console.warn("Comment posted, but failed to notify admins:", notificationError);
    }
  
    setIsSubmittingComment(false);
  };
  
  const handleUpdateComment = async (commentId: string, text: string) => {
    if (!text.trim()) return;
    setIsSubmittingComment(true);
    try {
      const commentRef = doc(db, 'announcementComments', commentId);
      await updateDoc(commentRef, { commentText: text.trim() });
      toast({ title: "Success", description: "Comment updated." });
      setEditingComment(null);
    } catch (error) {
      toast({ title: "Error", description: "Could not update comment.", variant: "destructive" });
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleDeleteComment = async () => {
    if (!commentToDelete) return;
    setIsSubmittingComment(true);
    try {
      const commentRef = doc(db, 'announcementComments', commentToDelete.id);
      await deleteDoc(commentRef);
      toast({ title: "Success", description: "Comment deleted." });
      setCommentToDelete(null);
      setIsDeleteCommentDialogOpen(false);
    } catch (error) {
      toast({ title: "Error", description: "Could not delete comment.", variant: "destructive" });
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const renderComments = (commentsToRender: CommentWithReplies[], level: number = 0) => {
    return commentsToRender.map(comment => (
      <div key={comment.id} className={cn("flex items-start space-x-3", level > 0 && "mt-4 ml-6 pl-4 border-l-2")}>
        <Avatar className="h-8 w-8">
            <AvatarImage src={comment.userAvatarUrl || `https://placehold.co/40x40.png?text=${comment.userAvatarFallback}`} alt={comment.userName} data-ai-hint="employee avatar" />
            <AvatarFallback>{comment.userAvatarFallback}</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
            <div className="bg-muted p-3 rounded-lg">
                <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold">{comment.userName}</p>
                    <p className="text-xs text-muted-foreground">{formatDistanceToNow(comment.timestamp, { addSuffix: true })}</p>
                </div>
                {editingComment?.id === comment.id ? (
                  <form onSubmit={(e) => { e.preventDefault(); handleUpdateComment(comment.id, editingComment.text); }} className="mt-2 space-y-2">
                    <Textarea value={editingComment.text} onChange={(e) => setEditingComment({ ...editingComment, text: e.target.value })} autoFocus className="min-h-[60px]" />
                    <div className="flex justify-end gap-2">
                      <Button type="button" size="sm" variant="ghost" onClick={() => setEditingComment(null)}>Cancel</Button>
                      <Button type="submit" size="sm" disabled={isSubmittingComment}>
                        {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin"/> : "Save"}
                      </Button>
                    </div>
                  </form>
                ) : (
                  <p className="text-sm text-foreground mt-1 whitespace-pre-wrap">{comment.commentText}</p>
                )}
            </div>

            {!editingComment && (
              <div className="flex items-center gap-2">
                <Button variant="link" size="sm" className="p-0 h-auto text-xs" onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}>
                    <Reply className="mr-1 h-3 w-3" /> Reply
                </Button>
                {(user?.uid === comment.userId || isAdmin) && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-6 w-6"><MoreHorizontal className="h-4 w-4" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        {user?.uid === comment.userId &&
                            <DropdownMenuItem onClick={() => setEditingComment({ id: comment.id, text: comment.commentText })}>
                                <Edit className="mr-2 h-4 w-4" /> Edit
                            </DropdownMenuItem>
                        }
                        <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => { setCommentToDelete(comment); setIsDeleteCommentDialogOpen(true); }}>
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            )}
            
            {replyingTo === comment.id && (
              <form onSubmit={(e) => handleCommentSubmit(e, replyContent, comment.id)} className="flex items-start space-x-2 mt-2">
                  <Avatar className="h-8 w-8"><AvatarImage src={employeeProfile?.avatarUrl || undefined} /><AvatarFallback>{employeeProfile?.name?.charAt(0)}</AvatarFallback></Avatar>
                  <Textarea value={replyContent} onChange={(e) => setReplyContent(e.target.value)} placeholder={`Replying to ${comment.userName}...`} className="min-h-[60px]" />
                  <Button type="submit" size="sm" disabled={isSubmittingComment}>
                      {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : "Post"}
                  </Button>
              </form>
            )}

            {comment.replies && renderComments(comment.replies, level + 1)}
        </div>
      </div>
    ));
  };
  
  const currentAnnouncement = allAnnouncements[currentAnnouncementIndex];

  return (
    <>
      <PageHeader
        icon={<HomeIcon className="h-7 w-7 text-primary" />}
        title={`Welcome, ${employeeProfile?.name || 'User'}!`}
        description="Here's your personal dashboard and time clock for today."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
           <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Briefcase className="mr-2 h-5 w-5 text-primary" />
                Today's Time Clock
              </CardTitle>
              <CardDescription>{format(new Date(), 'EEEE, MMMM d, yyyy')}</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center gap-6 text-center">
              <div className="flex items-baseline justify-center gap-2">
                <span className="text-7xl font-bold text-foreground tracking-tighter">{time || '00:00:00'}</span>
                <span className="text-4xl font-semibold text-muted-foreground">{period}</span>
              </div>
              {loadingRecord ? (
                <div className="w-full space-y-2">
                  <Skeleton className="h-10 w-3/4 mx-auto" />
                  <Skeleton className="h-10 w-1/2 mx-auto" />
                </div>
              ) : (
                <div className="grid w-full max-w-md grid-cols-2 gap-4">
                  <Button
                    size="lg"
                    className={cn("h-16 text-lg", !todaysRecord?.morningIn ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-primary/20 text-primary hover:bg-primary/30')}
                    disabled={!!todaysRecord?.morningIn || isProcessing}
                    onClick={() => handleClockEvent('morningIn')}
                  >
                    <LogIn className="mr-2 h-6 w-6" /> Morning In
                  </Button>
                  <Button
                    size="lg"
                    className={cn("h-16 text-lg", !!todaysRecord?.morningIn && !todaysRecord?.lunchOut ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-primary/20 text-primary hover:bg-primary/30')}
                    disabled={!todaysRecord?.morningIn || !!todaysRecord?.lunchOut || isProcessing}
                    onClick={() => handleClockEvent('lunchOut')}
                  >
                    <Coffee className="mr-2 h-6 w-6" /> Lunch Out
                  </Button>
                  <Button
                    size="lg"
                    className={cn("h-16 text-lg", !!todaysRecord?.lunchOut && !todaysRecord?.lunchIn ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-primary/20 text-primary hover:bg-primary/30')}
                    disabled={!todaysRecord?.lunchOut || !!todaysRecord?.lunchIn || isProcessing}
                    onClick={() => handleClockEvent('lunchIn')}
                  >
                    <Coffee className="mr-2 h-6 w-6" /> Lunch In
                  </Button>
                  <Button
                    size="lg"
                    className={cn("h-16 text-lg", !!todaysRecord?.lunchIn && !todaysRecord?.afternoonOut ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-primary/20 text-primary hover:bg-primary/30')}
                    disabled={!todaysRecord?.lunchIn || !!todaysRecord?.afternoonOut || isProcessing}
                    onClick={() => handleClockEvent('afternoonOut')}
                  >
                    <LogOut className="mr-2 h-6 w-6" /> Afternoon Out
                  </Button>
                </div>
              )}
               <div className="mt-4 w-full max-w-2xl rounded-lg border bg-muted/50 p-4">
                <h4 className="font-semibold mb-3 text-foreground">Today's Activity</h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  <div>
                    <p className="text-sm text-muted-foreground">Morning In</p>
                    <p className="text-lg font-bold text-primary">{todaysRecord?.morningIn || '--:--'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Lunch Out</p>
                    <p className="text-lg font-bold text-primary">{todaysRecord?.lunchOut || '--:--'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Lunch In</p>
                    <p className="text-lg font-bold text-primary">{todaysRecord?.lunchIn || '--:--'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Afternoon Out</p>
                    <p className="text-lg font-bold text-primary">{todaysRecord?.afternoonOut || '--:--'}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>My Links</CardTitle>
              <CardDescription>Quick access to your pages.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-1 p-4 pt-0">
                <Link href="/leave" className="flex items-center gap-3 rounded-md p-3 text-sm font-medium text-foreground hover:bg-muted transition-colors">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400">
                    <Plane className="h-4 w-4" />
                  </div>
                  <span>My Leave Requests</span>
                </Link>
                <Link href="/payroll" className="flex items-center gap-3 rounded-md p-3 text-sm font-medium text-foreground hover:bg-muted transition-colors">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/50 dark:text-green-400">
                    <DollarSign className="h-4 w-4" />
                  </div>
                  <span>My Payslips</span>
                </Link>
                <Link href="/calendar" className="flex items-center gap-3 rounded-md p-3 text-sm font-medium text-foreground hover:bg-muted transition-colors">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-purple-100 text-purple-600 dark:bg-purple-900/50 dark:text-purple-400">
                    <CalendarClock className="h-4 w-4" />
                  </div>
                  <span>Company Calendar</span>
                </Link>
            </CardContent>
          </Card>
           <Card className="flex flex-col">
            <CardHeader className="flex flex-row justify-between items-center">
              <CardTitle>Announcements</CardTitle>
              {allAnnouncements.length > 1 && (
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handlePrevAnnouncement}
                    disabled={currentAnnouncementIndex === 0}
                    className="h-8 w-8"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleNextAnnouncement}
                    disabled={currentAnnouncementIndex >= allAnnouncements.length - 1}
                    className="h-8 w-8"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="flex flex-col flex-grow">
               {loadingAnnouncement ? (
                <div className="space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-full" />
                </div>
               ) : currentAnnouncement ? (
                  <div className="flex flex-col h-full">
                    <div className="flex-grow">
                      <div>
                        <h4 className="font-semibold">{currentAnnouncement.title}</h4>
                        <p className="text-sm text-muted-foreground line-clamp-3 mt-1">{currentAnnouncement.content}</p>
                      </div>
                    </div>
                    <div className="mt-4 flex items-end justify-between">
                      <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => handleOpenAnnouncementDialog(currentAnnouncement)}>
                        See more...
                      </Button>
                      <p className="text-xs text-muted-foreground text-right">
                        Posted by {currentAnnouncement.authorName} on {isValid(currentAnnouncement.timestamp) ? format(currentAnnouncement.timestamp, 'PP') : ''}
                      </p>
                    </div>
                  </div>
               ) : (
                <div className="flex items-center gap-3 m-auto">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-orange-100 text-orange-600 dark:bg-orange-900/50 dark:text-orange-400">
                    <AlertCircle className="h-4 w-4" />
                  </div>
                  <p className="text-sm text-muted-foreground">No new announcements.</p>
                </div>
               )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Dialog open={isViewAnnouncementDialogOpen} onOpenChange={setIsViewAnnouncementDialogOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-2xl">{selectedAnnouncementForView?.title}</DialogTitle>
            <DialogDescription>
              Posted by {selectedAnnouncementForView?.authorName} on {selectedAnnouncementForView?.timestamp ? format(selectedAnnouncementForView.timestamp, 'PPp') : ''}
            </DialogDescription>
          </DialogHeader>
          <div className="flex-grow overflow-y-auto pr-6 -mr-6">
            <p className="whitespace-pre-wrap leading-relaxed">{selectedAnnouncementForView?.content}</p>
            <Separator className="my-6" />
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Comments
              </h4>
              {loadingComments ? (
                 <div className="space-y-4">
                    <div className="flex items-start space-x-4"><Skeleton className="h-10 w-10 rounded-full" /><div className="space-y-2"><Skeleton className="h-4 w-[250px]" /><Skeleton className="h-4 w-[200px]" /></div></div>
                    <div className="flex items-start space-x-4"><Skeleton className="h-10 w-10 rounded-full" /><div className="space-y-2"><Skeleton className="h-4 w-[250px]" /><Skeleton className="h-4 w-[200px]" /></div></div>
                 </div>
              ) : comments.length > 0 ? (
                <div className="space-y-4">{renderComments(comments)}</div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No comments yet. Be the first to comment!</p>
              )}
            </div>
          </div>
          <DialogFooter className="border-t pt-4 flex-shrink-0">
            <form onSubmit={(e) => handleCommentSubmit(e, newComment)} className="flex w-full items-center space-x-2">
                <Input
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Write a comment..."
                    disabled={isSubmittingComment}
                />
                <Button type="submit" size="icon" disabled={isSubmittingComment || !newComment.trim()}>
                    {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
            </form>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteCommentDialogOpen} onOpenChange={setIsDeleteCommentDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete your comment. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setCommentToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteComment} disabled={isSubmittingComment} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              {isSubmittingComment ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4"/>} Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}


function AdminDashboard() {
  const { user, employeeProfile } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  const router = useRouter();
  const searchParams = useSearchParams();
  const [currentTime, setCurrentTime] = useState('');
  const [nextPayrollDate, setNextPayrollDate] = useState('');
  const [totalEmployees, setTotalEmployees] = useState(0);
  const [activeEmployees, setActiveEmployees] = useState(0);
  const [allEmployees, setAllEmployees] = useState<Employee[]>([]);
  const [pendingLeaveRequestsCount, setPendingLeaveRequestsCount] = useState(0);
  const [activityFeed, setActivityFeed] = useState<ActivityFeedItemType[]>([]);
  const [loadingStats, setLoadingStats] = useState(true);
  const [loadingActivity, setLoadingActivity] = useState(true);
  const [now, setNow] = useState(() => new Date());
  
  const [allAnnouncements, setAllAnnouncements] = useState<Announcement[]>([]);
  const [currentAnnouncementIndex, setCurrentAnnouncementIndex] = useState(0);
  const [loadingAnnouncement, setLoadingAnnouncement] = useState(true);
  const { toast } = useToast();

  const [attendanceSettings, setAttendanceSettings] = useState<AttendanceSettings | null>(null);
  const [todaysAttendance, setTodaysAttendance] = useState<AttendanceRecord[]>([]);
  const [todaysLeaves, setTodaysLeaves] = useState<LeaveRequest[]>([]);
  const [loadingAttendanceData, setLoadingAttendanceData] = useState(true);
  
  // State for announcement details dialog
  const [isViewAnnouncementDialogOpen, setIsViewAnnouncementDialogOpen] = useState(false);
  const [selectedAnnouncementForView, setSelectedAnnouncementForView] = useState<Announcement | null>(null);
  const [comments, setComments] = useState<CommentWithReplies[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);

  // State for comment actions
  const [editingComment, setEditingComment] = useState<{ id: string; text: string } | null>(null);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [commentToDelete, setCommentToDelete] = useState<AnnouncementComment | null>(null);
  const [isDeleteCommentDialogOpen, setIsDeleteCommentDialogOpen] = useState(false);
  
  const timeToMinutes = (timeStr: string | null | undefined): number | null => {
    if (!timeStr || !/^\d{2}:\d{2}$/.test(timeStr)) return null;
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  };

  useEffect(() => {
    const updateClock = () => {
      setCurrentTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
    };
    updateClock();
    const timerId = setInterval(updateClock, 1000);
    return () => clearInterval(timerId);
  }, []);

  useEffect(() => {
    const intervalId = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const payrollDate = endOfMonth(new Date());
    setNextPayrollDate(format(payrollDate, 'MMMM d, yyyy'));
  }, []);

  useEffect(() => {
    setLoadingStats(true);
    const employeesCollection = collection(db, "employees");
    const unsubscribeEmployees = onSnapshot(employeesCollection, (snapshot) => {
      const employeesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee));
      const filteredEmployees = employeesData.filter(emp => emp.employeeId !== 'ADMIN');
      setAllEmployees(filteredEmployees);
      setTotalEmployees(filteredEmployees.length);
      setActiveEmployees(filteredEmployees.filter(emp => emp.status === 'Active').length);
      setLoadingStats(false);
    }, () => setLoadingStats(false));

    const leaveRequestsCollection = collection(db, "leaveRequests");
    const pendingLeaveQuery = query(leaveRequestsCollection, where("status", "==", "Pending"));
    const unsubscribeLeaveRequests = onSnapshot(pendingLeaveQuery, (snapshot) => {
      setPendingLeaveRequestsCount(snapshot.size);
    });
    
    setLoadingAnnouncement(true);
    const qAnnouncement = query(collection(db, 'announcements'), where("isPublished", "==", true));
    const unsubAnnouncement = onSnapshot(qAnnouncement, (snapshot) => {
      const fetchedAnnouncements = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          timestamp: data.timestamp?.toDate ? data.timestamp.toDate() : new Date(0),
        } as Announcement;
      });

      fetchedAnnouncements.sort((a,b) => b.timestamp.getTime() - a.timestamp.getTime());
      setAllAnnouncements(fetchedAnnouncements);
      setCurrentAnnouncementIndex(0);
      setLoadingAnnouncement(false);
    }, (error) => {
        console.error("Error fetching latest announcement for admin dashboard:", error);
        setLoadingAnnouncement(false);
        toast({ title: 'Error', description: 'Could not fetch announcements.', variant: 'destructive' });
    });

    return () => {
      unsubscribeEmployees();
      unsubscribeLeaveRequests();
      unsubAnnouncement();
    };
  }, [toast]);

  useEffect(() => {
    const announcementId = searchParams.get('announcement');
    if (announcementId) {
      const fetchAndShowAnnouncement = async () => {
        try {
          const docRef = doc(db, 'announcements', announcementId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const announcementData = {
              id: docSnap.id,
              ...docSnap.data(),
              timestamp: docSnap.data().timestamp?.toDate ? docSnap.data().timestamp.toDate() : new Date(0),
            } as Announcement;
            handleOpenAnnouncementDialog(announcementData);
          } else {
            toast({ title: "Not Found", description: "The requested announcement does not exist.", variant: "destructive" });
          }
        } catch (error) {
          toast({ title: "Error", description: "Failed to fetch the announcement.", variant: "destructive" });
        } finally {
          router.replace('/dashboard', { scroll: false });
        }
      };
      fetchAndShowAnnouncement();
    }
  }, [searchParams, router, toast]);

  useEffect(() => {
    setLoadingActivity(true);
    const activityQuery = query(collection(db, "activityFeedItems"), orderBy("timestamp", "desc"), firestoreLimit(10));
    const unsubscribeActivity = onSnapshot(activityQuery, (snapshot) => {
      const feedItems = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id, ...data,
          timestamp: data.timestamp instanceof Timestamp ? data.timestamp.toDate() : new Date(data.timestamp)
        } as ActivityFeedItemType;
      });
      setActivityFeed(feedItems);
      setLoadingActivity(false);
    }, () => setLoadingActivity(false));

    return () => unsubscribeActivity();
  }, []);
  
  useEffect(() => {
    setLoadingAttendanceData(true);
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    
    let settingsLoaded = false, attendanceLoaded = false, leavesLoaded = false;
    const checkAllLoaded = () => {
        if(settingsLoaded && attendanceLoaded && leavesLoaded) {
            setLoadingAttendanceData(false);
        }
    }

    const settingsDocRef = doc(db, 'companySettings', 'attendance');
    const unsubSettings = onSnapshot(settingsDocRef, (docSnap) => {
        if (docSnap.exists()) {
            setAttendanceSettings(docSnap.data() as AttendanceSettings);
        } else {
            setAttendanceSettings({ expectedMorningIn: '08:00', lateGracePeriod: 15, requiredWorkHours: 8 } as AttendanceSettings);
        }
        settingsLoaded = true;
        checkAllLoaded();
    });
    
    const attendanceQuery = query(collection(db, 'attendanceRecords'), where('date', '==', todayStr));
    const unsubAttendance = onSnapshot(attendanceQuery, (snapshot) => {
        setTodaysAttendance(snapshot.docs.map(d => d.data() as AttendanceRecord));
        attendanceLoaded = true;
        checkAllLoaded();
    });

    const leavesQuery = query(collection(db, 'leaveRequests'), where('status', '==', 'Approved'));
    const unsubLeaves = onSnapshot(leavesQuery, (snapshot) => {
        const allApprovedLeaves = snapshot.docs.map(d => ({id: d.id, ...d.data()} as LeaveRequest));
        const today = startOfDay(new Date());
        const leavesForToday = allApprovedLeaves.filter(leave => {
            try {
                const start = parseISO(leave.startDate);
                const end = parseISO(leave.endDate);
                return isWithinInterval(today, { start: startOfDay(start), end: startOfDay(end) });
            } catch { return false; }
        });
        setTodaysLeaves(leavesForToday);
        leavesLoaded = true;
        checkAllLoaded();
    });

    return () => {
        unsubSettings();
        unsubAttendance();
        unsubLeaves();
    };
  }, []);

  const nestComments = (list: AnnouncementComment[]): CommentWithReplies[] => {
    const listWithReplies = list.map(c => ({ ...c, replies: [] as CommentWithReplies[] }));
    const map = new Map(listWithReplies.map(c => [c.id, c]));
    const roots: CommentWithReplies[] = [];
    for (const comment of map.values()) {
        if (comment.parentCommentId && map.has(comment.parentCommentId)) {
            map.get(comment.parentCommentId)!.replies.push(comment);
        } else {
            roots.push(comment);
        }
    }
    return roots;
  };

  useEffect(() => {
    if (!selectedAnnouncementForView) {
      setComments([]);
      return;
    }
    setLoadingComments(true);
    const commentsQuery = query(
      collection(db, 'announcementComments'),
      where('announcementId', '==', selectedAnnouncementForView.id)
    );
    const unsubscribe = onSnapshot(commentsQuery, (snapshot) => {
      const fetchedComments = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timestamp: doc.data().timestamp?.toDate ? doc.data().timestamp.toDate() : new Date(),
      } as AnnouncementComment));
      fetchedComments.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
      const nested = nestComments(fetchedComments);
      setComments(nested);
      setLoadingComments(false);
    }, (error) => {
      console.error("Error fetching comments:", error);
      toast({ title: "Error", description: "Could not load comments. Check permissions.", variant: "destructive" });
      setLoadingComments(false);
    });
    return () => unsubscribe();
  }, [selectedAnnouncementForView, toast]);
  
  const handleOpenAnnouncementDialog = (announcement: Announcement | null) => {
    if (!announcement) return;
    setSelectedAnnouncementForView(announcement);
    setIsViewAnnouncementDialogOpen(true);
  };
  
  const handleNextAnnouncement = () => {
    if (currentAnnouncementIndex < allAnnouncements.length - 1) {
      setCurrentAnnouncementIndex(prev => prev + 1);
    }
  };
  const handlePrevAnnouncement = () => {
    if (currentAnnouncementIndex > 0) {
      setCurrentAnnouncementIndex(prev => prev - 1);
    }
  };

  const handleCommentSubmit = async (e: FormEvent, text: string, parentId?: string) => {
    e.preventDefault();
    if (!text.trim() || !user || !employeeProfile || !selectedAnnouncementForView) return;
    setIsSubmittingComment(true);
    const nameParts = employeeProfile.name.split(' ');
    const initials = (nameParts.length > 1 ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}` : employeeProfile.name.substring(0, 2)).toUpperCase();
    const commentData: Omit<AnnouncementComment, 'id'> = {
        announcementId: selectedAnnouncementForView.id,
        userId: user.uid,
        userName: employeeProfile.name,
        userAvatarUrl: employeeProfile.avatarUrl || '',
        userAvatarFallback: initials,
        commentText: text.trim(),
        timestamp: new Date(),
        ...(parentId && { parentCommentId: parentId }),
    };

    try {
      await addDoc(collection(db, 'announcementComments'), commentData);
      if (parentId) {
        setReplyingTo(null);
        setReplyContent('');
      } else {
        setNewComment('');
      }
    } catch (error) {
      console.error("Error posting comment:", error);
      toast({ title: "Error", description: "Could not post your comment. Check your permissions.", variant: "destructive" });
      setIsSubmittingComment(false);
      return;
    }

    try {
      const q = query(collection(db, "employees"), where("permissionRole", "==", "Administrator"));
      const adminsSnapshot = await getDocs(q);
      if (!adminsSnapshot.empty) {
        const batch = writeBatch(db);
        const notificationText = `${employeeProfile.name} commented on the announcement: "${selectedAnnouncementForView.title}"`;
        adminsSnapshot.forEach(adminDoc => {
          const adminId = adminDoc.id;
          if (adminId !== user.uid) {
            const notificationRef = doc(collection(db, "notifications"));
            batch.set(notificationRef, {
              userId: adminId, type: 'info', text: notificationText,
              timestamp: new Date(), isRead: false, link: `/announcements?announcement=${selectedAnnouncementForView.id}`,
            });
          }
        });
        await batch.commit();
      }
    } catch (notificationError) {
      console.warn("Comment posted, but failed to notify admins:", notificationError);
    }
    setIsSubmittingComment(false);
  };
  
  const handleUpdateComment = async (commentId: string, text: string) => {
    if (!text.trim()) return;
    setIsSubmittingComment(true);
    try {
      const commentRef = doc(db, 'announcementComments', commentId);
      await updateDoc(commentRef, { commentText: text.trim() });
      toast({ title: "Success", description: "Comment updated." });
      setEditingComment(null);
    } catch (error) {
      toast({ title: "Error", description: "Could not update comment.", variant: "destructive" });
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleDeleteComment = async () => {
    if (!commentToDelete) return;
    setIsSubmittingComment(true);
    try {
      const commentRef = doc(db, 'announcementComments', commentToDelete.id);
      await deleteDoc(commentRef);
      toast({ title: "Success", description: "Comment deleted." });
      setCommentToDelete(null);
      setIsDeleteCommentDialogOpen(false);
    } catch (error) {
      toast({ title: "Error", description: "Could not delete comment.", variant: "destructive" });
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const renderComments = (commentsToRender: CommentWithReplies[], level: number = 0) => {
    return commentsToRender.map(comment => (
      <div key={comment.id} className={cn("flex items-start space-x-3", level > 0 && "mt-4 ml-6 pl-4 border-l-2")}>
        <Avatar className="h-8 w-8">
          <AvatarImage src={comment.userAvatarUrl || `https://placehold.co/40x40.png?text=${comment.userAvatarFallback}`} alt={comment.userName} data-ai-hint="employee avatar" />
          <AvatarFallback>{comment.userAvatarFallback}</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
          <div className="bg-muted p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">{comment.userName}</p>
              <p className="text-xs text-muted-foreground">{formatDistanceToNow(comment.timestamp, { addSuffix: true })}</p>
            </div>
            {editingComment?.id === comment.id ? (
              <form onSubmit={(e) => { e.preventDefault(); handleUpdateComment(comment.id, editingComment.text); }} className="mt-2 space-y-2">
                <Textarea value={editingComment.text} onChange={(e) => setEditingComment({ ...editingComment, text: e.target.value })} autoFocus className="min-h-[60px]" />
                <div className="flex justify-end gap-2">
                  <Button type="button" size="sm" variant="ghost" onClick={() => setEditingComment(null)}>Cancel</Button>
                  <Button type="submit" size="sm" disabled={isSubmittingComment}>
                    {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin"/> : "Save"}
                  </Button>
                </div>
              </form>
            ) : (
              <p className="text-sm text-foreground mt-1 whitespace-pre-wrap">{comment.commentText}</p>
            )}
          </div>
          {!editingComment && (
            <div className="flex items-center gap-2">
              <Button variant="link" size="sm" className="p-0 h-auto text-xs" onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}>
                <Reply className="mr-1 h-3 w-3" /> Reply
              </Button>
              {(user?.uid === comment.userId || isAdmin) && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-6 w-6"><MoreHorizontal className="h-4 w-4" /></Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {user?.uid === comment.userId &&
                      <DropdownMenuItem onClick={() => setEditingComment({ id: comment.id, text: comment.commentText })}>
                        <Edit className="mr-2 h-4 w-4" /> Edit
                      </DropdownMenuItem>
                    }
                    <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => { setCommentToDelete(comment); setIsDeleteCommentDialogOpen(true); }}>
                      <Trash2 className="mr-2 h-4 w-4" /> Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          )}
          {replyingTo === comment.id && (
            <form onSubmit={(e) => handleCommentSubmit(e, replyContent, comment.id)} className="flex items-start space-x-2 mt-2">
              <Avatar className="h-8 w-8"><AvatarImage src={employeeProfile?.avatarUrl || undefined} /><AvatarFallback>{employeeProfile?.name?.charAt(0)}</AvatarFallback></Avatar>
              <Textarea value={replyContent} onChange={(e) => setReplyContent(e.target.value)} placeholder={`Replying to ${comment.userName}...`} className="min-h-[60px]" />
              <Button type="submit" size="sm" disabled={isSubmittingComment}>
                {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : "Post"}
              </Button>
            </form>
          )}
          {comment.replies && renderComments(comment.replies, level + 1)}
        </div>
      </div>
    ));
  };


  const dailyAttendanceStatus = useMemo(() => {
    const result = {
        late: [] as { employee: Employee; record: AttendanceRecord }[],
        absent: [] as Employee[],
        onLeave: [] as { employee: Employee; leaveRequest: LeaveRequest }[],
    };

    if (loadingStats || loadingAttendanceData || !attendanceSettings) {
        return result;
    }

    const onLeaveEmployeeIds = new Set(todaysLeaves.map(l => l.employeeId));
    const activeEmployeesList = allEmployees.filter(e => e.status === 'Active' && e.employeeId !== 'ADMIN');

    activeEmployeesList.forEach(emp => {
        if (onLeaveEmployeeIds.has(emp.id)) {
            const leaveRequest = todaysLeaves.find(l => l.employeeId === emp.id);
            if (leaveRequest) {
                 result.onLeave.push({ employee: emp, leaveRequest });
            }
            return;
        }

        const attendanceRecord = todaysAttendance.find(r => r.employeeId === emp.id);

        if (!attendanceRecord?.morningIn) {
            result.absent.push(emp);
        } else {
            const clockInTime = timeToMinutes(attendanceRecord.morningIn);
            const expectedInTime = timeToMinutes(attendanceSettings.expectedMorningIn);
            if (expectedInTime !== null && clockInTime !== null) {
                if (clockInTime > (expectedInTime + attendanceSettings.lateGracePeriod)) {
                    result.late.push({ employee: emp, record: attendanceRecord });
                }
            }
        }
    });

    return result;
}, [allEmployees, todaysAttendance, todaysLeaves, attendanceSettings, loadingStats, loadingAttendanceData]);

  const activeEmployeesPercentage = totalEmployees > 0 ? Math.round((activeEmployees / totalEmployees) * 100) : 0;

  const formatActivityTimestamp = (timestamp: Date | Timestamp | string, now: Date): string => {
    let dateObj: Date = timestamp instanceof Timestamp ? timestamp.toDate() : new Date(timestamp);
    if (!isValid(dateObj)) return "Invalid date";
    const diffSeconds = Math.round((now.getTime() - dateObj.getTime()) / 1000);
    if (diffSeconds < 60) return `${diffSeconds}s ago`;
    const diffMinutes = Math.round(diffSeconds / 60);
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    const diffHours = Math.round(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return format(dateObj, "MMM d, HH:mm");
  };
  
  const currentAnnouncement = allAnnouncements[currentAnnouncementIndex];

  return (
    <>
      <PageHeader
        icon={<LayoutDashboard className="h-7 w-7 text-primary" />}
        title="Welcome, Admin!"
        description={`Here's an overview of the company's activities and metrics. Current time: ${currentTime}`}
        className="mb-8"
      />

      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <div className="p-2 bg-blue-100 rounded-full"><Users className="h-5 w-5 text-blue-500" /></div>
          </CardHeader>
          <CardContent>
            {loadingStats ? <Loader2 className="h-7 w-7 animate-spin" /> : <div className="text-3xl font-bold">{totalEmployees}</div>}
            <p className="text-xs text-muted-foreground h-4">{!loadingStats ? (totalEmployees > 0 ? `Currently in system` : `No employees found`) : ""}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
            <div className="p-2 bg-green-100 rounded-full"><UserCheck className="h-5 w-5 text-green-500" /></div>
          </CardHeader>
          <CardContent>
            {loadingStats ? <Loader2 className="h-7 w-7 animate-spin" /> : <div className="text-3xl font-bold">{activeEmployees}</div>}
            <p className="text-xs text-muted-foreground h-4">{!loadingStats ? (totalEmployees > 0 ? `${activeEmployeesPercentage}% of total` : ``) : ""}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Leaves</CardTitle>
            <div className="p-2 bg-yellow-100 rounded-full"><CalendarClock className="h-5 w-5 text-yellow-600" /></div>
          </CardHeader>
          <CardContent>
            {loadingStats ? <Loader2 className="h-7 w-7 animate-spin" /> : <div className="text-3xl font-bold">{pendingLeaveRequestsCount}</div>}
            <Link href="/leave" className="text-xs text-primary hover:underline h-4 block">
              {!loadingStats ? (pendingLeaveRequestsCount > 0 ? `${pendingLeaveRequestsCount} new requests to review` : 'No pending requests') : ""}
            </Link>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Payroll</CardTitle>
            <div className="p-2 bg-indigo-100 rounded-full"><DollarSign className="h-5 w-5 text-indigo-500" /></div>
          </CardHeader>
          <CardContent>
            {nextPayrollDate ? <div className="text-xl font-bold">{nextPayrollDate}</div> : <Loader2 className="h-6 w-6 animate-spin" />}
            <p className="text-xs text-muted-foreground">Mark your calendar</p>
          </CardContent>
        </Card>
      </div>

       <Card className="mb-6">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
                <Megaphone className="h-5 w-5 text-primary" />
                <CardTitle>Company Announcements</CardTitle>
            </div>
            <div className="flex items-center gap-2">
                {allAnnouncements.length > 1 && (
                    <>
                        <Button variant="outline" size="icon" onClick={handlePrevAnnouncement} disabled={currentAnnouncementIndex === 0} className="h-8 w-8"><ChevronLeft className="h-4 w-4" /></Button>
                        <Button variant="outline" size="icon" onClick={handleNextAnnouncement} disabled={currentAnnouncementIndex >= allAnnouncements.length - 1} className="h-8 w-8"><ChevronRight className="h-4 w-4" /></Button>
                    </>
                )}
                <Button variant="outline" onClick={() => router.push('/announcements')}>
                    Manage Announcements <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
            </div>
          </div>
          <CardDescription>Latest published announcement for all employees.</CardDescription>
        </CardHeader>
        <CardContent>
          {loadingAnnouncement ? (
            <div className="space-y-2"><Skeleton className="h-5 w-3/4" /><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-1/2" /></div>
          ) : currentAnnouncement ? (
            <div className="p-4 bg-muted/50 rounded-lg flex flex-col">
                <div className="flex-grow text-center">
                  <h4 className="font-semibold text-lg">{currentAnnouncement.title}</h4>
                  <p className="text-foreground whitespace-pre-wrap mt-2">{currentAnnouncement.content}</p>
                </div>
                <div className="mt-4 flex items-end justify-between">
                  <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => handleOpenAnnouncementDialog(currentAnnouncement)}>
                    View & Comment...
                  </Button>
                  <p className="text-sm text-muted-foreground text-right">
                    Posted by {currentAnnouncement.authorName} on {isValid(currentAnnouncement.timestamp) ? format(currentAnnouncement.timestamp, 'PP') : ''}
                  </p>
                </div>
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-4">No published announcements.</p>
          )}
        </CardContent>
       </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center"><ListChecks className="mr-2 h-5 w-5" />Today's Attendance Status</CardTitle>
            <CardDescription>Overview of employee attendance for {format(now, 'MMMM d, yyyy')}.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="late">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="late">
                        <AlarmClock className="mr-2 h-4 w-4" />
                        Late
                        {dailyAttendanceStatus.late.length > 0 && <Badge variant="destructive" className="ml-2">{dailyAttendanceStatus.late.length}</Badge>}
                    </TabsTrigger>
                    <TabsTrigger value="absent">
                        <UserX className="mr-2 h-4 w-4" />
                        Absent
                        {dailyAttendanceStatus.absent.length > 0 && <Badge variant="secondary" className="ml-2">{dailyAttendanceStatus.absent.length}</Badge>}
                    </TabsTrigger>
                    <TabsTrigger value="on-leave">
                        <CalendarOff className="mr-2 h-4 w-4" />
                        On Leave
                        {dailyAttendanceStatus.onLeave.length > 0 && <Badge variant="secondary" className="ml-2">{dailyAttendanceStatus.onLeave.length}</Badge>}
                    </TabsTrigger>
                </TabsList>
                <ScrollArea className="h-80 mt-4">
                    <TabsContent value="late">
                        {loadingAttendanceData ? (
                          <div className="space-y-3">
                              {[...Array(3)].map((_, i) => (
                                  <div key={i} className="flex items-center gap-3 p-2 rounded-md border">
                                      <Skeleton className="h-10 w-10 rounded-full" />
                                      <div className="flex-1 space-y-1">
                                          <Skeleton className="h-4 w-3/4" />
                                          <Skeleton className="h-3 w-1/2" />
                                      </div>
                                  </div>
                              ))}
                          </div>
                        ) :
                         dailyAttendanceStatus.late.length === 0 ? <div className="text-center text-muted-foreground py-10"><AlarmClock className="mx-auto h-8 w-8 mb-2" /><p>No late employees today.</p></div> :
                          <ul className="space-y-3">
                            {dailyAttendanceStatus.late.map(({employee, record}) => {
                                const nameParts = employee.name.split(' ');
                                const initials = (
                                  nameParts.length > 1
                                    ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}`
                                    : employee.name.substring(0, 2)
                                ).toUpperCase();
                                return (
                                 <li key={employee.id} className="flex items-center gap-3 p-2 rounded-md border">
                                     <Avatar><AvatarImage src={employee.avatarUrl || `https://placehold.co/40x40.png?text=${initials}`} alt={employee.name} data-ai-hint="employee avatar" /><AvatarFallback>{initials}</AvatarFallback></Avatar>
                                     <div><p className="font-medium">{employee.name}</p><p className="text-xs text-muted-foreground">{employee.role} &bull; {employee.department}</p></div>
                                     <Badge variant="destructive" className="ml-auto">In at {record.morningIn}</Badge>
                                 </li>
                            )})}
                          </ul>
                        }
                    </TabsContent>
                    <TabsContent value="absent">
                        {loadingAttendanceData ? (
                           <div className="space-y-3">
                              {[...Array(3)].map((_, i) => (
                                  <div key={i} className="flex items-center gap-3 p-2 rounded-md border">
                                      <Skeleton className="h-10 w-10 rounded-full" />
                                      <div className="flex-1 space-y-1">
                                          <Skeleton className="h-4 w-3/4" />
                                          <Skeleton className="h-3 w-1/2" />
                                      </div>
                                  </div>
                              ))}
                          </div>
                        ) :
                         dailyAttendanceStatus.absent.length === 0 ? <div className="text-center text-muted-foreground py-10"><UserCheck className="mx-auto h-8 w-8 mb-2" /><p>All active employees are accounted for.</p></div> :
                           <ul className="space-y-3">
                            {dailyAttendanceStatus.absent.map(employee => {
                                const nameParts = employee.name.split(' ');
                                const initials = (
                                  nameParts.length > 1
                                    ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}`
                                    : employee.name.substring(0, 2)
                                ).toUpperCase();
                                return (
                                 <li key={employee.id} className="flex items-center gap-3 p-2 rounded-md border">
                                     <Avatar><AvatarImage src={employee.avatarUrl || `https://placehold.co/40x40.png?text=${initials}`} alt={employee.name} data-ai-hint="employee avatar" /><AvatarFallback>{initials}</AvatarFallback></Avatar>
                                     <div><p className="font-medium">{employee.name}</p><p className="text-xs text-muted-foreground">{employee.role} &bull; {employee.department}</p></div>
                                 </li>
                            )})}
                          </ul>
                        }
                    </TabsContent>
                    <TabsContent value="on-leave">
                        {loadingAttendanceData ? (
                           <div className="space-y-3">
                              {[...Array(3)].map((_, i) => (
                                  <div key={i} className="flex items-center gap-3 p-2 rounded-md border">
                                      <Skeleton className="h-10 w-10 rounded-full" />
                                      <div className="flex-1 space-y-1">
                                          <Skeleton className="h-4 w-3/4" />
                                          <Skeleton className="h-3 w-1/2" />
                                      </div>
                                  </div>
                              ))}
                          </div>
                        ) :
                         dailyAttendanceStatus.onLeave.length === 0 ? <div className="text-center text-muted-foreground py-10"><CalendarOff className="mx-auto h-8 w-8 mb-2" /><p>No employees on leave today.</p></div> :
                          <ul className="space-y-3">
                            {dailyAttendanceStatus.onLeave.map(({employee, leaveRequest}) => {
                                const nameParts = employee.name.split(' ');
                                const initials = (
                                  nameParts.length > 1
                                    ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}`
                                    : employee.name.substring(0, 2)
                                ).toUpperCase();
                                return (
                                 <li key={employee.id} className="flex items-center gap-3 p-2 rounded-md border">
                                     <Avatar><AvatarImage src={employee.avatarUrl || `https://placehold.co/40x40.png?text=${initials}`} alt={employee.name} data-ai-hint="employee avatar" /><AvatarFallback>{initials}</AvatarFallback></Avatar>
                                     <div className="flex-grow"><p className="font-medium">{employee.name}</p><p className="text-xs text-muted-foreground">{employee.role} &bull; {employee.department}</p></div>
                                     <Badge variant="secondary" className="ml-auto">{leaveRequest.leaveType} Leave</Badge>
                                 </li>
                            )})}
                          </ul>
                        }
                    </TabsContent>
                </ScrollArea>
            </Tabs>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-1 relative">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-foreground flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Audit Log
            </CardTitle>
            <CardDescription>Latest high-level actions taken in the system.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[300px] pr-2">
              <div className="space-y-4 p-6 pt-0">
                {loadingActivity ? (
                  <div className="flex items-center justify-center h-full"><Loader2 className="h-6 w-6 animate-spin text-primary" /><p className="ml-2 text-sm text-muted-foreground">Loading activity...</p></div>
                ) : activityFeed.length > 0 ? (
                  activityFeed.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3 pt-4 first:pt-0">
                      <Avatar className="h-9 w-9 mt-1">
                        <AvatarImage src={activity.avatarUrl || `https://placehold.co/40x40.png?text=${activity.avatarFallback || activity.userName.substring(0,2)}`} alt={activity.userName} data-ai-hint="person user"/>
                        <AvatarFallback>{activity.avatarFallback || activity.userName.substring(0,2)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-sm">
                          <span className="font-medium">{activity.userName}</span>
                          {activity.userRole && <span className="text-muted-foreground"> ({activity.userRole})</span>}
                          {' '}{activity.text}
                          {activity.ipAddress && <span className="text-muted-foreground"> from {activity.ipAddress}</span>}
                        </p>
                        <p className="text-xs text-muted-foreground">{formatActivityTimestamp(activity.timestamp, now)}</p>
                        {activity.details && activity.details.length > 0 && (
                          <div className="mt-1.5 space-y-1">
                            {activity.details.map((detail, idx) => (
                              <div key={idx} className="flex items-center text-xs">
                                 <Badge variant="secondary" className="mr-1.5 text-nowrap">{detail.label}:</Badge> 
                                 <span className="text-sm text-foreground">{detail.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center p-4"><MessageSquareText className="w-12 h-12 text-muted-foreground mb-3" /><p className="text-sm font-medium text-foreground">No Recent Activity</p><p className="text-xs text-muted-foreground">Updates will appear here as actions are taken in the system.</p></div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      <Dialog open={isViewAnnouncementDialogOpen} onOpenChange={setIsViewAnnouncementDialogOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="text-2xl">{selectedAnnouncementForView?.title}</DialogTitle>
            <DialogDescription>
              Posted by {selectedAnnouncementForView?.authorName} on {selectedAnnouncementForView?.timestamp ? format(selectedAnnouncementForView.timestamp, 'PPp') : ''}
            </DialogDescription>
          </DialogHeader>
          <div className="flex-grow overflow-y-auto pr-6 -mr-6">
            <p className="whitespace-pre-wrap leading-relaxed">{selectedAnnouncementForView?.content}</p>
            <Separator className="my-6" />
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Comments
              </h4>
              {loadingComments ? (
                 <div className="space-y-4">
                    <div className="flex items-start space-x-4"><Skeleton className="h-10 w-10 rounded-full" /><div className="space-y-2"><Skeleton className="h-4 w-[250px]" /><Skeleton className="h-4 w-[200px]" /></div></div>
                    <div className="flex items-start space-x-4"><Skeleton className="h-10 w-10 rounded-full" /><div className="space-y-2"><Skeleton className="h-4 w-[250px]" /><Skeleton className="h-4 w-[200px]" /></div></div>
                 </div>
              ) : comments.length > 0 ? (
                <div className="space-y-4">{renderComments(comments)}</div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No comments yet. Be the first to comment!</p>
              )}
            </div>
          </div>
          <DialogFooter className="border-t pt-4 flex-shrink-0">
            <form onSubmit={(e) => handleCommentSubmit(e, newComment)} className="flex w-full items-center space-x-2">
                <Input
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Write a comment..."
                    disabled={isSubmittingComment}
                />
                <Button type="submit" size="icon" disabled={isSubmittingComment || !newComment.trim()}>
                    {isSubmittingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
            </form>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteCommentDialogOpen} onOpenChange={setIsDeleteCommentDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the comment. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setCommentToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteComment} disabled={isSubmittingComment} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              {isSubmittingComment ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4"/>} Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

export default function DashboardPage() {
  const { employeeProfile, loading: authLoading } = useAuth();

  if (authLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-1/3" />
        <Skeleton className="h-6 w-1/2" />
        <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 mt-6">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <div className="grid gap-6 md:grid-cols-3 mt-6">
          <Skeleton className="md:col-span-2 h-96" />
          <Skeleton className="md:col-span-1 h-96" />
        </div>
      </div>
    );
  }

  if (employeeProfile?.permissionRole === 'User') {
    return <UserDashboard />;
  }
  
  // Default to Admin Dashboard
  return <AdminDashboard />;
}
