
'use client';

import { redirect } from 'next/navigation';
import { useEffect } from 'react';
import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent } from '@/components/ui/card';
import { Info, KeyRound } from 'lucide-react';

// This page is deprecated and no longer used.
export default function DeprecatedRolesPage() {
  
  return (
    <>
      <PageHeader
        icon={<KeyRound className="h-7 w-7 text-primary" />}
        title="Role Management (Deprecated)"
        description="This page is no longer in use."
      />
      <Card>
        <CardContent className="p-6 text-center">
            <Info className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold">Page No Longer In Use</h3>
            <p className="text-muted-foreground mt-2">
              Role management has been simplified to "Administrator" and "User" roles.
              You can assign these roles when adding or editing an employee in the Employee Directory.
            </p>
        </CardContent>
      </Card>
    </>
  );
}
