'use client';

import { redirect } from 'next/navigation';
import { useEffect } from 'react';

// This page is deprecated in favor of Firebase's default action handlers.
export default function DeprecatedAuthActionPage() {
  useEffect(() => {
    redirect('/login');
  }, []);

  return null; // Render nothing while redirecting
}
