

"use client";

import { PageHeader } from '@/components/shared/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Save, UserCog, Palette, Bell, ArrowRight, Sun, Moon, Loader2, AlertTriangle, Paintbrush, KeyRound, XCircle, Trash2, Settings as SettingsIcon, Eye, EyeOff, Mail, Edit3 } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';
import { useRouter } from 'next/navigation';
import { useEffect, useState, type FormEvent } from 'react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { doc, updateDoc } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { signOut, sendPasswordResetEmail, updatePassword, reauthenticateWithCredential, EmailAuthProvider, updateEmail } from 'firebase/auth';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';

type CustomizationSettings = {
  font: string;
  theme: string;
  fontSize: 'sm' | 'default' | 'lg';
};

export default function SettingsPage() {
  const { user, employeeProfile } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [inAppNotifications, setInAppNotifications] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [customization, setCustomization] = useState<CustomizationSettings>({
    font: 'sans',
    theme: 'default',
    fontSize: 'default',
  });

  const [isDeleteRequestDialogOpen, setIsDeleteRequestDialogOpen] = useState(false);
  const [isRequestingDelete, setIsRequestingDelete] = useState(false);
  
  // State for Change Password Dialog
  const [isChangePasswordDialogOpen, setIsChangePasswordDialogOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);

  // New state for editing user/admin email
  const [isEditEmailDialogOpen, setIsEditEmailDialogOpen] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [currentPasswordForEmail, setCurrentPasswordForEmail] = useState('');
  const [isUpdatingEmail, setIsUpdatingEmail] = useState(false);


  useEffect(() => {
    const savedFont = localStorage.getItem('app-font') || 'sans';
    const savedTheme = localStorage.getItem('app-theme') || 'default';
    const savedFontSize = (localStorage.getItem('app-font-size') as CustomizationSettings['fontSize']) || 'default';
    const savedIsDark = localStorage.getItem('dark-mode') === 'true';

    setCustomization({ font: savedFont, theme: savedTheme, fontSize: savedFontSize });
    setIsDarkMode(savedIsDark);
    
    const observer = new MutationObserver(() => {
      setIsDarkMode(document.documentElement.classList.contains('dark'));
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

    return () => observer.disconnect();
  }, []);
  
  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;

    body.classList.remove('font-sans', 'font-roboto', 'font-lato');
    body.classList.add(`font-${customization.font}`);
    localStorage.setItem('app-font', customization.font);

    root.setAttribute('data-theme', customization.theme);
    localStorage.setItem('app-theme', customization.theme);

    root.setAttribute('data-font-size', customization.fontSize);
    localStorage.setItem('app-font-size', customization.fontSize);
  }, [customization]);

  const handleProfileNavigation = () => {
    if (user) {
      router.push(`/employees/${user.uid}`);
    }
  };

  const toggleTheme = (checked: boolean) => {
    if (checked) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('dark-mode', String(checked));
    setIsDarkMode(checked);
  };

  const handleSavePreferences = async () => {
    if (!user) {
      toast({ title: "Error", description: "You must be logged in to save settings.", variant: "destructive" });
      return;
    }
    setIsSaving(true);
    try {
      const employeeDocRef = doc(db, 'employees', user.uid);
      await updateDoc(employeeDocRef, {
        notificationPreferences: {
          email: emailNotifications,
          inApp: inAppNotifications,
        }
      });
      toast({ title: "Success", description: "Your notification preferences have been saved.", variant: 'success' });
    } catch (error) {
      console.error("Error saving preferences:", error);
      toast({ title: "Error", description: "Failed to save preferences.", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const handleRequestDeletion = async () => {
    if (!user) {
      toast({ title: "Error", description: "You must be logged in.", variant: "destructive" });
      return;
    }
    setIsRequestingDelete(true);
    try {
      const employeeDocRef = doc(db, 'employees', user.uid);
      await updateDoc(employeeDocRef, {
        status: 'Inactive',
        deletionRequested: true,
        deletionRequestTimestamp: new Date(),
      });

      toast({
        title: "Deletion Request Submitted",
        description: "Your request has been sent to an administrator for review. You will now be logged out.",
        variant: 'success',
        duration: 5000,
      });

      await signOut(auth);
      router.push('/login');

    } catch (error) {
      console.error("Error requesting account deletion:", error);
      toast({ title: "Error", description: "Failed to submit your deletion request.", variant: "destructive" });
    }
  };
  
  const calculatePasswordStrength = (password: string) => {
    let score = 0;
    if (!password) {
        setPasswordStrength(0);
        return;
    }
    if (password.length >= 8) score += 25;
    if (/[a-z]/.test(password)) score += 25;
    if (/[A-Z]/.test(password)) score += 25;
    if (/\d/.test(password)) score += 25;
    setPasswordStrength(Math.min(100, score));
  };

  useEffect(() => {
    calculatePasswordStrength(newPassword);
  }, [newPassword]);
  
  const handleChangePassword = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !user.email) {
      toast({ title: "Error", description: "You must be logged in to change your password.", variant: "destructive" });
      return;
    }
    if (newPassword !== confirmNewPassword) {
      toast({ title: "Error", description: "New passwords do not match.", variant: "destructive" });
      return;
    }
    if (newPassword.length < 6) {
      toast({ title: "Error", description: "New password must be at least 6 characters long.", variant: "destructive" });
      return;
    }
    if (!currentPassword) {
        toast({ title: "Error", description: "Please enter your current password.", variant: "destructive" });
        return;
    }
    
    setIsChangingPassword(true);
    try {
      const credential = EmailAuthProvider.credential(user.email, currentPassword);
      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, newPassword);

      toast({
        title: "Password Updated Successfully",
        description: "Your password has been changed. You will be logged out for security.",
        variant: "success",
        duration: 5000,
      });

      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      
      await signOut(auth);
      router.push('/login');

    } catch (error: any) {
      let description = "An unexpected error occurred.";
      if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        description = "Incorrect current password. Please try again.";
      }
      toast({ title: "Password Change Failed", description, variant: "destructive" });
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleUpdateEmail = async () => {
    if (!auth.currentUser || !newEmail || !currentPasswordForEmail) {
      toast({ title: "Error", description: "Please fill all fields.", variant: "destructive" });
      return;
    }

    if (newEmail.toLowerCase() === auth.currentUser.email?.toLowerCase()) {
      toast({ title: "Error", description: "You entered the same email address. Please provide a new email.", variant: "destructive" });
      return;
    }
    
    setIsUpdatingEmail(true);
    const user = auth.currentUser;

    try {
      const credential = EmailAuthProvider.credential(user.email!, currentPasswordForEmail);
      await reauthenticateWithCredential(user, credential);
      
      await updateEmail(user, newEmail);
      
      const employeeDocRef = doc(db, 'employees', user.uid);
      await updateDoc(employeeDocRef, { email: newEmail });

      toast({
        title: "Email Updated Successfully",
        description: `Your email has been changed to ${newEmail}. You will be logged out to complete the change. Please log in with your new email.`,
        variant: 'success',
        duration: 8000
      });

      setIsEditEmailDialogOpen(false);
      await signOut(auth);
      router.push('/login');

    } catch (error: any) {
      let description = "An unexpected error occurred. Please try again.";
      if (error.code === 'auth/invalid-credential' || error.code === 'auth/wrong-password') {
          description = "The password you entered is incorrect. Please try again.";
      } else if (error.code === 'auth/email-already-in-use') {
          description = "This email address is already in use by another account.";
      } else if (error.code === 'auth/requires-recent-login') {
          description = "This is a sensitive operation. Please log out and log back in before changing your email.";
      } else if (error.code === 'auth/invalid-email') {
          description = "The new email address is not valid.";
      }
      else {
          console.error("Email update error:", error);
      }
      toast({ title: "Update Failed", description, variant: "destructive" });
    } finally {
      setIsUpdatingEmail(false);
    }
  };


  const handleCustomizationChange = <K extends keyof CustomizationSettings>(key: K, value: CustomizationSettings[K]) => {
    setCustomization(prev => ({ ...prev, [key]: value }));
  };

  return (
    <>
      <PageHeader
        icon={<SettingsIcon className="h-7 w-7 text-primary" />}
        title="Settings"
        description="Manage your account, appearance, and notification preferences."
      />
      <div className={cn(
        "grid gap-8 md:grid-cols-2",
        employeeProfile?.permissionRole === 'User' ? 'lg:grid-cols-4' : 'lg:grid-cols-3'
      )}>

        <Card>
          <CardHeader className="flex flex-row items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <UserCog className="h-6 w-6 text-primary" />
            </div>
            <div>
              <CardTitle>Account</CardTitle>
              <CardDescription>Manage your profile.</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
             <Button variant="default" onClick={handleProfileNavigation} disabled={!user} className="w-full">
                <UserCog className="mr-2 h-4 w-4" /> Manage Full Profile
             </Button>
             <Button variant="default" onClick={() => setIsChangePasswordDialogOpen(true)} disabled={!user} className="w-full">
                <KeyRound className="mr-2 h-4 w-4" /> Change Password
             </Button>
             <Button variant="default" onClick={() => {
                  setNewEmail(employeeProfile?.email || '');
                  setCurrentPasswordForEmail('');
                  setIsEditEmailDialogOpen(true);
                }} disabled={!user} className="w-full">
                <Mail className="mr-2 h-4 w-4" /> Change Email
             </Button>
          </CardContent>
        </Card>

        <Card>
           <CardHeader className="flex flex-row items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Palette className="h-6 w-6 text-primary" />
            </div>
            <div>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>Customize the look and feel.</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="flex items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <Label htmlFor="darkMode" className="text-base">Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Enable the dark theme.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                    <Sun className={cn("h-5 w-5", !isDarkMode && "text-primary")} />
                    <Switch id="darkMode" checked={isDarkMode} onCheckedChange={toggleTheme} />
                    <Moon className={cn("h-5 w-5", isDarkMode && "text-primary")} />
                </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Bell className="h-6 w-6 text-primary" />
            </div>
            <div>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Manage how you receive alerts.</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="emailNotifications" className="font-medium">Email Notifications</Label>
                <p className="text-sm text-muted-foreground">Receive important alerts via email.</p>
              </div>
              <Switch id="emailNotifications" checked={emailNotifications} onCheckedChange={setEmailNotifications} />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="pushNotifications" className="font-medium">In-App Notifications</Label>
                <p className="text-sm text-muted-foreground">Show alerts inside the application.</p>
              </div>
              <Switch id="pushNotifications" checked={inAppNotifications} onCheckedChange={setInAppNotifications} disabled/>
            </div>
             <Button className="w-full mt-4" onClick={handleSavePreferences} disabled={isSaving}>
              {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
               Save Preferences
             </Button>
          </CardContent>
        </Card>
        
        {employeeProfile?.permissionRole === 'User' && (
            <Card className="border-destructive">
              <CardHeader className="flex flex-row items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10">
                      <AlertTriangle className="h-6 w-6 text-destructive" />
                  </div>
                  <div>
                    <CardTitle className="text-destructive">Danger Zone</CardTitle>
                    <CardDescription>Irreversible account actions.</CardDescription>
                  </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold">Request Account Deletion</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Once you request deletion, your account will be deactivated and submitted for permanent removal.
                    </p>
                  </div>
                  <Button
                    variant="destructive"
                    className="w-full"
                    onClick={() => setIsDeleteRequestDialogOpen(true)}
                    disabled={isRequestingDelete}
                  >
                    <Trash2 className="mr-2 h-4 w-4"/>Request Account Deletion
                  </Button>
                </div>
              </CardContent>
            </Card>
        )}
      </div>

      <Separator className="my-8" />
      
        <Card>
          <CardHeader className="flex flex-row items-start gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 flex-shrink-0">
                <Paintbrush className="h-6 w-6 text-primary" />
            </div>
            <div>
              <CardTitle>Customization</CardTitle>
              <CardDescription>Adjust the look and feel of the application.</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="space-y-2">
                <Label>Font Family</Label>
                <Select value={customization.font} onValueChange={(value) => handleCustomizationChange('font', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a font" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sans">Open Sans (Default)</SelectItem>
                    <SelectItem value="roboto">Roboto</SelectItem>
                    <SelectItem value="lato">Lato</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Color Theme</Label>
                <RadioGroup value={customization.theme} onValueChange={(value) => handleCustomizationChange('theme', value)} className="flex items-center gap-4">
                  <Label htmlFor="theme-default" className="cursor-pointer space-y-1">
                    <RadioGroupItem value="default" id="theme-default" className="sr-only" />
                    <div className={cn("rounded-md border-2 p-1", customization.theme === 'default' ? 'border-primary' : 'border-muted hover:border-muted-foreground/50')}>
                      <div className="flex items-center gap-2 rounded-sm p-2 bg-muted/50">
                        <div className="h-4 w-4 rounded-full" style={{ backgroundColor: 'hsl(224 100% 45%)' }} />
                        <div className="h-2 w-10 rounded-lg" style={{ backgroundColor: 'hsl(224 100% 45%)' }} />
                      </div>
                    </div>
                    <span className="block w-full text-center text-xs">Default</span>
                  </Label>
                  <Label htmlFor="theme-green" className="cursor-pointer space-y-1">
                    <RadioGroupItem value="green" id="theme-green" className="sr-only" />
                    <div className={cn("rounded-md border-2 p-1", customization.theme === 'green' ? 'border-primary' : 'border-muted hover:border-muted-foreground/50')}>
                      <div className="flex items-center gap-2 rounded-sm p-2 bg-muted/50">
                        <div className="h-4 w-4 rounded-full" style={{ backgroundColor: 'hsl(145 58% 51%)' }} />
                        <div className="h-2 w-10 rounded-lg" style={{ backgroundColor: 'hsl(145 58% 51%)' }}/>
                      </div>
                    </div>
                    <span className="block w-full text-center text-xs">Green</span>
                  </Label>
                  <Label htmlFor="theme-purple" className="cursor-pointer space-y-1">
                    <RadioGroupItem value="purple" id="theme-purple" className="sr-only" />
                    <div className={cn("rounded-md border-2 p-1", customization.theme === 'purple' ? 'border-primary' : 'border-muted hover:border-muted-foreground/50')}>
                      <div className="flex items-center gap-2 rounded-sm p-2 bg-muted/50">
                        <div className="h-4 w-4 rounded-full" style={{ backgroundColor: 'hsl(260 65% 65%)' }} />
                        <div className="h-2 w-10 rounded-lg" style={{ backgroundColor: 'hsl(260 65% 65%)' }}/>
                      </div>
                    </div>
                    <span className="block w-full text-center text-xs">Purple</span>
                  </Label>
                </RadioGroup>
              </div>
              
              <div className="space-y-2">
                <Label>Font Size</Label>
                <RadioGroup value={customization.fontSize} onValueChange={(value) => handleCustomizationChange('fontSize', value as any)} className="flex items-center border rounded-lg p-1 w-min">
                  <Label htmlFor="font-sm" className={cn("rounded-md px-3 py-1.5 cursor-pointer transition-colors text-sm", customization.fontSize === 'sm' && "bg-primary text-primary-foreground")}>
                    <RadioGroupItem value="sm" id="font-sm" className="sr-only" />
                    Small
                  </Label>
                  <Label htmlFor="font-default" className={cn("rounded-md px-3 py-1.5 cursor-pointer transition-colors text-sm", customization.fontSize === 'default' && "bg-primary text-primary-foreground")}>
                    <RadioGroupItem value="default" id="font-default" className="sr-only" />
                    Default
                  </Label>
                  <Label htmlFor="font-lg" className={cn("rounded-md px-3 py-1.5 cursor-pointer transition-colors text-sm", customization.fontSize === 'lg' && "bg-primary text-primary-foreground")}>
                    <RadioGroupItem value="lg" id="font-lg" className="sr-only" />
                    Large
                  </Label>
                </RadioGroup>
              </div>
            </div>
          </CardContent>
        </Card>

      <AlertDialog open={isDeleteRequestDialogOpen} onOpenChange={setIsDeleteRequestDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action is permanent. By proceeding, you will submit a request to delete your account and all associated data. Your account will be immediately deactivated. You will be logged out upon confirmation.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isRequestingDelete}><XCircle className="mr-2 h-4 w-4"/>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleRequestDeletion}
              disabled={isRequestingDelete}
            >
              {isRequestingDelete && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isRequestingDelete ? "Submitting..." : "Yes, request deletion"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <Dialog open={isChangePasswordDialogOpen} onOpenChange={setIsChangePasswordDialogOpen}>
          <DialogContent>
              <DialogHeader>
                  <DialogTitle>Change Your Password</DialogTitle>
                  <DialogDescription>
                      Enter your current password and a new password below. You will be logged out after a successful change.
                  </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleChangePassword} className="space-y-4 py-2">
                  <div className="space-y-2">
                      <Label htmlFor="currentPasswordDlg">Current Password</Label>
                      <div className="relative">
                          <Input id="currentPasswordDlg" type={showCurrentPassword ? 'text' : 'password'} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
                          <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-0" onClick={() => setShowCurrentPassword((p) => !p)}>
                              {showCurrentPassword ? <EyeOff /> : <Eye />}
                          </Button>
                      </div>
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="newPasswordDlg">New Password</Label>
                      <div className="relative">
                          <Input id="newPasswordDlg" type={showNewPassword ? 'text' : 'password'} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
                          <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-0" onClick={() => setShowNewPassword((p) => !p)}>
                              {showNewPassword ? <EyeOff /> : <Eye />}
                          </Button>
                      </div>
                      {newPassword && (
                          <div className="mt-2">
                              <Progress value={passwordStrength} className={cn(
                                  "h-2",
                                  passwordStrength < 50 ? "bg-red-500" : passwordStrength < 75 ? "bg-yellow-500" : "bg-green-500"
                              )} />
                              <p className={cn(
                                  "text-xs mt-1",
                                  passwordStrength < 50 ? "text-red-500" : passwordStrength < 75 ? "text-yellow-500" : "text-green-500"
                              )}>
                                  {passwordStrength < 50 ? "Weak" : passwordStrength < 75 ? "Medium" : "Strong"}
                              </p>
                          </div>
                      )}
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="confirmNewPasswordDlg">Confirm New Password</Label>
                      <Input id="confirmNewPasswordDlg" type={showNewPassword ? 'text' : 'password'} value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} required />
                  </div>
                  <DialogFooter className="pt-2">
                      <Button type="button" variant="outline" onClick={() => setIsChangePasswordDialogOpen(false)} disabled={isChangingPassword}>
                          <XCircle className="mr-2 h-4 w-4" />Cancel
                      </Button>
                      <Button type="submit" disabled={isChangingPassword}>
                          {isChangingPassword ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                          Change Password
                      </Button>
                  </DialogFooter>
              </form>
          </DialogContent>
      </Dialog>
      
      <Dialog open={isEditEmailDialogOpen} onOpenChange={setIsEditEmailDialogOpen}>
          <DialogContent className="sm:max-w-md">
              <DialogHeader>
                  <DialogTitle>Change Your Email Address</DialogTitle>
                  <DialogDescription>
                      Enter your new email and current password. You will be logged out to complete the change.
                  </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-2">
                  <div>
                      <Label htmlFor="change-email-new">New Email</Label>
                      <Input id="change-email-new" type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} disabled={isUpdatingEmail} />
                  </div>
                  <div>
                      <Label htmlFor="change-email-password">Current Password</Label>
                      <Input id="change-email-password" type="password" value={currentPasswordForEmail} onChange={(e) => setCurrentPasswordForEmail(e.target.value)} disabled={isUpdatingEmail} />
                  </div>
              </div>
              <DialogFooter>
                  <Button variant="outline" onClick={() => setIsEditEmailDialogOpen(false)} disabled={isUpdatingEmail}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button>
                  <Button onClick={handleUpdateEmail} disabled={isUpdatingEmail}>
                      {isUpdatingEmail ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4"/>}
                      Update Email
                  </Button>
              </DialogFooter>
          </DialogContent>
      </Dialog>
    </>
  );
}
