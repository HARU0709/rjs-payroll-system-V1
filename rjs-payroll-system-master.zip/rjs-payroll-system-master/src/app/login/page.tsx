
'use client';

import { useState, useEffect, type FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { LogIn, Mail, Lock, Sun, Moon, Facebook, Instagram, Linkedin, Youtube, Globe, Loader2, Eye, EyeOff, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import Image from 'next/image';
import { auth, db } from '@/lib/firebase';
import { signInWithEmailAndPassword, sendPasswordResetEmail, signOut } from 'firebase/auth';
import { doc, getDoc, collection, addDoc, updateDoc } from 'firebase/firestore';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";


export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const router = useRouter();
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Forgot Password State
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [isSendingReset, setIsSendingReset] = useState(false);


  useEffect(() => {
    const checkDarkMode = () => document.documentElement.classList.contains('dark');
    setIsDarkMode(checkDarkMode());

    const observer = new MutationObserver(() => {
      setIsDarkMode(checkDarkMode());
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

    return () => observer.disconnect();
  }, []);

  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        title: 'Error',
        description: 'Please enter both email and password.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);
    try {
      // Step 1: Attempt to sign in
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Step 2: Check the user's profile for deletion request and get their name
      const employeeDocRef = doc(db, 'employees', user.uid);
      const employeeDocSnap = await getDoc(employeeDocRef);

      if (employeeDocSnap.exists()) {
        const employeeData = employeeDocSnap.data();

        if (employeeData.deletionRequested) {
          await signOut(auth);
          toast({
            title: 'Login Denied',
            description: 'Your account is pending deletion. You cannot log in at this time.',
            variant: 'destructive',
            duration: 7000,
          });
          return;
        }

        // Log successful login
        const nameParts = (employeeData.name || 'User').split(' ');
        const initials = (nameParts.length > 1 ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}` : (employeeData.name || 'U').substring(0, 2)).toUpperCase();
        
        await addDoc(collection(db, "activityFeedItems"), {
          text: 'logged in.',
          userId: user.uid,
          userName: employeeData.name,
          userRole: employeeData.permissionRole || "User",
          avatarUrl: employeeData.avatarUrl || "",
          avatarFallback: initials,
          timestamp: new Date(),
          relatedEntityType: 'login',
          relatedEntityId: user.uid,
          ipAddress: null, // IP address logging from client is unreliable and a security risk. Best handled server-side if needed.
        });
        
        // Update last login info
        await updateDoc(employeeDocRef, {
          lastLogin: {
            timestamp: new Date(),
            ipAddress: null,
          }
        });
      }
      
      toast({
        title: 'Login Successful',
        description: 'Welcome back!',
        variant: 'success',
      });
      router.push('/dashboard');

    } catch (error) {
      let errorMessage = 'An unexpected error occurred during login.';
      if (typeof error === 'object' && error !== null && 'code' in error && typeof (error as any).code === 'string') {
        const firebaseError = error as { code: string; message: string };
        switch (firebaseError.code) {
          case 'auth/user-not-found':
          case 'auth/wrong-password':
          case 'auth/invalid-credential':
            errorMessage = 'Invalid email or password.';
            break;
          case 'auth/invalid-email':
            errorMessage = 'Please enter a valid email address.';
            break;
          default:
            errorMessage = `Login failed: ${firebaseError.message}`;
        }
      } else if (error instanceof Error) {
        errorMessage = `Login failed: ${error.message}`;
      }
      toast({
        title: 'Login Failed',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleForgotPassword = async () => {
    if (!forgotPasswordEmail) {
      toast({ title: 'Error', description: 'Please enter an email address.', variant: 'destructive' });
      return;
    }
    setIsSendingReset(true);
    try {
      await sendPasswordResetEmail(auth, forgotPasswordEmail);
      toast({ title: 'Success', description: 'If an account exists for that email, a password reset link has been sent.', variant: 'success' });
      setIsForgotPasswordOpen(false);
      setForgotPasswordEmail('');
    } catch (error) {
      console.error("Password reset error:", error);
      toast({ title: 'Error', description: 'Failed to send password reset email. Please try again.', variant: 'destructive' });
    } finally {
      setIsSendingReset(false);
    }
  };

  return (
    <>
      <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
        <div className="grid md:grid-cols-2 gap-0 max-w-4xl w-full">
          <div className="hidden md:flex flex-col items-center justify-center bg-primary p-8 rounded-l-lg text-primary-foreground">
            <h2 className="text-3xl font-bold mb-6 text-center">
              About Us
            </h2>
            <p className="text-sm text-primary-foreground/90 text-center mb-8">
              In December 2014, Rightjob Solutions began its journey from a cozy apartment bedroom, driven by the vision of Jasper, a seasoned BPO industry professional with over a decade of leadership experience. Transitioning into freelancing, Jasper sought to create an income stream while balancing family responsibilities.
            </p>
             <p className="text-sm text-primary-foreground/90 text-center mb-8">
              With a deep understanding of the BPO sector, Jasper founded Rightjob Solutions to offer a flexible work environment for rural teams. The company’s focus on digital marketing and social media ads reflects its commitment to innovation. Since its humble beginnings, the talented local team, including Software Developers and Virtual Assistance Specialists, has grown. At Rightjob Solutions, we are dedicated to harnessing local talent to provide exceptional BPO and IT services.
            </p>
            <div className="mt-auto flex space-x-4">
              <a href="https://rightjobsolutions.com/" target="_blank" rel="noopener noreferrer" aria-label="Website" className="h-10 w-10 rounded-full flex items-center justify-center bg-primary-foreground/10 hover:bg-primary-foreground/20 transition-colors">
                <Globe className="h-6 w-6" />
              </a>
              <a href="https://www.facebook.com/rightjobsolns" target="_blank" rel="noopener noreferrer" aria-label="Facebook" className="h-10 w-10 rounded-full flex items-center justify-center bg-primary-foreground/10 hover:bg-primary-foreground/20 transition-colors">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="https://www.instagram.com/rightjobsolutions/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="h-10 w-10 rounded-full flex items-center justify-center bg-primary-foreground/10 hover:bg-primary-foreground/20 transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="https://www.youtube.com/channel/UC5Jpa7IPhgRnU2c6XuS9QrQ" target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="h-10 w-10 rounded-full flex items-center justify-center bg-primary-foreground/10 hover:bg-primary-foreground/20 transition-colors">
                <Youtube className="h-6 w-6" />
              </a>
              <a href="https://www.google.com/maps/place/Rightjob+Solutions/@6.9324375,122.0725724,16.75z/data=!4m6!3m5!1s0x325041901b873691:0x5c785cc35f631c5a!8m2!3d6.932711!4d122.07202!16s%2Fg%2F11b7cjjl1t?entry=ttu&g_ep=EgoyMDI1MDcwOC4wIKXMDSoASAFQAw%3D%3D" target="_blank" rel="noopener noreferrer" aria-label="Google Maps" className="h-10 w-10 rounded-full flex items-center justify-center bg-primary-foreground/10 hover:bg-primary-foreground/20 transition-colors">
                <MapPin className="h-6 w-6" />
              </a>
            </div>
          </div>
          <Card className="w-full md:rounded-l-none shadow-xl relative">
            <CardHeader className="text-center pt-8">
              <div className="absolute top-4 right-4">
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Toggle Theme"
                  onClick={toggleTheme}
                  className="rounded-full relative overflow-hidden focus-visible:ring-0 focus-visible:ring-offset-0 transition-colors duration-200 hover:text-muted-foreground"
                >
                  <Sun
                    className={cn(
                      "h-5 w-5 transition-all duration-300 ease-in-out",
                      isDarkMode ? "transform rotate-90 scale-0 opacity-0" : "transform rotate-0 scale-100 opacity-100"
                    )}
                  />
                  <Moon
                    className={cn(
                      "h-5 w-5 absolute transition-all duration-300 ease-in-out",
                      isDarkMode ? "transform rotate-0 scale-100 opacity-100" : "transform rotate-90 scale-0 opacity-0"
                    )}
                  />
                </Button>
              </div>
              <div className="mx-auto mb-6">
                <Image
                  src="https://i.ibb.co/WNYDj92H/RJS-PAYROLL-SYSTEM-LOGO-LIGHT-MODE.png"
                  alt="RJS Payroll System Logo"
                  width={200}
                  height={50}
                  className="hidden dark:block"
                  priority
                />
                <Image
                  src="https://i.ibb.co/RT47BTnh/RJS-PAYROLL-SYSTEM-LOGO-DARK-MODE.png"
                  alt="RJS Payroll System Logo"
                  width={200}
                  height={50}
                  className="block dark:hidden"
                  priority
                />
              </div>
              <CardTitle className="text-2xl font-bold whitespace-nowrap">Welcome to RJS Payroll System</CardTitle>
              <CardDescription>Please sign in to access your account.</CardDescription>
            </CardHeader>
            <CardContent className="pb-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      disabled={isLoading}
                      className="pl-10 h-12 text-base"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">Password</Label>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      disabled={isLoading}
                      className="pl-10 pr-10 h-12 text-base"
                    />
                    <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground hover:translate-y-0"
                        onClick={() => setShowPassword((prev) => !prev)}
                        disabled={isLoading}
                        aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                        {showPassword ? (
                            <EyeOff className="h-5 w-5" />
                        ) : (
                            <Eye className="h-5 w-5" />
                        )}
                    </Button>
                  </div>
                </div>
                <Button type="submit" className="w-full h-12 text-lg" disabled={isLoading}>
                  {isLoading ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <LogIn className="mr-2 h-5 w-5" />}
                  {isLoading ? 'Signing In...' : 'Sign In'}
                </Button>
                 <div className="text-center">
                  <Button variant="link" type="button" onClick={() => setIsForgotPasswordOpen(true)} className="px-0 h-auto text-sm font-medium">
                    Forgot Password?
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
        <p className="mt-8 text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} RJS Payroll System. All rights reserved.
        </p>
      </div>

      <AlertDialog open={isForgotPasswordOpen} onOpenChange={setIsForgotPasswordOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset Password</AlertDialogTitle>
            <AlertDialogDescription>
              Enter your email address below, and we'll send you a link to reset your password.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2 py-2">
            <Label htmlFor="forgot-email" className="sr-only">Email</Label>
            <Input
              id="forgot-email"
              type="email"
              placeholder="you@example.com"
              value={forgotPasswordEmail}
              onChange={(e) => setForgotPasswordEmail(e.target.value)}
              disabled={isSendingReset}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSendingReset}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleForgotPassword} disabled={isSendingReset}>
              {isSendingReset ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {isSendingReset ? 'Sending...' : 'Send Reset Link'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
