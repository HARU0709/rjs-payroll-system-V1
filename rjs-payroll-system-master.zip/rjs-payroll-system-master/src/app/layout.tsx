
import type { Metadata } from 'next';
import { Open_Sans, Roboto, Lato } from 'next/font/google';
import './globals.css';
import { MainLayout } from '@/components/layout/main-layout';
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from '@/contexts/auth-context';

const openSans = Open_Sans({
  subsets: ['latin'],
  variable: '--font-app-sans',
});
const roboto = Roboto({
  subsets: ['latin'],
  weight: ['400', '500', '700'],
  variable: '--font-app-roboto',
});
const lato = Lato({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-app-lato',
});

export const metadata: Metadata = {
  title: 'RJS Payroll System',
  description: 'Comprehensive Payroll and HR Management for RJS Payroll System',
  icons: {
    icon: 'https://i.ibb.co/mX5qPz7/RJS-PAYROLL-SYSTEM-LOGO-FAVICON.png',
    apple: 'https://i.ibb.co/mX5qPz7/RJS-PAYROLL-SYSTEM-LOGO-FAVICON.png',
  },
};


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={`${openSans.variable} ${roboto.variable} ${lato.variable}`}>
      <head />
      <body className="font-sans antialiased">
        <AuthProvider>
          <MainLayout>{children}</MainLayout>
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  );
}
