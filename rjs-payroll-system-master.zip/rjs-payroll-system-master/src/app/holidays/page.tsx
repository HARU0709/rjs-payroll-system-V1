
'use client';

import { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import { PageHeader } from '@/components/shared/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { DatePicker } from '@/components/ui/date-picker';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { Gift, PlusCircle, Loader2, Save, XCircle, Trash2, Repeat, Edit, Sparkles, Search } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, query, addDoc, deleteDoc, doc, where, orderBy, updateDoc, writeBatch } from 'firebase/firestore';
import type { AttendanceEvent } from '@/types';
import { useRouter } from 'next/navigation';
import { ScrollArea } from '@/components/ui/scroll-area';

const holidayFormSchema = z.object({
  title: z.string().min(3, "Holiday name must be at least 3 characters long."),
  date: z.date({ required_error: "Date is required." }),
  repeatsYearly: z.boolean().default(false),
});

type HolidayFormValues = z.infer<typeof holidayFormSchema>;

const commonNationalHolidays = [
  // Regular Holidays for 2025
  { name: "New Year's Day", month: 0, day: 1, repeats: true },
  { name: "Araw ng Kagitingan", month: 3, day: 9, repeats: true },
  { name: "Maundy Thursday", month: 3, day: 17, repeats: false, year: 2025 },
  { name: "Good Friday", month: 3, day: 18, repeats: false, year: 2025 },
  { name: "Labor Day", month: 4, day: 1, repeats: true },
  { name: "Independence Day", month: 5, day: 12, repeats: true },
  { name: "National Heroes Day", month: 7, day: 25, repeats: false, year: 2025 }, // Last Monday of August 2025
  { name: "Bonifacio Day", month: 10, day: 30, repeats: true },
  { name: "Christmas Day", month: 11, day: 25, repeats: true },
  { name: "Rizal Day", month: 11, day: 30, repeats: true },
  
  // Special Non-Working Days for 2025
  { name: "Chinese New Year", month: 0, day: 29, repeats: false, year: 2025 },
  { name: "Black Saturday", month: 3, day: 19, repeats: false, year: 2025 },
  { name: "Ninoy Aquino Day", month: 7, day: 21, repeats: true },
  { name: "All Saints' Day", month: 10, day: 1, repeats: true },
  { name: "All Souls' Day", month: 10, day: 2, repeats: true },
  { name: "Feast of the Immaculate Conception", month: 11, day: 8, repeats: true },
  { name: "Christmas Eve", month: 11, day: 24, repeats: true },
  { name: "Last Day of the Year", month: 11, day: 31, repeats: true },

  // Muslim Holidays (Tentative)
  { name: "Eid'l Fitr", month: 3, day: 1, repeats: false, year: 2025 },
  { name: "Eid'l Adha", month: 5, day: 6, repeats: false, year: 2025 },
];

interface SelectableHoliday {
  id: string;
  name: string;
  month: number;
  day: number;
  repeats: boolean;
  year?: number;
  checked: boolean;
}

export default function HolidaysPage() {
  const { employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';
  const { toast } = useToast();
  const router = useRouter();

  const [holidays, setHolidays] = useState<AttendanceEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [holidayToDelete, setHolidayToDelete] = useState<AttendanceEvent | null>(null);
  
  const [holidayToEdit, setHolidayToEdit] = useState<AttendanceEvent | null>(null);
  
  // State for the seeding modal
  const [isSeedDialogOpen, setIsSeedDialogOpen] = useState(false);
  const [selectableHolidays, setSelectableHolidays] = useState<SelectableHoliday[]>([]);
  const [isSeeding, setIsSeeding] = useState(false);

  const [searchTerm, setSearchTerm] = useState('');

  const form = useForm<HolidayFormValues>({
    resolver: zodResolver(holidayFormSchema),
    defaultValues: {
      repeatsYearly: false,
      date: new Date(),
    },
  });

  useEffect(() => {
    if (authLoading) return;
    if (!isAdmin) {
      router.push('/dashboard');
      return;
    }

    setLoading(true);
    const holidaysQuery = query(
      collection(db, "attendanceEvents"), 
      where("status", "==", "Holiday"),
      orderBy("date", "asc")
    );
    const unsubscribe = onSnapshot(holidaysQuery, (snapshot) => {
      const fetchedHolidays = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          date: data.date?.toDate ? data.date.toDate() : new Date(0),
        } as AttendanceEvent;
      });
      setHolidays(fetchedHolidays);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching holidays:", error);
      toast({ title: "Error", description: "Failed to fetch holidays.", variant: "destructive" });
      setLoading(false);
    });

    return () => unsubscribe();
  }, [isAdmin, authLoading, router, toast]);

  const filteredHolidays = useMemo(() => {
    return holidays.filter(holiday => 
      holiday.title?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [holidays, searchTerm]);

  const handleOpenSeedDialog = () => {
    const existingHolidayNames = new Set(holidays.map(h => h.title?.toLowerCase()));
    const selectable = commonNationalHolidays.map((holiday, index) => ({
      ...holiday,
      id: `common-${index}`,
      checked: !existingHolidayNames.has(holiday.name.toLowerCase()), // Default to checked if not already present
    }));
    setSelectableHolidays(selectable);
    setIsSeedDialogOpen(true);
  };
  
  const handleSelectableHolidayChange = (id: string, checked: boolean) => {
    setSelectableHolidays(prev =>
      prev.map(h => (h.id === id ? { ...h, checked } : h))
    );
  };

  const handleSelectAllHolidays = (checked: boolean) => {
    setSelectableHolidays(prev => prev.map(h => ({ ...h, checked })));
  };

  const handleAddSelectedHolidays = async () => {
    setIsSeeding(true);
    const holidaysToAdd = selectableHolidays.filter(h => h.checked);

    if (holidaysToAdd.length === 0) {
        toast({ title: "No new holidays to add", description: "All selected holidays already exist in your list.", variant: "default" });
        setIsSeeding(false);
        return;
    }
    
    try {
      const batch = writeBatch(db);
      const currentYear = new Date().getFullYear();
      
      const existingHolidayNames = new Set(holidays.map(h => h.title?.toLowerCase()));
      const newHolidays = holidaysToAdd.filter(h => !existingHolidayNames.has(h.name.toLowerCase()));

      if (newHolidays.length === 0) {
        toast({ title: "No new holidays to add", description: "All selected holidays already exist.", variant: 'default' });
        setIsSeedDialogOpen(false);
        setIsSeeding(false);
        return;
      }

      newHolidays.forEach(holiday => {
        const holidayDocRef = doc(collection(db, "attendanceEvents"));
        const holidayDate = new Date(holiday.year || currentYear, holiday.month, holiday.day);
        
        const holidayData: Omit<AttendanceEvent, 'id'> = {
          title: holiday.name,
          date: holidayDate,
          status: 'Holiday',
          repeatsYearly: holiday.repeats,
          description: holiday.repeats ? 'Recurring Holiday' : 'One-time Holiday'
        };
        batch.set(holidayDocRef, holidayData);
      });

      await batch.commit();
      toast({ title: "Success", description: `${newHolidays.length} holiday(s) have been added.`, variant: 'success' });
      setIsSeedDialogOpen(false);

    } catch (error) {
      console.error("Error seeding holidays:", error);
      toast({ title: "Error", description: "Could not add selected holidays.", variant: "destructive" });
    } finally {
      setIsSeeding(false);
    }
  };


  const handleOpenFormDialog = (holiday: AttendanceEvent | null) => {
    setHolidayToEdit(holiday);
    if (holiday) {
      form.reset({
        title: holiday.title || '',
        date: holiday.date,
        repeatsYearly: holiday.repeatsYearly || false,
      });
    } else {
      form.reset({ title: '', date: new Date(), repeatsYearly: false });
    }
    setIsFormDialogOpen(true);
  };
  
  const handleFormSubmit = async (data: HolidayFormValues) => {
    setIsSubmitting(true);
    try {
      if (holidayToEdit) {
        // Update existing holiday
        const docRef = doc(db, "attendanceEvents", holidayToEdit.id!);
        await updateDoc(docRef, { ...data, status: 'Holiday' });
        toast({ title: "Success", description: "Holiday updated." });
      } else {
        // Create new holiday
        await addDoc(collection(db, "attendanceEvents"), {
          title: data.title,
          date: data.date,
          status: 'Holiday',
          repeatsYearly: data.repeatsYearly,
          description: data.repeatsYearly ? 'Recurring Holiday' : 'One-time Holiday'
        });
        toast({ title: "Success", description: "Holiday has been added." });
      }
      setIsFormDialogOpen(false);
    } catch (error) {
      console.error("Error saving holiday:", error);
      toast({ title: "Error", description: "Failed to save holiday.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleOpenDeleteDialog = (holiday: AttendanceEvent) => {
    if (holiday.isStatic) return;
    setHolidayToDelete(holiday);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!holidayToDelete || !holidayToDelete.id) return;
    setIsSubmitting(true);
    try {
      await deleteDoc(doc(db, "attendanceEvents", holidayToDelete.id));
      toast({ title: "Success", description: "Holiday deleted.", variant: 'success' });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Error deleting holiday:", error);
      toast({ title: "Error", description: "Failed to delete holiday.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
      setHolidayToDelete(null);
    }
  };
  
  if (authLoading) {
    return (
      <div className="space-y-4">
        <PageHeader title="Company Holidays" description="Loading..." />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const isAllSelected = selectableHolidays.every(h => h.checked);
  const isSomeSelected = selectableHolidays.some(h => h.checked) && !isAllSelected;

  return (
    <>
      <PageHeader
        icon={<Gift className="h-7 w-7 text-primary" />}
        title="Company Holidays"
        description="Add, view, and manage all company-wide holidays."
      />
      
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex-grow">
              <CardTitle>Holiday Management</CardTitle>
              <CardDescription>
                All company holidays are managed from this table.
              </CardDescription>
            </div>
            <div className="flex w-full md:w-auto items-center gap-2">
              <Button variant="outline" onClick={handleOpenSeedDialog} disabled={isSeeding}>
                  {isSeeding ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Sparkles className="mr-2 h-4 w-4" />}
                  Seed Common Holidays
              </Button>
              <Button onClick={() => handleOpenFormDialog(null)}><PlusCircle className="mr-2 h-4 w-4" /> Add Holiday</Button>
            </div>
          </div>
          <div className="mt-4 relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
             <Input
                placeholder="Search holidays..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 max-w-sm"
              />
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : filteredHolidays.length === 0 ? (
            <div className="text-center p-12">
              <Gift className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-medium">
                {searchTerm ? 'No holidays found' : 'Your Holiday List is Empty'}
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {searchTerm ? `No results for "${searchTerm}".` : 'Get started by adding a custom holiday or seeding common holidays.'}
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Holiday Name</TableHead>
                  <TableHead>Repeats</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                  {filteredHolidays.map(holiday => (
                    <TableRow key={holiday.id}>
                      <TableCell className="font-medium">
                        {holiday.repeatsYearly ? format(holiday.date, 'MMMM dd') : format(holiday.date, 'PPP')}
                      </TableCell>
                      <TableCell>{holiday.title}</TableCell>
                      <TableCell>
                        {holiday.repeatsYearly ? (
                           <span className="flex items-center text-green-600 dark:text-green-400 font-medium">
                              <Repeat className="mr-2 h-4 w-4" /> Yes
                          </span>
                        ) : 'No'}
                      </TableCell>
                      <TableCell className="text-right">
                         <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleOpenFormDialog(holiday)}
                        >
                          <Edit className="h-4 w-4 text-primary" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-destructive hover:text-destructive" 
                          onClick={() => handleOpenDeleteDialog(holiday)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{holidayToEdit ? 'Edit' : 'Add New'} Holiday</DialogTitle>
            <DialogDescription>
              {holidayToEdit ? 'Update the details for this holiday.' : 'Select a date and provide a name for the new holiday.'}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form id="holiday-form" onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4 py-2">
              <FormField control={form.control} name="title" render={({ field }) => (
                <FormItem><FormLabel>Holiday Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="date" render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Date</FormLabel>
                  <DatePicker 
                    date={field.value} 
                    onDateChange={field.onChange}
                    buttonClassName="w-full"
                  />
                  <FormMessage />
                </FormItem>
              )} />
               <FormField
                  control={form.control}
                  name="repeatsYearly"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Repeat yearly?
                        </FormLabel>
                        <FormDescription>
                          If checked, this holiday will automatically appear every year on the selected date.
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
            </form>
          </Form>
          <DialogFooter>
            <DialogClose asChild><Button type="button" variant="outline" disabled={isSubmitting}><XCircle className="mr-2 h-4 w-4" />Cancel</Button></DialogClose>
            <Button type="submit" form="holiday-form" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Save Holiday
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the holiday "{holidayToDelete?.title}". This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setHolidayToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} disabled={isSubmitting} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4"/>} Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={isSeedDialogOpen} onOpenChange={setIsSeedDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Seed Common National Holidays</DialogTitle>
            <DialogDescription>
              Select the holidays you want to add to your company calendar. Holidays already on your list are unchecked by default.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex items-center px-3 py-2 border-b">
              <Checkbox
                id="select-all"
                checked={isAllSelected}
                onCheckedChange={(checked) => handleSelectAllHolidays(Boolean(checked))}
                aria-label="Select all"
              />
              <label htmlFor="select-all" className="ml-3 text-sm font-medium">
                Select All
              </label>
            </div>
            <ScrollArea className="h-72">
              <div className="p-1">
                {selectableHolidays.map((holiday) => (
                  <div key={holiday.id} className="flex items-center space-x-3 p-2 rounded-md hover:bg-muted/50">
                    <Checkbox
                      id={holiday.id}
                      checked={holiday.checked}
                      onCheckedChange={(checked) => handleSelectableHolidayChange(holiday.id, Boolean(checked))}
                    />
                    <label htmlFor={holiday.id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      {holiday.name} ({format(new Date(holiday.year || new Date().getFullYear(), holiday.month, holiday.day), 'MMM d')})
                    </label>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button type="button" variant="outline" disabled={isSeeding}><XCircle className="mr-2 h-4 w-4" />Cancel</Button></DialogClose>
            <Button onClick={handleAddSelectedHolidays} disabled={isSeeding}>
              {isSeeding ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlusCircle className="mr-2 h-4 w-4" />}
              Add Selected Holidays
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
