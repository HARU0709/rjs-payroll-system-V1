
'use client';

import { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { format, isSameDay, parseISO, isValid, addMonths, subMonths, getYear, setYear } from 'date-fns';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, query, where, orderBy, Timestamp, limit } from 'firebase/firestore';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/auth-context';

import { PageHeader } from '@/components/shared/page-header';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, ChevronLeft, ChevronRight, Gift, Circle, Loader2, CalendarDays as PageIcon, Users, ListChecks, AlertCircle, Clock, HelpCircle, Info, CalendarDays as CalendarIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { AttendanceEvent, Employee, LeaveRequest } from '@/types';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const parseDateSafe = (dateInput: string | Date | Timestamp | undefined | null): Date | null => {
  if (!dateInput) return null;
  if (dateInput instanceof Date) return isValid(dateInput) ? dateInput : null;
  if (dateInput instanceof Timestamp) return dateInput.toDate();
  if (typeof dateInput === 'string') {
    const parsed = parseISO(dateInput);
    return isValid(parsed) ? parsed : null;
  }
  return null;
};

const calculateDuration = (startDateStr: string, endDateStr: string): string => {
  const start = parseDateSafe(startDateStr);
  const end = parseDateSafe(endDateStr);
  if (!start || !end) return 'N/A';
  
  const days = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  if (days <= 0) return 'Invalid dates';
  return `${days} day${days > 1 ? 's' : ''}`;
};


const formatLeaveDateRange = (startDateStr: string, endDateStr: string): string => {
  const start = parseDateSafe(startDateStr);
  const end = parseDateSafe(endDateStr);
  if (!start || !end) return 'N/A';

  const startFormatted = format(start, 'MMM d');
  if (isSameDay(start, end)) {
    return startFormatted;
  }
  const endFormatted = format(end, 'MMM d');
  return `${startFormatted} - ${endFormatted}`;
};

const ITEMS_PER_PAGE_UPCOMING = 3;

export default function VisualCalendarPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, loading: authLoading } = useAuth(); 
  const [currentMonthDisplay, setCurrentMonthDisplay] = useState<Date>(new Date());
  const [allEvents, setAllEvents] = useState<AttendanceEvent[]>([]);
  const [loadingEvents, setLoadingEvents] = useState<boolean>(true);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loadingEmployees, setLoadingEmployees] = useState<boolean>(true);
  const [selectedEmployeeFilter, setSelectedEmployeeFilter] = useState<string>('all');

  const [upcomingApprovedLeaves, setUpcomingApprovedLeaves] = useState<LeaveRequest[]>([]);
  const [loadingUpcomingLeaves, setLoadingUpcomingLeaves] = useState<boolean>(true);
  const [pendingLeaves, setPendingLeaves] = useState<LeaveRequest[]>([]);
  const [loadingPendingLeaves, setLoadingPendingLeaves] = useState<boolean>(true);
  const [rejectedLeaves, setRejectedLeaves] = useState<LeaveRequest[]>([]);
  const [loadingRejectedLeaves, setLoadingRejectedLeaves] = useState<boolean>(true);
  
  const [upcomingLeavesPage, setUpcomingLeavesPage] = useState(0);

  const displayedUpcomingLeaves = useMemo(() => {
    return upcomingApprovedLeaves.slice(
      upcomingLeavesPage * ITEMS_PER_PAGE_UPCOMING,
      (upcomingLeavesPage + 1) * ITEMS_PER_PAGE_UPCOMING
    );
  }, [upcomingApprovedLeaves, upcomingLeavesPage]);

  useEffect(() => {
    if (authLoading || !user) {
        setLoadingEmployees(false);
        return;
    }

    setLoadingEmployees(true);
    const q = query(collection(db, "employees"), orderBy("name"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedEmployees = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee));
      setEmployees(fetchedEmployees.filter(emp => emp.employeeId !== 'ADMIN'));
      setLoadingEmployees(false);
    }, (error) => {
      console.error("Error fetching employees:", error);
      toast({ title: "Error", description: "Could not load employees for filter.", variant: "destructive" });
      setLoadingEmployees(false);
    });
    return () => unsubscribe();
  }, [toast, authLoading, user]);

  useEffect(() => {
    if (authLoading || !user) {
        setLoadingEvents(false);
        setAllEvents([]);
        return;
    }
    setLoadingEvents(true);
    const year = getYear(currentMonthDisplay);

    const holidaysQuery = query(collection(db, "attendanceEvents"), where("status", "==", "Holiday"));
    const leavesQuery = query(collection(db, "leaveRequests"), where("status", "==", "Approved"));

    let unsubHolidays: (() => void) | null = null;
    let unsubLeaves: (() => void) | null = null;
    
    unsubHolidays = onSnapshot(holidaysQuery, (holidaySnapshot) => {
        const fetchedHolidays = holidaySnapshot.docs.flatMap(doc => {
            const data = doc.data() as Omit<AttendanceEvent, 'id'>;
            const eventDate = parseDateSafe(data.date);
            if (!eventDate) return [];

            const generatedEvents: AttendanceEvent[] = [];
            if (data.repeatsYearly) {
                generatedEvents.push({ id: `${doc.id}-${year}`, ...data, date: setYear(eventDate, year), title: data.title || 'Holiday' });
            } else if (getYear(eventDate) === year) {
                generatedEvents.push({ id: doc.id, ...data, date: eventDate, title: data.title || 'Holiday' });
            }
            return generatedEvents;
        });

        // This prevents re-attaching the listener if it's already running
        if (unsubLeaves) unsubLeaves();
        
        unsubLeaves = onSnapshot(leavesQuery, (leaveSnapshot) => {
            const approvedLeavesAsEvents = leaveSnapshot.docs.flatMap(docSnap => {
                const lr = { id: docSnap.id, ...docSnap.data() } as LeaveRequest;
                const startDate = parseDateSafe(lr.startDate);
                const endDate = parseDateSafe(lr.endDate);
                if (!startDate || !endDate) return [];
                if (selectedEmployeeFilter !== 'all' && lr.employeeId !== selectedEmployeeFilter) return [];

                const eventsList: AttendanceEvent[] = [];
                let currentDate = startDate;
                while (currentDate <= endDate) {
                    eventsList.push({
                    id: `${docSnap.id}-${format(currentDate, 'yyyy-MM-dd')}`,
                    date: new Date(currentDate),
                    status: 'Leave',
                    employeeId: lr.employeeId,
                    title: `Leave: ${employees.find(e => e.id === lr.employeeId)?.name || lr.employeeName || 'Unknown'} (${lr.leaveType})`,
                    description: lr.reason,
                    });
                    currentDate.setDate(currentDate.getDate() + 1);
                }
                return eventsList;
            });

            setAllEvents([...fetchedHolidays, ...approvedLeavesAsEvents]);
            setLoadingEvents(false);
        }, (error) => {
            console.error("Error fetching approved leaves:", error);
            if(user) toast({ title: "Error", description: "Could not load approved leaves for calendar view.", variant: "destructive" });
            setLoadingEvents(false);
        });

    }, (error) => {
        console.error("Error fetching holiday events:", error);
        toast({ title: "Error", description: "Could not fetch holiday events.", variant: "destructive" });
        setLoadingEvents(false);
    });

    return () => {
        if (unsubHolidays) unsubHolidays();
        if (unsubLeaves) unsubLeaves();
    };
  }, [toast, employees, selectedEmployeeFilter, currentMonthDisplay, authLoading, user]);

  const fetchLeaveCategory = (
    status: 'Approved' | 'Pending' | 'Rejected',
    setData: React.Dispatch<React.SetStateAction<LeaveRequest[]>>,
    setLoading: React.Dispatch<React.SetStateAction<boolean>>,
    limitCount = 10
  ) => {
    if (authLoading || !user) {
        setData([]);
        setLoading(false);
        return () => {};
    }
    setLoading(true);

    const queryConstraints: any[] = [
      where("status", "==", status),
    ];
    
    if (selectedEmployeeFilter !== 'all') {
      queryConstraints.push(where("employeeId", "==", selectedEmployeeFilter));
    }
    
    queryConstraints.push(limit(50));
    
    const q = query(collection(db, "leaveRequests"), ...queryConstraints);

    const unsubscribe = onSnapshot(q, (snapshot) => {
      let leaves = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LeaveRequest));
      
      if (status === 'Approved') {
        const today = format(new Date(), 'yyyy-MM-dd');
        leaves = leaves.filter(l => (l.endDate || "") >= today);
        leaves.sort((a, b) => (a.startDate || "").localeCompare(b.startDate || ""));
      } else { 
        leaves.sort((a, b) => (b.appliedDate || "").localeCompare(a.appliedDate || ""));
      }

      setData(leaves.slice(0, limitCount)); 
      setLoading(false);
    }, (error) => {
      console.error(`Error fetching ${status.toLowerCase()} leaves:`, error);
      toast({ title: "Error", description: `Could not load ${status.toLowerCase()} leaves.`, variant: "destructive" });
      setLoading(false);
    });
    return unsubscribe;
  };


  useEffect(() => {
    const unsubUpcoming = fetchLeaveCategory('Approved', setUpcomingApprovedLeaves, setLoadingUpcomingLeaves, 10);
    const unsubPending = fetchLeaveCategory('Pending', setPendingLeaves, setLoadingPendingLeaves, 5);
    const unsubRejected = fetchLeaveCategory('Rejected', setRejectedLeaves, setLoadingRejectedLeaves, 5);
    return () => {
      if (typeof unsubUpcoming === 'function') unsubUpcoming();
      if (typeof unsubPending === 'function') unsubPending();
      if (typeof unsubRejected === 'function') unsubRejected();
    };
  }, [toast, selectedEmployeeFilter, authLoading, user]);

  useEffect(() => {
    setUpcomingLeavesPage(0); // Reset page when filter changes
  }, [selectedEmployeeFilter]);


  const handlePrevMonth = () => setCurrentMonthDisplay(prev => subMonths(prev, 1));
  const handleNextMonth = () => setCurrentMonthDisplay(prev => addMonths(prev, 1));

  const CustomDayComponent = ({ date, displayMonth }: { date: Date; displayMonth: Date }) => {
    const isOutside = date.getMonth() !== displayMonth.getMonth();
    const dayOfMonth = format(date, 'd');
  
    const dayEvents = allEvents.filter(e => e.date && isSameDay(e.date, date));
    const isHoliday = dayEvents.some(e => e.status === 'Holiday');
    const isLeave = dayEvents.some(e => e.status === 'Leave');
    const isWeekendDay = date.getDay() === 0 || date.getDay() === 6;
  
    let cellClassName = cn(
      "relative h-24 w-full flex flex-col items-start justify-start p-1.5 text-sm",
      "rounded-sm",
      isOutside ? "text-muted-foreground/40 bg-background" : "bg-card",
      isHoliday && !isLeave ? "bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-700/50 text-red-700 dark:text-red-300"
        : isLeave ? "bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-700/50 text-green-700 dark:text-green-300"
          : isWeekendDay && !isOutside ? "bg-muted/40 dark:bg-muted/30"
            : isOutside ? "border-transparent"
              : "border-border/50"
    );
  
    if (!isOutside && !isHoliday && !isLeave && !isWeekendDay) {
      cellClassName = cn(cellClassName, "border border-border/50");
    }
    if (isHoliday && isLeave) {
      cellClassName = cn("relative h-24 w-full flex flex-col items-start justify-start p-1.5 text-sm rounded-sm bg-purple-50 dark:bg-purple-900/30 border border-purple-200 dark:border-purple-700/50 text-purple-700 dark:text-purple-300");
    }
  
    const DayCell = (
      <div className={cellClassName}>
        <span className={cn("font-normal mb-1", isOutside && "opacity-60")}>
          {dayOfMonth}
        </span>
        <div className="absolute bottom-2 left-0 right-0 flex justify-center items-center space-x-1">
          {isHoliday && <Gift className="h-4 w-4 text-red-500 dark:text-red-400" />}
          {isLeave && <Circle className="h-3 w-3 text-green-500 dark:text-green-400 fill-current" />}
        </div>
      </div>
    );
  
    if (dayEvents.length > 0 && !isOutside) {
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>{DayCell}</TooltipTrigger>
            <TooltipContent>
              <ul className="space-y-1 p-1">
                {dayEvents.map(event => (
                  <li key={event.id} className="text-sm">
                    {event.status === 'Holiday' ? (
                      <span className="flex items-center gap-2"><Gift className="h-4 w-4 text-red-500" /> {event.title}</span>
                    ) : (
                      <span className="flex items-center gap-2"><Circle className="h-3 w-3 text-green-500 fill-current" /> {event.title}</span>
                    )}
                  </li>
                ))}
              </ul>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }
  
    return DayCell;
  };

  const renderLeaveListCard = (
      leaves: LeaveRequest[],
      loading: boolean,
      title: string,
      description: string,
      emptyMessage: string,
      cardIconProp: React.ElementType, 
      dotColorClass: string 
    ) => {
    return (
      <Card className="shadow-lg flex-1 min-h-[250px] flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center">
            <span className={cn("h-3 w-3 rounded-full mr-2 shrink-0", dotColorClass)}></span>
            {title}
          </CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent className="px-4 pt-0 pb-4 flex-grow">
          {loading ? (
             <div className="space-y-2.5 p-1">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex justify-between items-start py-1.5">
                  <div className="space-y-1">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-20" />
                  </div>
                  <div className="space-y-1 text-right">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                </div>
              ))}
            </div>
          ) : leaves.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-6 text-center">
              <Info className="h-8 w-8 text-muted-foreground mb-1" />
              <p className="text-xs text-muted-foreground">{emptyMessage}</p>
            </div>
          ) : (
            <ScrollArea className="h-[180px] pr-2 -mr-2">
              <ul className="space-y-2.5">
                {leaves.map(leave => {
                  const emp = employees.find(e => e.id === leave.employeeId);
                  const employeeDisplayName = `${emp?.name || leave.employeeName}${user?.uid === leave.employeeId ? ' (User)' : ''}`;
                  return (
                    <li key={leave.id} className="flex justify-between items-start py-1.5 border-b border-border/50 last:border-b-0">
                      <div>
                        <p className="font-medium text-sm leading-tight">{employeeDisplayName}</p>
                        <p className="text-xs text-muted-foreground leading-tight">{leave.leaveType} Leave</p>
                      </div>
                      <div className="text-right shrink-0 pl-2">
                        <p className="text-sm leading-tight">{formatLeaveDateRange(leave.startDate, leave.endDate)}</p>
                        <p className="text-xs text-muted-foreground leading-tight">{calculateDuration(leave.startDate, leave.endDate)}</p>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    );
  };
  
  const pageDescription = `Displaying events for ${format(currentMonthDisplay, 'MMMM yyyy')}. Filter by employee or view all.`;

  return (
    <div className="py-4 sm:py-6 lg:py-8 px-4 sm:px-6 lg:px-8">
      <PageHeader
        icon={<PageIcon className="h-7 w-7 text-primary" />}
        title="Leave & Holiday Calendar"
        description={pageDescription}
        className="mb-3"
        actions={
          <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        }
      />

      <div className="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="shadow-lg">
            <CardHeader className="flex flex-col sm:flex-row items-center justify-between py-3 px-4 border-b gap-2">
              <CardTitle className="text-xl font-semibold text-primary">
                {format(currentMonthDisplay, 'MMMM yyyy')}
              </CardTitle>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Select value={selectedEmployeeFilter} onValueChange={setSelectedEmployeeFilter} disabled={loadingEmployees}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <span className="flex items-center">
                      <Users className="mr-2 h-4 w-4 text-muted-foreground" />
                      <SelectValue placeholder="Filter by Employee" />
                    </span>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Employees</SelectItem>
                    {employees.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                 <Button variant="outline" size="icon" onClick={handlePrevMonth} aria-label="Previous month">
                    <ChevronLeft className="h-5 w-5" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleNextMonth} aria-label="Next month">
                    <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {loadingEvents || loadingEmployees ? (
                <div className="flex items-center justify-center h-[calc(24rem+56px)]"> 
                  <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  <p className="ml-3 text-muted-foreground">Loading calendar data...</p>
                </div>
              ) : (
                <Calendar
                  month={currentMonthDisplay}
                  onMonthChange={setCurrentMonthDisplay}
                  mode="single"
                  selected={undefined} 
                  showOutsideDays={true}
                  className="w-full p-0 border-0 shadow-none bg-transparent"
                  classNames={{
                    months: "flex flex-col", 
                    month: "space-y-0 p-0", 
                    caption_label: "hidden", 
                    nav_button_previous: "hidden", 
                    nav_button_next: "hidden", 
                    table: "w-full border-collapse",
                    head_row: "flex border-b border-border/70",
                    head_cell: cn(
                      "text-muted-foreground font-medium text-xs sm:text-sm",
                      "w-[14.2857%] flex-1 text-center py-2 sm:py-3" 
                    ),
                    row: cn(
                      "flex w-full",
                      "[&:not(:last-child)]:border-b [&:not(:last-child)]:border-border/50" 
                    ),
                    cell: cn(
                      "p-0 relative w-[14.2857%] flex-1", 
                      "[&:not(:last-child)]:border-r [&:not(:last-child)]:border-border/50" 
                    ),
                    day: "h-full w-full focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 rounded-none", 
                    day_hidden: "invisible",
                  }}
                  components={{
                    Day: CustomDayComponent,
                  }}
                  modifiers={{
                    holiday: (date) => allEvents.some(e => e.status === 'Holiday' && e.date && isSameDay(e.date, date)),
                    leave: (date) => allEvents.some(e => e.status === 'Leave' && e.date && isSameDay(e.date, date)),
                  }}
                />
              )}
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-1 space-y-6">
           <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center text-primary">
                <ListChecks className="mr-2 h-5 w-5" />
                Upcoming Approved Leaves
              </CardTitle>
              <CardDescription>Approved leaves for the selected view.</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingUpcomingLeaves ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="p-3 rounded-md border">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <Skeleton className="h-4 w-24" />
                          <Skeleton className="h-3 w-16" />
                        </div>
                        <Skeleton className="h-8 w-8 rounded-full" />
                      </div>
                      <Skeleton className="h-3 w-full mt-2" />
                    </div>
                  ))}
                </div>
              ) : upcomingApprovedLeaves.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <Info className="h-10 w-10 text-muted-foreground mb-2" />
                  <p className="text-muted-foreground">No upcoming approved leaves.</p>
                </div>
              ) : (
                <ul className="space-y-3">
                  {displayedUpcomingLeaves.map(leave => {
                    const emp = employees.find(e => e.id === leave.employeeId);
                    const nameParts = (emp?.name || leave.employeeName || 'U').split(' ');
                    const initials = (nameParts.length > 1 ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}` : (emp?.name || leave.employeeName || 'U').substring(0, 2)).toUpperCase();
                    return (
                      <li key={leave.id} className="p-3 rounded-md border bg-card hover:bg-muted/50 transition-colors">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-sm">{emp?.name || leave.employeeName}</p>
                            <p className="text-xs text-muted-foreground">{leave.leaveType} Leave</p>
                          </div>
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={emp?.avatarUrl || undefined} alt={emp?.name || leave.employeeName} data-ai-hint="employee avatar" />
                            <AvatarFallback>{initials}</AvatarFallback>
                          </Avatar>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(parseISO(leave.startDate), 'MMM d')} - {format(parseISO(leave.endDate), 'MMM d, yyyy')}
                          <span className="ml-2 font-medium">({calculateDuration(leave.startDate, leave.endDate)})</span>
                        </p>
                      </li>
                    );
                  })}
                </ul>
              )}
            </CardContent>
             {upcomingApprovedLeaves.length > ITEMS_PER_PAGE_UPCOMING && (
                <CardFooter className="flex justify-between pt-4 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setUpcomingLeavesPage(prev => Math.max(0, prev - 1))}
                    disabled={upcomingLeavesPage === 0}
                  >
                    <ChevronLeft className="mr-1 h-4 w-4" /> Previous
                  </Button>
                  <span className="text-sm text-muted-foreground">
                    Page {upcomingLeavesPage + 1} of {Math.ceil(upcomingApprovedLeaves.length / ITEMS_PER_PAGE_UPCOMING)}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setUpcomingLeavesPage(prev => prev + 1)}
                    disabled={(upcomingLeavesPage + 1) * ITEMS_PER_PAGE_UPCOMING >= upcomingApprovedLeaves.length}
                  >
                    Next <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardFooter>
              )}
          </Card>
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center text-primary">
                <HelpCircle className="mr-2 h-5 w-5" />
                Legend
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center">
                <Gift className="h-5 w-5 text-red-500 dark:text-red-400 mr-2" />
                <span className="text-sm">Company Holiday</span>
              </div>
              <div className="flex items-center">
                <Circle className="h-4 w-4 text-green-500 dark:text-green-400 fill-current mr-2.5 ml-0.5" /> 
                <span className="text-sm">Approved Leave</span>
              </div>
              <div className="flex items-center">
                <CalendarIcon className="h-5 w-5 text-muted-foreground mr-2" />
                <span className="text-sm">Weekend / Regular Day</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {renderLeaveListCard(
          rejectedLeaves,
          loadingRejectedLeaves,
          "Rejected Requests",
          "Recently rejected leave requests.",
          "No rejected leave requests found.",
          AlertCircle,
          "bg-red-500"
        )}
        {renderLeaveListCard(
          pendingLeaves,
          loadingPendingLeaves,
          "Pending Approvals",
          "Leave requests awaiting review.",
          "No pending leave approvals.",
          Clock, 
          "bg-yellow-500"
        )}
        {renderLeaveListCard(
          upcomingApprovedLeaves, 
          loadingUpcomingLeaves,
          "Approved Leaves",
          "Recently approved and upcoming leaves.",
          "No approved leaves to show here.",
          ListChecks,
          "bg-green-500"
        )}
      </div>
    </div>
  );
}
