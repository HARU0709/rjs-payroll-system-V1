
'use client';

import { useState, useEffect, useMemo, type FormEvent } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { PageHeader } from '@/components/shared/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { DatePicker } from '@/components/ui/date-picker';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2, Landmark, Coins, Gift, HeartHandshake, PlusCircle, Save, XCircle, Trash2, ShieldCheck, MoreHorizontal, AlertTriangle, Edit, SlidersHorizontal, Users } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/firebase';
import { collection, onSnapshot, query, orderBy, doc, addDoc, updateDoc, deleteDoc, getDocs, where, writeBatch, getDoc, setDoc } from 'firebase/firestore';
import type { Employee, Loan, Benefit, BenefitType, Payslip, ThirteenthMonthPay } from '@/types';
import { format, parseISO, getYear, startOfYear, endOfYear } from 'date-fns';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';

// Zod Schemas
const numberPreprocess = (val: unknown) => (val === "" || val === undefined || val === null || Number.isNaN(parseFloat(String(val))) ? undefined : parseFloat(String(val)));

const loanFormSchema = z.object({
  employeeId: z.string().min(1, "Employee is required."),
  loanType: z.string().min(2, "Loan type is required."),
  totalAmount: z.preprocess(numberPreprocess, z.number().positive("Amount must be positive.")),
  monthlyDeduction: z.preprocess(numberPreprocess, z.number().positive("Deduction must be positive.")),
  startDate: z.date({ required_error: "Start date is required." }),
  notes: z.string().optional(),
});
type LoanFormValues = z.infer<typeof loanFormSchema>;

const benefitFormSchema = z.object({
  employeeId: z.string().min(1, "Employee is required."),
  benefitType: z.string().min(1, "Benefit type is required."),
  provider: z.string().min(2, "Provider is required."),
  policyNumber: z.string().optional(),
  monthlyContribution: z.preprocess(numberPreprocess, z.number().min(0, "Contribution must be non-negative.")),
  notes: z.string().optional(),
});
type BenefitFormValues = z.infer<typeof benefitFormSchema>;

const formatCurrency = (amount: number) => new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount);

// Main Component
export default function FinancialsPage() {
  const { toast } = useToast();
  const { employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';

  const [activeTab, setActiveTab] = useState('loans');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loadingEmployees, setLoadingEmployees] = useState(true);

  // Loans State
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loadingLoans, setLoadingLoans] = useState(true);
  const [isLoanDialogOpen, setIsLoanDialogOpen] = useState(false);
  const [loanToEdit, setLoanToEdit] = useState<Loan | null>(null);
  
  // Benefits State
  const [benefits, setBenefits] = useState<Benefit[]>([]);
  const [loadingBenefits, setLoadingBenefits] = useState(true);
  const [isBenefitDialogOpen, setIsBenefitDialogOpen] = useState(false);
  const [benefitToEdit, setBenefitToEdit] = useState<Benefit | null>(null);
  const [benefitTypes, setBenefitTypes] = useState<BenefitType[]>([]);
  const [loadingBenefitTypes, setLoadingBenefitTypes] = useState(true);
  const [isManageBenefitTypesDialogOpen, setIsManageBenefitTypesDialogOpen] = useState(false);
  const [newBenefitTypeName, setNewBenefitTypeName] = useState('');
  const [isSubmittingNewBenefitType, setIsSubmittingNewBenefitType] = useState(false);
  const [benefitTypeToEditDialog, setBenefitTypeToEditDialog] = useState<BenefitType | null>(null);
  const [editBenefitTypeName, setEditBenefitTypeName] = useState('');
  const [isSubmittingBenefitTypeEdit, setIsSubmittingBenefitTypeEdit] = useState(false);
  const [benefitTypeToDeleteDialog, setBenefitTypeToDeleteDialog] = useState<BenefitType | null>(null);
  const [isSubmittingBenefitTypeDelete, setIsSubmittingBenefitTypeDelete] = useState(false);
  
  // 13th Month Pay State
  const [thirteenthMonthPays, setThirteenthMonthPay] = useState<ThirteenthMonthPay[]>([]);
  const [loading13thMonth, setLoading13thMonth] = useState(true);
  const [calculationYear, setCalculationYear] = useState<number>(getYear(new Date()));
  const [isCalculating13th, setIsCalculating13th] = useState(false);
  const [is13thMonthOverwriteDialogOpen, setIs13thMonthOverwriteDialogOpen] = useState(false);
  const [selected13thMonthPayIds, setSelected13thMonthPayIds] = useState<string[]>([]);
  const [isBulkDelete13thMonthDialogOpen, setIsBulkDelete13thMonthDialogOpen] = useState(false);

  // Common Dialog State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ id: string; name: string; type: 'loan' | 'benefit' } | null>(null);

  const loanForm = useForm<LoanFormValues>({ resolver: zodResolver(loanFormSchema) });
  const benefitForm = useForm<BenefitFormValues>({ resolver: zodResolver(benefitFormSchema) });

  useEffect(() => {
    if (authLoading || !isAdmin) {
      setLoadingEmployees(false);
      setLoadingLoans(false);
      setLoadingBenefits(false);
      setLoadingBenefitTypes(false);
      setLoading13thMonth(false);
      return;
    }
    
    // Fetch Employees
    const qEmployees = query(collection(db, "employees"));
    const unsubEmployees = onSnapshot(qEmployees, (snapshot) => {
      let fetchedEmployees = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee)).filter(e => e.employeeId !== 'ADMIN');
      fetchedEmployees.sort((a,b) => a.name.localeCompare(b.name));
      setEmployees(fetchedEmployees);
      setLoadingEmployees(false);
    }, (error) => {
      console.error("Error fetching employees:", error);
      toast({ title: 'Error fetching employees', description: error.message, variant: 'destructive' });
      setLoadingEmployees(false);
    });

    // Fetch Loans
    const qLoans = query(collection(db, "loans"));
    const unsubLoans = onSnapshot(qLoans, (snapshot) => {
      let loansData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Loan));
      loansData.sort((a,b) => (b.startDate || "").localeCompare(a.startDate || ""));
      setLoans(loansData);
      setLoadingLoans(false);
    }, (error) => {
      console.error("Error fetching loans:", error);
      toast({ title: 'Error fetching loans', description: error.message, variant: 'destructive' });
      setLoadingLoans(false);
    });

    // Fetch Benefits
    const qBenefits = query(collection(db, "benefits"));
    const unsubBenefits = onSnapshot(qBenefits, (snapshot) => {
      let benefitsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Benefit));
      benefitsData.sort((a,b) => (a.employeeName || "").localeCompare(b.employeeName || ""));
      setBenefits(benefitsData);
      setLoadingBenefits(false);
    }, (error) => {
      console.error("Error fetching benefits:", error);
      toast({ title: 'Error fetching benefits', description: error.message, variant: 'destructive' });
      setLoadingBenefits(false);
    });
    
    // Fetch Benefit Types
    const qBenefitTypes = query(collection(db, "benefitTypes"));
    const unsubBenefitTypes = onSnapshot(qBenefitTypes, (snapshot) => {
      let benefitTypesData = snapshot.docs.map(doc => ({ id: doc.id, name: doc.data().name } as BenefitType));
      benefitTypesData.sort((a,b) => a.name.localeCompare(b.name));
      setBenefitTypes(benefitTypesData);
      setLoadingBenefitTypes(false);
    }, (error) => {
      console.error("Error fetching benefit types:", error);
      toast({ title: 'Error fetching benefit types', description: error.message, variant: 'destructive' });
      setLoadingBenefitTypes(false);
    });
    
    // Fetch 13th Month Pay
    const q13th = query(collection(db, "thirteenthMonthPays"));
    const unsub13th = onSnapshot(q13th, (snapshot) => {
        let paysData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ThirteenthMonthPay));
        paysData.sort((a, b) => (b.year || 0) - (a.year || 0));
        setThirteenthMonthPay(paysData);
        setLoading13thMonth(false);
    }, (error) => {
      console.error("Error fetching 13th month pay data:", error);
      toast({ title: 'Error fetching 13th month pay data', description: error.message, variant: 'destructive' });
      setLoading13thMonth(false);
    });

    return () => {
      unsubEmployees();
      unsubLoans();
      unsubBenefits();
      unsubBenefitTypes();
      unsub13th();
    };
  }, [isAdmin, authLoading, toast]);
  
  const financialsSummary = useMemo(() => {
    const activeLoans = loans.filter(l => l.status === 'Active');
    const totalLoanBalance = activeLoans.reduce((acc, loan) => acc + (loan.totalAmount - loan.amountPaid), 0);
    const totalBenefitContributions = benefits.reduce((acc, benefit) => acc + benefit.monthlyContribution, 0);

    const currentYear = getYear(new Date());
    const is13thMonthRun = thirteenthMonthPays.some(p => p.year === currentYear);

    return {
        activeLoanCount: activeLoans.length,
        totalLoanBalance,
        totalBenefitContributions,
        is13thMonthRun,
    };
  }, [loans, benefits, thirteenthMonthPays]);

  const handleOpenLoanDialog = (loan: Loan | null) => {
    setLoanToEdit(loan);
    if (loan) {
      loanForm.reset({
        employeeId: loan.employeeId,
        loanType: loan.loanType,
        totalAmount: loan.totalAmount,
        monthlyDeduction: loan.monthlyDeduction,
        startDate: parseISO(loan.startDate),
        notes: loan.notes || '',
      });
    } else {
      loanForm.reset({
        loanType: '',
        notes: '',
        employeeId: undefined,
        totalAmount: undefined,
        monthlyDeduction: undefined,
        startDate: undefined,
      });
    }
    setIsLoanDialogOpen(true);
  };
  
  const handleOpenBenefitDialog = (benefit: Benefit | null) => {
    setBenefitToEdit(benefit);
    if (benefit) {
      benefitForm.reset({
        employeeId: benefit.employeeId,
        benefitType: benefit.benefitType,
        provider: benefit.provider,
        policyNumber: benefit.policyNumber || '',
        monthlyContribution: benefit.monthlyContribution,
        notes: benefit.notes || '',
      });
    } else {
      benefitForm.reset({
        benefitType: '',
        provider: '',
        policyNumber: '',
        notes: '',
        employeeId: undefined,
        monthlyContribution: undefined,
      });
    }
    setIsBenefitDialogOpen(true);
  };
  
  const handleLoanSubmit = async (data: LoanFormValues) => {
    setIsSubmitting(true);
    const employee = employees.find(e => e.id === data.employeeId);
    if (!employee) {
        toast({ title: 'Error', description: 'Selected employee not found.', variant: 'destructive' });
        setIsSubmitting(false);
        return;
    }

    try {
      if (loanToEdit) {
        // Prepare update payload carefully to not overwrite existing progress
        const updatePayload = {
            employeeId: data.employeeId,
            employeeName: employee.name,
            loanType: data.loanType,
            totalAmount: data.totalAmount,
            monthlyDeduction: data.monthlyDeduction,
            startDate: format(data.startDate, 'yyyy-MM-dd'),
            notes: data.notes || '',
            // Do not reset amountPaid or status here, only what's on the form
        };
        await updateDoc(doc(db, 'loans', loanToEdit.id), updatePayload);
        toast({ title: 'Success', description: 'Loan updated successfully.' });
      } else {
         // This is for a new loan, so we set the initial progress fields
         const addPayload = {
          employeeId: data.employeeId,
          employeeName: employee.name,
          loanType: data.loanType,
          totalAmount: data.totalAmount,
          monthlyDeduction: data.monthlyDeduction,
          startDate: format(data.startDate, 'yyyy-MM-dd'),
          notes: data.notes || '',
          status: 'Active' as const, 
          amountPaid: 0,
        };
        await addDoc(collection(db, 'loans'), addPayload);
        toast({ title: 'Success', description: 'Loan granted successfully.' });
      }
      setIsLoanDialogOpen(false);
    } catch (error) {
      console.error('Error saving loan:', error);
      toast({ title: 'Error', description: `Failed to save loan: ${error instanceof Error ? error.message : 'Unknown error'}`, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleBenefitSubmit = async (data: BenefitFormValues) => {
    setIsSubmitting(true);
    const employee = employees.find(e => e.id === data.employeeId);
    if (!employee) {
        toast({ title: 'Error', description: 'Selected employee not found.', variant: 'destructive' });
        setIsSubmitting(false);
        return;
    }
    
    // Construct a clean payload
    const payload = {
      employeeId: data.employeeId,
      employeeName: employee.name,
      benefitType: data.benefitType,
      provider: data.provider,
      policyNumber: data.policyNumber || '',
      monthlyContribution: data.monthlyContribution,
      notes: data.notes || '',
    };
    
    try {
      if (benefitToEdit) {
        await updateDoc(doc(db, 'benefits', benefitToEdit.id), payload);
        toast({ title: 'Success', description: 'Benefit updated successfully.' });
      } else {
        await addDoc(collection(db, 'benefits'), payload);
        toast({ title: 'Success', description: 'Benefit added successfully.' });
      }
      setIsBenefitDialogOpen(false);
    } catch (error) {
      console.error('Error saving benefit:', error);
      toast({ title: 'Error', description: `Failed to save benefit: ${error instanceof Error ? error.message : 'Unknown error'}`, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleInitiate13thMonthCalculation = () => {
    const alreadyRun = thirteenthMonthPays.some(p => p.year === calculationYear);
    if (alreadyRun) {
      setIs13thMonthOverwriteDialogOpen(true);
    } else {
      execute13thMonthCalculation();
    }
  };

  const execute13thMonthCalculation = async () => {
    setIsCalculating13th(true);
    setIs13thMonthOverwriteDialogOpen(false); // Close dialog if it was open
    try {
        const yearStart = startOfYear(new Date(calculationYear, 0, 1));
        const yearEnd = endOfYear(new Date(calculationYear, 0, 1));
        
        const payslipsQuery = query(
            collection(db, 'payslips'),
            where('runDate', '>=', format(yearStart, 'yyyy-MM-dd')),
            where('runDate', '<=', format(yearEnd, 'yyyy-MM-dd'))
        );
        const payslipsSnap = await getDocs(payslipsQuery);
        const yearlyPayslips = payslipsSnap.docs.map(d => d.data() as Payslip);
        
        const salaryDataByEmployee: Record<string, { totalBasic: number; months: Set<string> }> = {};

        yearlyPayslips.forEach(p => {
            if (!salaryDataByEmployee[p.employeeId]) {
                salaryDataByEmployee[p.employeeId] = { totalBasic: 0, months: new Set() };
            }
            salaryDataByEmployee[p.employeeId].totalBasic += p.basicSalaryForPeriod;
            salaryDataByEmployee[p.employeeId].months.add(p.payrollMonth);
        });

        const batch = writeBatch(db);
        let processedCount = 0;

        for (const emp of employees) {
            if (emp.status === 'Active' && salaryDataByEmployee[emp.id]) {
                const data = salaryDataByEmployee[emp.id];
                const thirteenthMonthAmount = data.totalBasic / 12;

                const docId = `${emp.id}_${calculationYear}`;
                const docRef = doc(db, 'thirteenthMonthPays', docId);

                batch.set(docRef, {
                    employeeId: emp.id,
                    employeeName: emp.name,
                    year: calculationYear,
                    totalBasicSalaryForYear: data.totalBasic,
                    monthsIncluded: data.months.size,
                    amount: thirteenthMonthAmount,
                    runDate: format(new Date(), 'yyyy-MM-dd'),
                });
                processedCount++;
            }
        }

        await batch.commit();
        toast({ title: 'Success', description: `13th month pay for ${calculationYear} processed for ${processedCount} employees.` });

    } catch (error) {
        console.error("Error calculating 13th month pay:", error);
        toast({ title: 'Error', description: 'Failed to calculate 13th month pay.', variant: 'destructive' });
    } finally {
        setIsCalculating13th(false);
    }
  };

  const handleConfirmBulkDelete13thMonth = async () => {
    if (selected13thMonthPayIds.length === 0) return;
    setIsCalculating13th(true); // Reuse the loading state for the delete button
    try {
        const batch = writeBatch(db);
        selected13thMonthPayIds.forEach(id => {
            const docRef = doc(db, 'thirteenthMonthPays', id);
            batch.delete(docRef);
        });
        await batch.commit();
        toast({ title: 'Success', description: `${selected13thMonthPayIds.length} record(s) deleted.` });
        setSelected13thMonthPayIds([]); // Clear selection
    } catch (error) {
        console.error('Error during bulk deletion:', error);
        toast({ title: 'Error', description: 'Failed to delete selected records.', variant: 'destructive' });
    } finally {
        setIsCalculating13th(false);
        setIsBulkDelete13thMonthDialogOpen(false);
    }
  };

  const openDeleteDialog = (id: string, name: string, type: 'loan' | 'benefit') => {
    setItemToDelete({ id, name, type });
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!itemToDelete) return;
    setIsSubmitting(true);
    try {
      await deleteDoc(doc(db, `${itemToDelete.type}s`, itemToDelete.id));
      toast({ title: 'Success', description: `${itemToDelete.type.charAt(0).toUpperCase() + itemToDelete.type.slice(1)} deleted.` });
    } catch (error) {
      console.error(`Error deleting ${itemToDelete.type}:`, error);
      toast({ title: 'Error', description: `Failed to delete ${itemToDelete.type}.`, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
      setItemToDelete(null);
      setIsDeleteDialogOpen(false);
    }
  };
  
  const handleAddNewBenefitType = async () => {
    const name = newBenefitTypeName.trim();
    if (!name) {
      toast({ title: "Error", description: "Name cannot be empty.", variant: "destructive" });
      return;
    }
    setIsSubmittingNewBenefitType(true);
    try {
      await addDoc(collection(db, 'benefitTypes'), { name });
      toast({ title: "Success", description: `Benefit type "${name}" added.`, variant: 'success' });
      setNewBenefitTypeName('');
    } catch (err) {
      toast({ title: "Error", description: `Failed to add benefit type.`, variant: "destructive" });
    } finally {
      setIsSubmittingNewBenefitType(false);
    }
  };

  const handleOpenEditBenefitTypeDialog = (type: BenefitType) => {
    setBenefitTypeToEditDialog(type);
    setEditBenefitTypeName(type.name);
  };
  
  const handleSaveBenefitTypeEdit = async () => {
    if (!benefitTypeToEditDialog || !editBenefitTypeName.trim()) {
      toast({ title: "Error", description: "Name cannot be empty.", variant: "destructive" });
      return;
    }
    setIsSubmittingBenefitTypeEdit(true);
    const docRef = doc(db, 'benefitTypes', benefitTypeToEditDialog.id);
    try {
      await updateDoc(docRef, { name: editBenefitTypeName });
      toast({ title: "Success", description: "Benefit type updated.", variant: 'success' });
      setBenefitTypeToEditDialog(null);
    } catch (err) {
      toast({ title: "Error", description: "Failed to update benefit type.", variant: "destructive" });
    } finally {
      setIsSubmittingBenefitTypeEdit(false);
    }
  };

  const handleOpenDeleteBenefitTypeDialog = (type: BenefitType) => {
    setBenefitTypeToDeleteDialog(type);
  };

  const handleConfirmDeleteBenefitType = async () => {
    if (!benefitTypeToDeleteDialog) return;
    setIsSubmittingBenefitTypeDelete(true);
    const docRef = doc(db, 'benefitTypes', benefitTypeToDeleteDialog.id);
    try {
      await deleteDoc(docRef);
      toast({ title: "Success", description: "Benefit type deleted.", variant: 'success' });
      setBenefitTypeToDeleteDialog(null);
    } catch (err) {
      toast({ title: "Error", description: `Failed to delete benefit type.`, variant: "destructive" });
    } finally {
      setIsSubmittingBenefitTypeDelete(false);
    }
  };

  const displayed13thMonthPays = useMemo(() => {
    return thirteenthMonthPays;
  }, [thirteenthMonthPays]);

  const isAll13thMonthSelected = displayed13thMonthPays.length > 0 && selected13thMonthPayIds.length === displayed13thMonthPays.length;
  const isSome13thMonthSelected = selected13thMonthPayIds.length > 0 && !isAll13thMonthSelected;


  if (authLoading) return <div className="flex justify-center items-center h-64"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  if (!isAdmin) return (
    <Card><CardContent className="p-8 text-center"><AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" /><CardTitle>Access Denied</CardTitle><CardDescription>You do not have permission to view this page.</CardDescription></CardContent></Card>
  );

  return (
    <>
      <PageHeader icon={<Landmark className="h-7 w-7 text-primary" />} title="Financial Management" description="Manage employee loans, benefits, and statutory pay calculations." />
      
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
            <div className="p-2 bg-blue-100 rounded-full"><Users className="h-5 w-5 text-blue-500" /></div>
          </CardHeader>
          <CardContent>
            {loadingLoans ? <Skeleton className="h-8 w-1/2" /> : (
              <div className="text-2xl font-bold">{financialsSummary.activeLoanCount}</div>
            )}
            <p className="text-xs text-muted-foreground">employees with active loans</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Loan Balance</CardTitle>
            <div className="p-2 bg-indigo-100 rounded-full"><Landmark className="h-5 w-5 text-indigo-500" /></div>
          </CardHeader>
          <CardContent>
            {loadingLoans ? <Skeleton className="h-8 w-3/4" /> : (
              <div className="text-2xl font-bold">{formatCurrency(financialsSummary.totalLoanBalance)}</div>
            )}
            <p className="text-xs text-muted-foreground">Total amount currently owed</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Benefit Costs</CardTitle>
            <div className="p-2 bg-green-100 rounded-full"><HeartHandshake className="h-5 w-5 text-green-500" /></div>
          </CardHeader>
          <CardContent>
            {loadingBenefits ? <Skeleton className="h-8 w-3/4" /> : (
              <div className="text-2xl font-bold">{formatCurrency(financialsSummary.totalBenefitContributions)}</div>
            )}
            <p className="text-xs text-muted-foreground">Total employee contributions per month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">13th Month Pay Status</CardTitle>
            <div className="p-2 bg-yellow-100 rounded-full"><Gift className="h-5 w-5 text-yellow-600" /></div>
          </CardHeader>
          <CardContent>
            {loading13thMonth ? <Skeleton className="h-8 w-1/2" /> : (
              <div className={`text-2xl font-bold ${financialsSummary.is13thMonthRun ? 'text-green-600' : 'text-amber-600'}`}>
                {financialsSummary.is13thMonthRun ? 'Completed' : 'Pending'}
              </div>
            )}
            <p className="text-xs text-muted-foreground">for current year ({getYear(new Date())})</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="loans"><Coins className="mr-2 h-4 w-4" />Loan Management</TabsTrigger>
          <TabsTrigger value="benefits"><HeartHandshake className="mr-2 h-4 w-4" />Benefits</TabsTrigger>
          <TabsTrigger value="13th-month"><Gift className="mr-2 h-4 w-4" />13th Month Pay</TabsTrigger>
        </TabsList>

        <TabsContent value="loans" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div><CardTitle>Employee Loans</CardTitle><CardDescription>Track and manage all employee loans.</CardDescription></div>
                <Button onClick={() => handleOpenLoanDialog(null)}><PlusCircle className="mr-2 h-4 w-4" /> Grant New Loan</Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Type</TableHead><TableHead>Total</TableHead><TableHead>Paid</TableHead><TableHead>Remaining</TableHead><TableHead>Monthly Deduction</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {loadingLoans ? <TableRow><TableCell colSpan={8} className="text-center"><Loader2 className="mx-auto my-4 h-6 w-6 animate-spin" /></TableCell></TableRow>
                    : loans.map(loan => (
                      <TableRow key={loan.id}>
                        <TableCell>{loan.employeeName}</TableCell>
                        <TableCell>{loan.loanType}</TableCell>
                        <TableCell>{formatCurrency(loan.totalAmount)}</TableCell>
                        <TableCell>{formatCurrency(loan.amountPaid)}</TableCell>
                        <TableCell>{formatCurrency(loan.totalAmount - loan.amountPaid)}</TableCell>
                        <TableCell>{formatCurrency(loan.monthlyDeduction)}</TableCell>
                        <TableCell><Badge variant={loan.status === 'Active' ? 'destructive' : 'default'}>{loan.status}</Badge></TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenLoanDialog(loan)}><Edit className="h-4 w-4 text-primary" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => openDeleteDialog(loan.id, loan.loanType, 'loan')}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="benefits" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div><CardTitle>Employee Benefits</CardTitle><CardDescription>Manage HMO, insurance, and other employee benefits.</CardDescription></div>
                <div className='flex items-center gap-2'>
                  <Button variant="outline" onClick={() => setIsManageBenefitTypesDialogOpen(true)}>
                    <SlidersHorizontal className="mr-2 h-4 w-4" /> Manage Types
                  </Button>
                  <Button onClick={() => handleOpenBenefitDialog(null)}><PlusCircle className="mr-2 h-4 w-4" /> Add Benefit</Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Type</TableHead><TableHead>Provider</TableHead><TableHead>Policy Number</TableHead><TableHead>Monthly Contribution</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {loadingBenefits ? <TableRow><TableCell colSpan={6} className="text-center"><Loader2 className="mx-auto my-4 h-6 w-6 animate-spin" /></TableCell></TableRow>
                    : benefits.map(benefit => (
                      <TableRow key={benefit.id}>
                        <TableCell>{benefit.employeeName}</TableCell>
                        <TableCell>{benefit.benefitType}</TableCell>
                        <TableCell>{benefit.provider}</TableCell>
                        <TableCell>{benefit.policyNumber || 'N/A'}</TableCell>
                        <TableCell>{formatCurrency(benefit.monthlyContribution)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenBenefitDialog(benefit)}><Edit className="h-4 w-4 text-primary" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => openDeleteDialog(benefit.id, benefit.benefitType, 'benefit')}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="13th-month" className="mt-4">
          <Card>
            <CardHeader>
                <div className="flex justify-between items-center">
                    <div><CardTitle>13th Month Pay</CardTitle><CardDescription>Calculate and process the 13th month pay for eligible employees.</CardDescription></div>
                    <div className="flex items-center gap-2">
                        <Select value={String(calculationYear)} onValueChange={(val) => setCalculationYear(Number(val))}>
                            <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                            <SelectContent>{Array.from({ length: 5 }, (_, i) => getYear(new Date()) - i).map(year => <SelectItem key={year} value={String(year)}>{year}</SelectItem>)}</SelectContent>
                        </Select>
                        <Button onClick={handleInitiate13thMonthCalculation} disabled={isCalculating13th || loadingEmployees}>
                            {isCalculating13th ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <ShieldCheck className="mr-2 h-4 w-4" />}
                            Calculate & Run
                        </Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
               {selected13thMonthPayIds.length > 0 && (
                <div className="flex items-center justify-between p-3 mb-4 bg-muted/50 rounded-md">
                    <span className="text-sm font-medium">{selected13thMonthPayIds.length} item(s) selected</span>
                    <Button variant="destructive" size="sm" onClick={() => setIsBulkDelete13thMonthDialogOpen(true)}>
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete Selected
                    </Button>
                </div>
                )}
               <Table>
                <TableHeader><TableRow>
                    <TableHead>
                        <Checkbox
                            checked={isAll13thMonthSelected ? true : (isSome13thMonthSelected ? 'indeterminate' : false)}
                            onCheckedChange={(checked) => {
                                if (checked === true) {
                                    setSelected13thMonthPayIds(displayed13thMonthPays.map(p => p.id));
                                } else {
                                    setSelected13thMonthPayIds([]);
                                }
                            }}
                            disabled={isCalculating13th || displayed13thMonthPays.length === 0}
                        />
                    </TableHead>
                    <TableHead>Employee</TableHead><TableHead>Year</TableHead><TableHead>Total Basic Salary</TableHead><TableHead>Months Included</TableHead><TableHead>13th Month Pay Amount</TableHead><TableHead>Run Date</TableHead></TableRow></TableHeader>
                <TableBody>
                    {loading13thMonth ? <TableRow><TableCell colSpan={7} className="text-center"><Loader2 className="mx-auto my-4 h-6 w-6 animate-spin" /></TableCell></TableRow>
                    : displayed13thMonthPays.map(p => (
                        <TableRow key={p.id}>
                            <TableCell>
                                <Checkbox
                                    checked={selected13thMonthPayIds.includes(p.id)}
                                    onCheckedChange={(checked) => {
                                        if (checked) {
                                            setSelected13thMonthPayIds(prev => [...prev, p.id]);
                                        } else {
                                            setSelected13thMonthPayIds(prev => prev.filter(id => id !== p.id));
                                        }
                                    }}
                                    disabled={isCalculating13th}
                                />
                            </TableCell>
                            <TableCell>{p.employeeName}</TableCell>
                            <TableCell>{p.year}</TableCell>
                            <TableCell>{formatCurrency(p.totalBasicSalaryForYear)}</TableCell>
                            <TableCell>{p.monthsIncluded}</TableCell>
                            <TableCell className="font-semibold text-green-600 dark:text-green-400">{formatCurrency(p.amount)}</TableCell>
                            <TableCell>{p.runDate}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
               </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Loan Dialog */}
      <Dialog open={isLoanDialogOpen} onOpenChange={setIsLoanDialogOpen}>
        <DialogContent><DialogHeader><DialogTitle>{loanToEdit ? 'Edit' : 'Grant'} Loan</DialogTitle><DialogDescription>Fill in the details for the employee loan.</DialogDescription></DialogHeader>
          <Form {...loanForm}><form onSubmit={loanForm.handleSubmit(handleLoanSubmit)} className="space-y-4 py-2">
            <FormField control={loanForm.control} name="employeeId" render={({ field }) => (<FormItem><FormLabel>Employee</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={loadingEmployees}><FormControl><SelectTrigger><SelectValue placeholder="Select an employee" /></SelectTrigger></FormControl><SelectContent>{employees.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}</SelectContent></Select><FormMessage /></FormItem>)} />
            <FormField control={loanForm.control} name="loanType" render={({ field }) => (<FormItem><FormLabel>Loan Type</FormLabel><FormControl><Input {...field} placeholder="e.g., Company Loan, Salary Advance" /></FormControl><FormMessage /></FormItem>)} />
            <FormField control={loanForm.control} name="totalAmount" render={({ field }) => (<FormItem><FormLabel>Total Amount</FormLabel><FormControl><Input type="number" {...field} value={field.value ?? ''} onChange={e => field.onChange(parseFloat(e.target.value) || 0)}/></FormControl><FormMessage /></FormItem>)} />
            <FormField control={loanForm.control} name="monthlyDeduction" render={({ field }) => (<FormItem><FormLabel>Monthly Deduction</FormLabel><FormControl><Input type="number" {...field} value={field.value ?? ''} onChange={e => field.onChange(parseFloat(e.target.value) || 0)}/></FormControl><FormMessage /></FormItem>)} />
            <FormField control={loanForm.control} name="startDate" render={({ field }) => (<FormItem className="flex flex-col"><FormLabel>Deduction Start Date</FormLabel><DatePicker date={field.value} onDateChange={field.onChange} buttonClassName="w-full" /><FormMessage /></FormItem>)} />
            <FormField control={loanForm.control} name="notes" render={({ field }) => (<FormItem><FormLabel>Notes (Optional)</FormLabel><FormControl><Textarea {...field} value={field.value ?? ''} rows={3}/></FormControl><FormMessage /></FormItem>)} />
          <DialogFooter><DialogClose asChild><Button type="button" variant="outline" disabled={isSubmitting}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button></DialogClose><Button type="submit" disabled={isSubmitting}>{isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>} Save</Button></DialogFooter>
          </form></Form>
        </DialogContent>
      </Dialog>
      
      {/* Benefit Dialog */}
      <Dialog open={isBenefitDialogOpen} onOpenChange={setIsBenefitDialogOpen}>
        <DialogContent><DialogHeader><DialogTitle>{benefitToEdit ? 'Edit' : 'Add'} Benefit</DialogTitle><DialogDescription>Assign a new benefit to an employee.</DialogDescription></DialogHeader>
          <Form {...benefitForm}><form onSubmit={benefitForm.handleSubmit(handleBenefitSubmit)} className="space-y-4 py-2">
            <FormField control={benefitForm.control} name="employeeId" render={({ field }) => (<FormItem><FormLabel>Employee</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={loadingEmployees}><FormControl><SelectTrigger><SelectValue placeholder="Select an employee" /></SelectTrigger></FormControl><SelectContent>{employees.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}</SelectContent></Select><FormMessage /></FormItem>)} />
            <FormField control={benefitForm.control} name="benefitType" render={({ field }) => (<FormItem><FormLabel>Benefit Type</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={loadingBenefitTypes}><FormControl><SelectTrigger><SelectValue placeholder="Select type"/></SelectTrigger></FormControl><SelectContent>{benefitTypes.map(bt => (<SelectItem key={bt.id} value={bt.name}>{bt.name}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem>)} />
            <FormField control={benefitForm.control} name="provider" render={({ field }) => (<FormItem><FormLabel>Provider</FormLabel><FormControl><Input {...field} placeholder="e.g., Maxicare" /></FormControl><FormMessage /></FormItem>)} />
            <FormField control={benefitForm.control} name="policyNumber" render={({ field }) => (<FormItem><FormLabel>Policy Number (Optional)</FormLabel><FormControl><Input {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>)} />
            <FormField control={benefitForm.control} name="monthlyContribution" render={({ field }) => (<FormItem><FormLabel>Monthly Contribution (Employee Share)</FormLabel><FormControl><Input type="number" {...field} value={field.value ?? ''} onChange={e => field.onChange(parseFloat(e.target.value) || 0)}/></FormControl><FormMessage /></FormItem>)} />
            <FormField control={benefitForm.control} name="notes" render={({ field }) => (<FormItem><FormLabel>Notes (Optional)</FormLabel><FormControl><Textarea {...field} value={field.value ?? ''} rows={3}/></FormControl><FormMessage /></FormItem>)} />
          <DialogFooter><DialogClose asChild><Button type="button" variant="outline" disabled={isSubmitting}><XCircle className="mr-2 h-4 w-4"/>Cancel</Button></DialogClose><Button type="submit" disabled={isSubmitting}>{isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>} Save</Button></DialogFooter>
          </form></Form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Are you sure?</AlertDialogTitle><AlertDialogDescription>This will permanently delete the {itemToDelete?.type} "{itemToDelete?.name}". This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel onClick={() => setItemToDelete(null)}>Cancel</AlertDialogCancel><AlertDialogAction onClick={confirmDelete} disabled={isSubmitting} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">{isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4"/>}Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Manage Benefit Types Dialogs */}
      <Dialog open={isManageBenefitTypesDialogOpen} onOpenChange={setIsManageBenefitTypesDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Manage Benefit Types</DialogTitle>
            <DialogDescription>Add, edit, or delete the types of benefits available.</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Card>
              <CardContent className="pt-6">
                <ScrollArea className="h-60 pr-4">
                  <div className="space-y-2">
                    {loadingBenefitTypes ? <Loader2 className="mx-auto my-4 h-6 w-6 animate-spin" /> : benefitTypes.map(type => (
                      <div key={type.id} className="flex items-center justify-between p-2 rounded-md border">
                        <span>{type.name}</span>
                        <div className="space-x-1">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenEditBenefitTypeDialog(type)}>
                            <Edit className="h-4 w-4 text-primary" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleOpenDeleteBenefitTypeDialog(type)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                <div className="mt-4 space-y-2">
                  <Label htmlFor="new-benefit-type-name" className="font-semibold">Add New Benefit Type</Label>
                  <div className="flex gap-2">
                    <Input id="new-benefit-type-name" value={newBenefitTypeName} onChange={e => setNewBenefitTypeName(e.target.value)} placeholder="e.g., Dental, Vision" />
                    <Button onClick={handleAddNewBenefitType} disabled={isSubmittingNewBenefitType}>
                      {isSubmittingNewBenefitType ? <Loader2 className="animate-spin h-4 w-4" /> : <PlusCircle className="mr-2 h-4 w-4" />}
                      <span>Add</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button type="button" variant="outline"><XCircle className="mr-2 h-4 w-4"/><span>Close</span></Button></DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={!!benefitTypeToEditDialog} onOpenChange={(open) => !open && setBenefitTypeToEditDialog(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Benefit Type</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-4">
            <Label htmlFor="edit-benefit-type-name">Name</Label>
            <Input id="edit-benefit-type-name" value={editBenefitTypeName} onChange={e => setEditBenefitTypeName(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBenefitTypeToEditDialog(null)} disabled={isSubmittingBenefitTypeEdit}><XCircle className="mr-2 h-4 w-4"/><span>Cancel</span></Button>
            <Button onClick={handleSaveBenefitTypeEdit} disabled={isSubmittingBenefitTypeEdit}>
              {isSubmittingBenefitTypeEdit ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              <span>Save Changes</span>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={!!benefitTypeToDeleteDialog} onOpenChange={(open) => !open && setBenefitTypeToDeleteDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the benefit type "{benefitTypeToDeleteDialog?.name}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSubmittingBenefitTypeDelete} onClick={() => setBenefitTypeToDeleteDialog(null)}><XCircle className="mr-2 h-4 w-4"/><span>Cancel</span></AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDeleteBenefitType} className="bg-destructive text-destructive-foreground hover:bg-destructive/90" disabled={isSubmittingBenefitTypeDelete}>
              {isSubmittingBenefitTypeDelete ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
              <span>Delete</span>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 13th Month Overwrite Confirmation Dialog */}
      <AlertDialog open={is13thMonthOverwriteDialogOpen} onOpenChange={setIs13thMonthOverwriteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Overwrite Existing Payroll Data?</AlertDialogTitle>
            <AlertDialogDescription>
              The 13th month pay for {calculationYear} has already been run. Re-running the calculation will overwrite the existing records. This action cannot be undone. Are you sure you want to proceed?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isCalculating13th}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={execute13thMonthCalculation}
              disabled={isCalculating13th}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isCalculating13th ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <AlertTriangle className="mr-2 h-4 w-4" />}
              Yes, Overwrite
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 13th Month Bulk Delete Confirmation Dialog */}
      <AlertDialog open={isBulkDelete13thMonthDialogOpen} onOpenChange={setIsBulkDelete13thMonthDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the selected {selected13thMonthPayIds.length} record(s). This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isCalculating13th}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmBulkDelete13thMonth}
              disabled={isCalculating13th}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isCalculating13th ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4" />}
              Yes, Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
    

    

    
