
'use client';

import { useState, useEffect, useMemo, type FC } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { PageHeader } from '@/components/shared/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DatePicker } from '@/components/ui/date-picker';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  ChevronLeft,
  ChevronRight,
  PlusCircle,
  Upload,
  Settings as SettingsIcon,
  Edit3,
  AlertTriangle,
  Clock,
  CalendarDays,
  Users,
  Loader2,
  FileWarningIcon,
  Save,
  XCircle,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react';
import { db } from '@/lib/firebase';
import { collection, query, where, onSnapshot, doc, getDoc, setDoc, getDocs } from 'firebase/firestore';
import { 
  format, parseISO, isValid, parse, 
  addDays, subDays, 
  startOfDay, isAfter, 
  isWithinInterval, eachDayOfInterval, isWeekend,
  startOfWeek, endOfWeek, startOfMonth, endOfMonth,
  addWeeks, subWeeks, addMonths, subMonths
} from 'date-fns';
import type { Employee, AttendanceRecord, AttendanceSettings, LeaveRequest, Shift } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/auth-context';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const initialAttendanceSettings: AttendanceSettings = {
  expectedMorningIn: '08:00',
  expectedLunchOut: '12:00',
  expectedLunchIn: '13:00',
  expectedAfternoonOut: '17:00',
  requiredWorkHours: 8,
  lateGracePeriod: 15,
  earlyLeaveThreshold: 15,
  shifts: [],
};

// Helper to parse HH:mm string to minutes from midnight
const timeToMinutes = (timeStr: string | null | undefined): number | null => {
  if (!timeStr || !/^\d{2}:\d{2}$/.test(timeStr)) return null;
  const [hours, minutes] = timeStr.split(':').map(Number);
  return hours * 60 + minutes;
};

const formatMinutesToHHMM = (totalMinutes: number): string => {
  if (isNaN(totalMinutes) || totalMinutes < 0) return '-';
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
};

// Zod schema for manual entry form
const manualEntryFormSchema = z.object({
  employeeId: z.string().min(1, "Employee is required"),
  date: z.date({ required_error: "Date is required" }),
  morningIn: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)").optional().nullable().or(z.literal('')),
  lunchOut: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)").optional().nullable().or(z.literal('')),
  lunchIn: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)").optional().nullable().or(z.literal('')),
  afternoonOut: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)").optional().nullable().or(z.literal('')),
});
type ManualEntryFormValues = z.infer<typeof manualEntryFormSchema>;

const shiftSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Shift name is required."),
  startTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)"),
  endTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)"),
});

// Zod schema for attendance settings form
const attendanceSettingsFormSchema = z.object({
  expectedMorningIn: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)"),
  expectedLunchOut: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)"),
  expectedLunchIn: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)"),
  expectedAfternoonOut: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Invalid time (HH:MM)"),
  requiredWorkHours: z.number().min(0, "Cannot be negative").max(24, "Cannot exceed 24 hours"),
  lateGracePeriod: z.number().min(0, "Cannot be negative").max(120, "Too long"),
  earlyLeaveThreshold: z.number().min(0, "Cannot be negative").max(120, "Too long"),
  shifts: z.array(shiftSchema).optional(),
});
type AttendanceSettingsFormValues = z.infer<typeof attendanceSettingsFormSchema>;


// Helper function to convert array of objects to CSV string
function convertToCSV(data: Array<Record<string, any>>, headers: Record<string, string>): string {
  const headerRow = Object.values(headers).join(',');
  const dataRows = data.map(row => {
    return Object.keys(headers).map(key => {
      let cellValue = row[key] === undefined || row[key] === null ? '' : String(row[key]);
      if (cellValue.includes(',') || cellValue.includes('\n') || cellValue.includes('"')) {
        cellValue = `"${cellValue.replace(/"/g, '""')}"`;
      }
      return cellValue;
    }).join(',');
  });
  return [headerRow, ...dataRows].join('\n');
}


export default function AttendancePage() {
  const { toast } = useToast();
  const { user, employeeProfile, loading: authLoading } = useAuth();
  const isAdmin = employeeProfile?.permissionRole === 'Administrator';

  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewType, setViewType] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [attendanceSettings, setAttendanceSettings] = useState<AttendanceSettings>(initialAttendanceSettings);
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([]);
  const [selectedEmployeeFilter, setSelectedEmployeeFilter] = useState<string>('all');
  const [loadingEmployees, setLoadingEmployees] = useState(true);
  const [loadingRecords, setLoadingRecords] = useState(true);
  const [loadingSettings, setLoadingSettings] = useState(true);
  const [loadingLeaves, setLoadingLeaves] = useState(true);

  // State for Add Manual Entry Dialog
  const [isAddManualEntryDialogOpen, setIsAddManualEntryDialogOpen] = useState(false);
  const [selectedEmployeeForManualEntry, setSelectedEmployeeForManualEntry] = useState<string>('');
  const [selectedDateForManualEntry, setSelectedDateForManualEntry] = useState<Date | undefined>(new Date());
  const [isSubmittingManualEntry, setIsSubmittingManualEntry] = useState(false);

  // State for Attendance Settings Dialog
  const [isAttendanceSettingsDialogOpen, setIsAttendanceSettingsDialogOpen] = useState(false);
  const [isSubmittingSettings, setIsSubmittingSettings] = useState(false);
  const [currentShifts, setCurrentShifts] = useState<Shift[]>([]);
  const [newShiftName, setNewShiftName] = useState('');
  const [newShiftStartTime, setNewShiftStartTime] = useState('');
  const [newShiftEndTime, setNewShiftEndTime] = useState('');


  const formManualEntry = useForm<ManualEntryFormValues>({
    resolver: zodResolver(manualEntryFormSchema),
    defaultValues: {
      employeeId: '',
      date: new Date(),
      morningIn: '',
      lunchOut: '',
      lunchIn: '',
      afternoonOut: '',
    },
  });

  const formSettings = useForm<AttendanceSettingsFormValues>({
    resolver: zodResolver(attendanceSettingsFormSchema),
    defaultValues: initialAttendanceSettings,
  });

  const watchedExpectedTimes = useWatch({
    control: formSettings.control,
    name: ["expectedMorningIn", "expectedLunchOut", "expectedLunchIn", "expectedAfternoonOut"],
  });

  useEffect(() => {
    const [morningInStr, lunchOutStr, lunchInStr, afternoonOutStr] = watchedExpectedTimes;

    const morningInMin = timeToMinutes(morningInStr);
    const lunchOutMin = timeToMinutes(lunchOutStr);
    const lunchInMin = timeToMinutes(lunchInStr);
    const afternoonOutMin = timeToMinutes(afternoonOutStr);

    let totalWorkMinutes = 0;

    if (morningInMin !== null && lunchOutMin !== null && lunchOutMin > morningInMin) {
      totalWorkMinutes += (lunchOutMin - morningInMin);
    }
    if (lunchInMin !== null && afternoonOutMin !== null && afternoonOutMin > lunchInMin) {
      totalWorkMinutes += (afternoonOutMin - lunchInMin);
    }

    if (morningInMin !== null && afternoonOutMin !== null &&
        (lunchOutMin === null || lunchInMin === null || (lunchOutMin !== null && lunchInMin !== null && lunchOutMin >= lunchInMin)) &&
        totalWorkMinutes === 0 && afternoonOutMin > morningInMin) {
        // This case handles scenarios where there's no lunch break or lunch times are invalid
        // but morning in and afternoon out are valid.
        totalWorkMinutes = afternoonOutMin - morningInMin;
    }


    const calculatedHours = totalWorkMinutes > 0 ? parseFloat((totalWorkMinutes / 60).toFixed(2)) : 0;
    formSettings.setValue('requiredWorkHours', calculatedHours, { shouldValidate: true });

  }, [watchedExpectedTimes, formSettings]);


  useEffect(() => {
    setLoadingEmployees(true);
    const q = query(collection(db, 'employees'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedEmployees = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee));
      setEmployees(fetchedEmployees.filter(emp => emp.employeeId !== 'ADMIN'));
      setLoadingEmployees(false);
    }, (error) => {
      console.error("Error fetching employees:", error);
      toast({ title: "Error", description: "Could not fetch employees.", variant: "destructive" });
      setLoadingEmployees(false);
    });
    return () => unsubscribe();
  }, [toast]);

  useEffect(() => {
    setLoadingSettings(true);
    const settingsDocRef = doc(db, 'companySettings', 'attendance');
    const unsubscribe = onSnapshot(settingsDocRef, (docSnap) => {
      if (docSnap.exists()) {
        const settingsData = { ...initialAttendanceSettings, ...docSnap.data() } as AttendanceSettings;
        setAttendanceSettings(settingsData);
        formSettings.reset(settingsData);
        setCurrentShifts(settingsData.shifts || []);
      } else {
        setAttendanceSettings(initialAttendanceSettings);
        formSettings.reset(initialAttendanceSettings);
        setCurrentShifts([]);
        console.warn("Attendance settings not found in Firestore, using defaults.");
      }
      setLoadingSettings(false);
    }, (error) => {
      console.error("Error fetching attendance settings:", error);
      setAttendanceSettings(initialAttendanceSettings);
      formSettings.reset(initialAttendanceSettings);
      setCurrentShifts([]);
      toast({ title: "Warning", description: "Could not fetch attendance settings, using defaults.", variant: "default" });
      setLoadingSettings(false);
    });
    return () => unsubscribe();
  }, [toast, formSettings]);

  const dateRange = useMemo(() => {
    switch (viewType) {
      case 'weekly':
        return { start: startOfWeek(selectedDate, { weekStartsOn: 1 }), end: endOfWeek(selectedDate, { weekStartsOn: 1 }) };
      case 'monthly':
        return { start: startOfMonth(selectedDate), end: endOfMonth(selectedDate) };
      case 'daily':
      default:
        return { start: startOfDay(selectedDate), end: startOfDay(selectedDate) };
    }
  }, [selectedDate, viewType]);

  useEffect(() => {
    setLoadingRecords(true);
    const startDateStr = format(dateRange.start, 'yyyy-MM-dd');
    const endDateStr = format(dateRange.end, 'yyyy-MM-dd');
    
    // Using a range query. This requires a corresponding index in Firestore.
    // Firestore can auto-create single-field indexes, but for complex queries, manual setup might be needed.
    // This query is on a single field ('date'), so it should work without a custom composite index.
    const q = query(
      collection(db, 'attendanceRecords'), 
      where('date', '>=', startDateStr),
      where('date', '<=', endDateStr)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedRecords = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AttendanceRecord));
      setAttendanceRecords(fetchedRecords);
      setLoadingRecords(false);
    }, (error) => {
      console.error("Error fetching attendance records:", error);
      toast({ title: "Error", description: `Could not fetch attendance records for the selected period.`, variant: "destructive" });
      setLoadingRecords(false);
    });
    return () => unsubscribe();
  }, [dateRange, toast]);
  
  useEffect(() => {
    setLoadingLeaves(true);
    // Fetch all approved leaves once, filtering will be done in memoized calculations
    const q = query(collection(db, 'leaveRequests'), where('status', '==', 'Approved'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
        const fetchedLeaves = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LeaveRequest));
        setLeaveRequests(fetchedLeaves);
        setLoadingLeaves(false);
    }, (error) => {
        console.error("Error fetching leave requests:", error);
        toast({ title: "Error", description: "Could not fetch leave requests.", variant: "destructive" });
        setLoadingLeaves(false);
    });
    return () => unsubscribe();
  }, [toast]);

  useEffect(() => {
    const fetchExistingRecord = async () => {
      if (!selectedEmployeeForManualEntry || !selectedDateForManualEntry) {
        formManualEntry.reset({
          ...formManualEntry.getValues(),
          morningIn: '', lunchOut: '', lunchIn: '', afternoonOut: ''
        });
        return;
      }
      const dateString = format(selectedDateForManualEntry, 'yyyy-MM-dd');
      const docId = `${selectedEmployeeForManualEntry}_${dateString}`;
      const docRef = doc(db, 'attendanceRecords', docId);

      try {
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const record = docSnap.data() as Omit<AttendanceRecord, 'id'>;
          formManualEntry.reset({
            employeeId: selectedEmployeeForManualEntry,
            date: selectedDateForManualEntry,
            morningIn: record.morningIn || '',
            lunchOut: record.lunchOut || '',
            lunchIn: record.lunchIn || '',
            afternoonOut: record.afternoonOut || '',
          });
        } else {
          formManualEntry.reset({
            employeeId: selectedEmployeeForManualEntry,
            date: selectedDateForManualEntry,
            morningIn: '', lunchOut: '', lunchIn: '', afternoonOut: '',
          });
        }
      } catch (error) {
        console.error("Error fetching existing record for manual entry:", error);
        toast({ title: "Error", description: "Could not fetch existing record for editing.", variant: "destructive" });
      }
    };

    if (isAddManualEntryDialogOpen) {
      if (selectedEmployeeForManualEntry && selectedDateForManualEntry) {
        formManualEntry.setValue('employeeId', selectedEmployeeForManualEntry);
        formManualEntry.setValue('date', selectedDateForManualEntry);
      }
      fetchExistingRecord();
    }
  }, [isAddManualEntryDialogOpen, selectedEmployeeForManualEntry, selectedDateForManualEntry, formManualEntry, toast]);


  const handleDateChange = (date?: Date) => {
    if (date) setSelectedDate(date);
  };
  
  const handlePeriodChange = (direction: 'prev' | 'next') => {
    const sign = direction === 'prev' ? -1 : 1;
    switch (viewType) {
      case 'weekly':
        setSelectedDate(addWeeks(selectedDate, sign));
        break;
      case 'monthly':
        setSelectedDate(addMonths(selectedDate, sign));
        break;
      case 'daily':
      default:
        setSelectedDate(addDays(selectedDate, sign));
        break;
    }
  };

  const displayedEmployees = useMemo(() => {
    if (isAdmin) {
      if (selectedEmployeeFilter === 'all') {
        return employees;
      }
      return employees.filter(emp => emp.id === selectedEmployeeFilter);
    }
    // If not admin, only show the logged-in user
    if (user) {
      return employees.filter(emp => emp.id === user.uid);
    }
    return [];
  }, [employees, selectedEmployeeFilter, isAdmin, user]);

  const processedDailyData = useMemo(() => {
    if(viewType !== 'daily') return [];
    return displayedEmployees.map(emp => {
      const onLeaveRequest = leaveRequests.find(lr => {
        if (lr.employeeId !== emp.id) return false;
        try {
            const leaveStartDate = parseISO(lr.startDate);
            const leaveEndDate = parseISO(lr.endDate);
            // Use startOfDay to make interval inclusive
            return isWithinInterval(startOfDay(selectedDate), {
                start: startOfDay(leaveStartDate),
                end: startOfDay(leaveEndDate),
            });
        } catch (e) {
            return false;
        }
      });

      const shift = attendanceSettings.shifts?.find(s => s.id === emp.shiftId);
      const expectedMorningIn = shift?.startTime || attendanceSettings.expectedMorningIn;
      const expectedAfternoonOut = shift?.endTime || attendanceSettings.expectedAfternoonOut;
      const requiredWorkHours = shift ? ((timeToMinutes(shift.endTime) || 0) - (timeToMinutes(shift.startTime) || 0)) / 60 : attendanceSettings.requiredWorkHours;
      
      if (onLeaveRequest) {
        if (onLeaveRequest.leaveType === 'Unpaid') {
          return {
            employeeName: emp.name,
            employeeId: emp.id,
            date: format(selectedDate, 'E, MMM dd, yyyy'),
            morningIn: '-',
            lunchOut: '-',
            lunchIn: '-',
            afternoonOut: '-',
            workHours: '-',
            status: 'Absent (Unpaid Leave)',
            statusVariant: 'destructive',
            isOnLeave: true, // Disables editing
          };
        } else {
          const workHoursFormatted = formatMinutesToHHMM(requiredWorkHours * 60);
          return {
            employeeName: emp.name,
            employeeId: emp.id,
            date: format(selectedDate, 'E, MMM dd, yyyy'),
            morningIn: expectedMorningIn,
            lunchOut: '-',
            lunchIn: '-',
            afternoonOut: expectedAfternoonOut,
            workHours: workHoursFormatted,
            status: `On Leave (${onLeaveRequest.leaveType})`,
            statusVariant: 'secondary',
            isOnLeave: true,
          };
        }
      }

      const record = attendanceRecords.find(r => r.employeeId === emp.id);
      let workMinutes = 0;
      if (record) {
        const morningInMin = timeToMinutes(record.morningIn);
        const lunchOutMin = timeToMinutes(record.lunchOut);
        const lunchInMin = timeToMinutes(record.lunchIn);
        const afternoonOutMin = timeToMinutes(record.afternoonOut);

        if (morningInMin !== null && afternoonOutMin !== null) {
          if (lunchOutMin !== null && lunchInMin !== null) {
            if (lunchOutMin > morningInMin && afternoonOutMin > lunchInMin && lunchInMin > lunchOutMin) {
              workMinutes = (lunchOutMin - morningInMin) + (afternoonOutMin - lunchInMin);
            }
          } else if (lunchOutMin === null && lunchInMin === null) {
             if (afternoonOutMin > morningInMin) {
                workMinutes = afternoonOutMin - morningInMin;
             }
          }
          else if (workMinutes === 0) {
             if (morningInMin !== null && lunchOutMin !== null && lunchOutMin > morningInMin) {
                workMinutes += (lunchOutMin - morningInMin);
             }
             if (lunchInMin !== null && afternoonOutMin !== null && afternoonOutMin > lunchInMin) {
                workMinutes += (afternoonOutMin - lunchInMin);
             }
          }
        }
      }
      const workHoursFormatted = workMinutes > 0 ? formatMinutesToHHMM(workMinutes) : '-';

      let statusText = '-';
      let statusVariant: 'default' | 'secondary' | 'destructive' | 'outline' = 'outline';

      const dayOfWeek = selectedDate.getDay();
      const isWeekendDay = dayOfWeek === 0 || dayOfWeek === 6;

      if (record) {
        const requiredWorkMinutes = requiredWorkHours * 60;
        const issues: string[] = [];

        // Check for Late
        const expectedMorningInMin = timeToMinutes(expectedMorningIn);
        const actualMorningInMin = timeToMinutes(record.morningIn || '');
        if (expectedMorningInMin !== null && actualMorningInMin !== null && actualMorningInMin > (expectedMorningInMin + attendanceSettings.lateGracePeriod)) {
          issues.push('Late');
        }

        // Check for Early Leave
        const expectedAfternoonOutMin = timeToMinutes(expectedAfternoonOut);
        const actualAfternoonOutMin = timeToMinutes(record.afternoonOut || '');
        if (expectedAfternoonOutMin !== null && actualAfternoonOutMin !== null && actualAfternoonOutMin > 0 && actualAfternoonOutMin < (expectedAfternoonOutMin - attendanceSettings.earlyLeaveThreshold)) {
          issues.push('Early Leave');
        }

        if (workMinutes > 0 && workMinutes < requiredWorkMinutes) {
          issues.push('Undertime');
        }
        
        if (issues.length > 0) {
          statusText = issues.join(', ');
          statusVariant = 'destructive';
        } else if (workMinutes >= requiredWorkMinutes) {
          statusText = 'Present';
          statusVariant = 'default';
        } else {
          statusText = 'Incomplete';
          statusVariant = 'outline';
        }
      } else {
        const today = new Date();
        const isFutureDate = isAfter(startOfDay(selectedDate), startOfDay(today));
        
        if (isFutureDate) {
            statusText = '-';
            statusVariant = 'outline';
        } else if (!isWeekendDay) {
          statusText = 'Absent';
          statusVariant = 'destructive';
        } else {
          statusText = 'Weekend';
          statusVariant = 'secondary';
        }
      }

      return {
        employeeName: emp.name,
        employeeId: emp.id,
        date: format(selectedDate, 'E, MMM dd, yyyy'),
        morningIn: record?.morningIn || '-',
        lunchOut: record?.lunchOut || '-',
        lunchIn: record?.lunchIn || '-',
        afternoonOut: record?.afternoonOut || '-',
        workHours: workHoursFormatted,
        status: statusText,
        statusVariant: statusVariant,
        isOnLeave: false,
      };
    });
  }, [displayedEmployees, attendanceRecords, leaveRequests, selectedDate, attendanceSettings, viewType]);

  const processedSummaryData = useMemo(() => {
    if (viewType === 'daily') return [];

    return displayedEmployees.map(emp => {
      let presentDays = 0, absentDays = 0, leaveDays = 0, totalWorkMinutes = 0, lateCount = 0, undertimeCount = 0;
      const daysInPeriod = eachDayOfInterval(dateRange);
      const today = startOfDay(new Date());

      const shift = attendanceSettings.shifts?.find(s => s.id === emp.shiftId);
      const expectedMorningIn = shift?.startTime || attendanceSettings.expectedMorningIn;
      const requiredWorkHours = shift ? ((timeToMinutes(shift.endTime) || 0) - (timeToMinutes(shift.startTime) || 0)) / 60 : attendanceSettings.requiredWorkHours;

      for(const day of daysInPeriod) {
        if (isWeekend(day) || day > today) continue;

        const onLeaveRequest = leaveRequests.find(lr => 
          lr.employeeId === emp.id && 
          isWithinInterval(day, { start: parseISO(lr.startDate), end: parseISO(lr.endDate) })
        );

        if (onLeaveRequest) {
          if (onLeaveRequest.leaveType !== 'Unpaid') {
            leaveDays++;
          } else {
            absentDays++;
          }
          continue;
        }
        
        const record = attendanceRecords.find(r => r.employeeId === emp.id && r.date === format(day, 'yyyy-MM-dd'));

        if (record) {
          presentDays++;
          let dailyWorkMinutes = 0;
          const morningInMin = timeToMinutes(record.morningIn);
          const lunchOutMin = timeToMinutes(record.lunchOut);
          const lunchInMin = timeToMinutes(record.lunchIn);
          const afternoonOutMin = timeToMinutes(record.afternoonOut);

          if (morningInMin !== null && afternoonOutMin !== null) {
            if (lunchOutMin !== null && lunchInMin !== null) {
              if (lunchOutMin > morningInMin && afternoonOutMin > lunchInMin && lunchInMin > lunchOutMin) {
                dailyWorkMinutes = (lunchOutMin - morningInMin) + (afternoonOutMin - lunchInMin);
              }
            } else if (afternoonOutMin > morningInMin) {
              dailyWorkMinutes = afternoonOutMin - morningInMin;
            }
          }
          totalWorkMinutes += dailyWorkMinutes;
          
          if (viewType === 'monthly') {
            const expectedMorningInMin = timeToMinutes(expectedMorningIn);
            if(expectedMorningInMin && morningInMin && morningInMin > (expectedMorningInMin + attendanceSettings.lateGracePeriod)) {
                lateCount++;
            }
            if(dailyWorkMinutes > 0 && dailyWorkMinutes < (requiredWorkHours * 60)) {
                undertimeCount++;
            }
          }
        } else {
          absentDays++;
        }
      }

      return {
        employeeId: emp.id,
        employeeName: emp.name,
        presentDays,
        absentDays,
        leaveDays,
        lateCount,
        undertimeCount,
        totalHours: totalWorkMinutes > 0 ? formatMinutesToHHMM(totalWorkMinutes) : '-',
        avgHours: presentDays > 0 ? formatMinutesToHHMM(totalWorkMinutes / presentDays) : '-'
      };
    });
  }, [viewType, displayedEmployees, attendanceRecords, leaveRequests, dateRange, attendanceSettings]);


  async function onSubmitManualEntry(data: ManualEntryFormValues) {
    setIsSubmittingManualEntry(true);
    const dateString = format(data.date, 'yyyy-MM-dd');
    const recordData: Omit<AttendanceRecord, 'id'> = {
      employeeId: data.employeeId,
      date: dateString,
      morningIn: data.morningIn || null,
      lunchOut: data.lunchOut || null,
      lunchIn: data.lunchIn || null,
      afternoonOut: data.afternoonOut || null,
    };

    const docId = `${data.employeeId}_${dateString}`;
    const docRef = doc(db, 'attendanceRecords', docId);

    try {
      await setDoc(docRef, recordData, { merge: true });
      toast({ title: 'Success', description: 'Attendance record saved.' });
      setIsAddManualEntryDialogOpen(false);
      formManualEntry.reset({
        employeeId: '',
        date: new Date(),
        morningIn: '',
        lunchOut: '',
        lunchIn: '',
        afternoonOut: ''
      });
      setSelectedEmployeeForManualEntry('');
      setSelectedDateForManualEntry(new Date());
    } catch (error) {
      console.error("Error saving manual attendance:", error);
      toast({
        title: "Error",
        description: `Failed to save attendance. ${error instanceof Error ? error.message : 'Please try again.'}`,
        variant: "destructive",
      });
    } finally {
      setIsSubmittingManualEntry(false);
    }
  }

  async function onSubmitSettings(data: AttendanceSettingsFormValues) {
    setIsSubmittingSettings(true);
    const settingsToSave: AttendanceSettings = {
      ...data,
      shifts: currentShifts, // Use the state for shifts
      requiredWorkHours: Number(data.requiredWorkHours),
      lateGracePeriod: Number(data.lateGracePeriod),
      earlyLeaveThreshold: Number(data.earlyLeaveThreshold),
    };

    const settingsDocRef = doc(db, 'companySettings', 'attendance');
    try {
      await setDoc(settingsDocRef, settingsToSave, { merge: true });
      toast({ title: 'Success', description: 'Attendance settings saved.' });
      setAttendanceSettings(settingsToSave);
      setIsAttendanceSettingsDialogOpen(false);
    } catch (error) {
      console.error("Error saving attendance settings:", error);
      toast({
        title: "Error",
        description: `Failed to save settings. ${error instanceof Error ? error.message : 'Please try again.'}`,
        variant: "destructive",
      });
    } finally {
      setIsSubmittingSettings(false);
    }
  }
  
  const handleAddNewShift = () => {
    if (!newShiftName.trim() || !newShiftStartTime || !newShiftEndTime) {
      toast({ title: "Error", description: "Please fill all shift fields.", variant: "destructive" });
      return;
    }
    const newShift: Shift = {
      id: `shift_${Date.now()}`,
      name: newShiftName,
      startTime: newShiftStartTime,
      endTime: newShiftEndTime,
    };
    setCurrentShifts(prev => [...prev, newShift]);
    setNewShiftName('');
    setNewShiftStartTime('');
    setNewShiftEndTime('');
  };

  const handleDeleteShift = (id: string) => {
    setCurrentShifts(prev => prev.filter(shift => shift.id !== id));
  };


  const handleExportCSV = () => {
    let dataToExport: Array<Record<string, any>> = [];
    let headers: Record<string, string> = {};
    let filenamePart = '';

    if (viewType === 'daily') {
        if (processedDailyData.length === 0) {
            toast({ title: "No Data", description: "There is no attendance data to export for the selected criteria.", variant: "default" });
            return;
        }
        headers = { date: 'Date', employeeName: 'Employee', morningIn: 'Morning In', lunchOut: 'Lunch Out', lunchIn: 'Lunch In', afternoonOut: 'Afternoon Out', workHours: 'Work Hours', status: 'Status' };
        dataToExport = processedDailyData;
        filenamePart = `daily_${format(selectedDate, 'yyyy-MM-dd')}`;

    } else { // weekly or monthly
        if (processedSummaryData.length === 0) {
            toast({ title: "No Data", description: "There is no attendance data to export for the selected criteria.", variant: "default" });
            return;
        }
        const baseHeaders = { employeeName: 'Employee', presentDays: 'Present', absentDays: 'Absent', leaveDays: 'On Leave', totalHours: 'Total Hours' };
        if (viewType === 'monthly') {
            headers = { ...baseHeaders, lateCount: 'Lates', undertimeCount: 'Undertime', avgHours: 'Avg Hours/Day' };
        } else { // weekly
            headers = { ...baseHeaders, avgHours: 'Avg Hours/Day' };
        }
        dataToExport = processedSummaryData;
        filenamePart = `${viewType}_${format(dateRange.start, 'yyyy-MM-dd')}_to_${format(dateRange.end, 'yyyy-MM-dd')}`;
    }

    const csvData = convertToCSV(dataToExport, headers);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `attendance_report_${filenamePart}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({ title: "Export Started", description: `Downloading attendance_report_${filenamePart}.csv` });
  };


  const isLoading = loadingEmployees || loadingRecords || loadingSettings || authLoading || loadingLeaves;

  const datePickerDisplay = useMemo(() => {
    switch(viewType) {
        case 'weekly': return `${format(dateRange.start, 'MMM dd')} - ${format(dateRange.end, 'MMM dd, yyyy')}`;
        case 'monthly': return format(selectedDate, 'MMMM yyyy');
        case 'daily':
        default: return format(selectedDate, 'PPP');
    }
  }, [selectedDate, viewType, dateRange]);


  return (
    <>
      <PageHeader
        icon={<Clock className="h-7 w-7 text-primary" />}
        title="Attendance Records"
        description={isAdmin ? "View attendance for a specific day. Admin can edit, add entries, or export data." : "View your personal daily attendance records."}
        actions={
          <div className="flex gap-2">
            {isAdmin && (
              <Button
                variant="outline"
                onClick={() => {
                  formManualEntry.reset({ employeeId: '', date: new Date(), morningIn: '', lunchOut: '', lunchIn: '', afternoonOut: '' });
                  setSelectedEmployeeForManualEntry('');
                  setSelectedDateForManualEntry(new Date());
                  setIsAddManualEntryDialogOpen(true);
                }}
                disabled={loadingEmployees}
              >
                <PlusCircle className="mr-2 h-4 w-4" /> Add Manual Entry
              </Button>
            )}
            <Button variant="outline" onClick={handleExportCSV} disabled={isLoading || (viewType === 'daily' ? processedDailyData.length === 0 : processedSummaryData.length === 0)}>
              <Upload className="mr-2 h-4 w-4" /> Export CSV
            </Button>
            {isAdmin && (
              <Button
                onClick={() => {
                  formSettings.reset({ ...attendanceSettings, shifts: currentShifts });
                  setIsAttendanceSettingsDialogOpen(true);
                }}
                disabled={loadingSettings}
              >
                <SlidersHorizontal className="mr-2 h-4 w-4" /> Configure Settings
              </Button>
            )}
          </div>
        }
      />
      <Card>
        <CardHeader>
          <div className="mb-6 rounded-lg border border-muted bg-muted/50 p-4 dark:bg-muted/30">
            {loadingSettings ? (
              <div className="flex items-center justify-around">
                  <Skeleton className="h-6 w-1/4" />
                  <Skeleton className="h-6 w-1/4" />
                  <Skeleton className="h-6 w-1/4" />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-around text-sm font-medium sm:flex-row">
                <div className="flex items-center gap-2 p-1 text-amber-700 dark:text-amber-400">
                  <AlertTriangle className="h-5 w-5" /> Default Morning In: {attendanceSettings.expectedMorningIn}
                </div>
                <div className="flex items-center gap-2 p-1 text-muted-foreground">
                  <Clock className="h-5 w-5" /> Default Afternoon Out: {attendanceSettings.expectedAfternoonOut}
                </div>
                <div className="flex items-center gap-2 p-1 text-primary">
                  <Clock className="h-5 w-5" /> Default Work Hours: {attendanceSettings.requiredWorkHours.toFixed(2)} hours/day
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-4 pt-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <DatePicker 
                date={selectedDate} 
                onDateChange={handleDateChange} 
                buttonClassName="w-[200px] sm:w-[240px]"
              />
              <Button variant="outline" size="icon" onClick={() => handlePeriodChange('prev')}><ChevronLeft className="h-4 w-4" /></Button>
              <Button variant="outline" size="icon" onClick={() => handlePeriodChange('next')}><ChevronRight className="h-4 w-4" /></Button>
            </div>
            <div className="flex w-full items-center gap-2 sm:w-auto">
              <Select value={viewType} onValueChange={(v) => setViewType(v as any)}>
                <SelectTrigger className="w-full sm:w-[130px]">
                  <span className="flex items-center">
                    <CalendarDays className="mr-2 h-4 w-4 text-muted-foreground" />
                    <SelectValue />
                  </span>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
              {isAdmin && (
                <Select value={selectedEmployeeFilter} onValueChange={setSelectedEmployeeFilter} disabled={loadingEmployees}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <span className="flex items-center">
                      <Users className="mr-2 h-4 w-4 text-muted-foreground" />
                      <SelectValue placeholder="Filter by Employee" />
                    </span>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Employees</SelectItem>
                    {employees.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <Table>
                <TableBody>
                    {[...Array(5)].map((_, i) => (
                      <TableRow key={i}>
                        <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16 mx-auto" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16 mx-auto" /></TableCell>
                        <TableCell><Skeleton className="h-4 w-16 mx-auto" /></TableCell>
                        <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                      </TableRow>
                    ))}
                </TableBody>
            </Table>
          ) : viewType === 'daily' ? (
            <Table>
                <TableHeader>
                <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Employee</TableHead>
                    <TableHead className="text-center">Morning In</TableHead>
                    <TableHead className="text-center">Lunch Out</TableHead>
                    <TableHead className="text-center">Lunch In</TableHead>
                    <TableHead className="text-center">Afternoon Out</TableHead>
                    <TableHead className="text-center">Work Hours</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    {isAdmin && <TableHead className="text-right">Actions</TableHead>}
                </TableRow>
                </TableHeader>
                <TableBody>
                {processedDailyData.length > 0 ? (
                    processedDailyData.map((item, index) => (
                    <TableRow key={`${item.employeeId}-${index}`}>
                        <TableCell>{item.date}</TableCell>
                        <TableCell className="font-medium">{item.employeeName}</TableCell>
                        <TableCell className="text-center">{item.morningIn}</TableCell>
                        <TableCell className="text-center">{item.lunchOut}</TableCell>
                        <TableCell className="text-center">{item.lunchIn}</TableCell>
                        <TableCell className="text-center">{item.afternoonOut}</TableCell>
                        <TableCell className="text-center font-semibold">{item.workHours}</TableCell>
                        <TableCell className="text-center">
                        <Badge variant={item.statusVariant as any}>{item.status}</Badge>
                        </TableCell>
                        {isAdmin && (
                        <TableCell className="text-right">
                            <Button variant="ghost" size="icon" onClick={() => {
                            const dateObj = parse(item.date, 'E, MMM dd, yyyy', new Date());
                            setSelectedEmployeeForManualEntry(item.employeeId);
                            setSelectedDateForManualEntry(dateObj);
                            setIsAddManualEntryDialogOpen(true);
                            }}
                            disabled={item.isOnLeave}
                            >
                            <Edit3 className="h-4 w-4" />
                            </Button>
                        </TableCell>
                        )}
                    </TableRow>
                    ))
                ) : (
                    <TableRow>
                    <TableCell colSpan={isAdmin ? 9 : 8} className="h-60">
                        <div className="flex flex-col items-center justify-center text-center p-4">
                            <FileWarningIcon className="w-12 h-12 text-muted-foreground mb-3" />
                            <p className="text-lg font-medium">No Attendance Data</p>
                            <p className="text-sm text-muted-foreground">
                            {isAdmin && employees.length === 0 ? "Please add employees to the system to view attendance records." : "No attendance records found for the selected criteria."}
                            </p>
                        </div>
                    </TableCell>
                    </TableRow>
                )}
                </TableBody>
            </Table>
          ) : viewType === 'weekly' || viewType === 'monthly' ? (
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead className="text-center">Present</TableHead>
                        <TableHead className="text-center">Absent</TableHead>
                        <TableHead className="text-center">On Leave</TableHead>
                        {viewType === 'monthly' && <TableHead className="text-center">Lates</TableHead>}
                        {viewType === 'monthly' && <TableHead className="text-center">Undertime</TableHead>}
                        <TableHead className="text-center">Total Hours</TableHead>
                        <TableHead className="text-center">Avg Hours/Day</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {processedSummaryData.length > 0 ? (
                        processedSummaryData.map((item) => (
                            <TableRow key={item.employeeId}>
                                <TableCell className="font-medium">{item.employeeName}</TableCell>
                                <TableCell className="text-center">{item.presentDays}</TableCell>
                                <TableCell className="text-center">{item.absentDays}</TableCell>
                                <TableCell className="text-center">{item.leaveDays}</TableCell>
                                {viewType === 'monthly' && <TableCell className="text-center">{item.lateCount}</TableCell>}
                                {viewType === 'monthly' && <TableCell className="text-center">{item.undertimeCount}</TableCell>}
                                <TableCell className="text-center font-semibold">{item.totalHours}</TableCell>
                                <TableCell className="text-center">{item.avgHours}</TableCell>
                            </TableRow>
                        ))
                    ) : (
                       <TableRow>
                            <TableCell colSpan={viewType === 'monthly' ? 8 : 6} className="h-60">
                                <div className="flex flex-col items-center justify-center text-center p-4">
                                    <FileWarningIcon className="w-12 h-12 text-muted-foreground mb-3" />
                                    <p className="text-lg font-medium">No Summary Data</p>
                                    <p className="text-sm text-muted-foreground">No attendance records found for the selected period.</p>
                                </div>
                            </TableCell>
                        </TableRow>
                    )}
                </TableBody>
            </Table>
          ) : null}
        </CardContent>
      </Card>

      {/* Add/Edit Manual Entry Dialog */}
      <Dialog open={isAddManualEntryDialogOpen} onOpenChange={(isOpen) => {
        setIsAddManualEntryDialogOpen(isOpen);
        if (!isOpen) {
            formManualEntry.reset({ employeeId: '', date: new Date(), morningIn: '', lunchOut: '', lunchIn: '', afternoonOut: '' });
            setSelectedEmployeeForManualEntry('');
            setSelectedDateForManualEntry(new Date());
        }
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add/Edit Manual Attendance</DialogTitle>
            <DialogDescription>
              Fill in the details for the attendance record. Saving will overwrite existing data for the same employee and date.
            </DialogDescription>
          </DialogHeader>
          <Form {...formManualEntry}>
            <form id="manualAttendanceForm" onSubmit={formManualEntry.handleSubmit(onSubmitManualEntry)} className="space-y-4 py-2">
              <FormField
                control={formManualEntry.control}
                name="employeeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={(value) => {
                        field.onChange(value);
                        setSelectedEmployeeForManualEntry(value);
                      }}
                      disabled={loadingEmployees}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select an employee" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {employees.map(emp => (
                          <SelectItem key={emp.id} value={emp.id}>{emp.name} ({emp.employeeId})</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={formManualEntry.control}
                name="date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Date</FormLabel>
                    <DatePicker
                      date={field.value}
                      onDateChange={(newDate) => {
                        field.onChange(newDate);
                        setSelectedDateForManualEntry(newDate);
                      }}
                      buttonClassName="w-full"
                    />
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={formManualEntry.control} name="morningIn" render={({ field }) => (
                    <FormItem><FormLabel>Morning In</FormLabel><FormControl><Input type="time" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={formManualEntry.control} name="lunchOut" render={({ field }) => (
                    <FormItem><FormLabel>Lunch Out</FormLabel><FormControl><Input type="time" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={formManualEntry.control} name="lunchIn" render={({ field }) => (
                    <FormItem><FormLabel>Lunch In</FormLabel><FormControl><Input type="time" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
                <FormField control={formManualEntry.control} name="afternoonOut" render={({ field }) => (
                    <FormItem><FormLabel>Afternoon Out</FormLabel><FormControl><Input type="time" {...field} value={field.value ?? ''} /></FormControl><FormMessage /></FormItem>
                )}/>
              </div>
            </form>
          </Form>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">
                <XCircle className="mr-2 h-4 w-4" /> Cancel
              </Button>
            </DialogClose>
            <Button type="submit" form="manualAttendanceForm" disabled={isSubmittingManualEntry || formManualEntry.formState.isSubmitting}>
              {isSubmittingManualEntry || formManualEntry.formState.isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Save Record
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Attendance Settings Dialog */}
      <Dialog open={isAttendanceSettingsDialogOpen} onOpenChange={setIsAttendanceSettingsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Configure Attendance Settings</DialogTitle>
            <DialogDescription>
              Set company-wide defaults and manage work shifts.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="defaults" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="defaults">Defaults</TabsTrigger>
              <TabsTrigger value="shifts">Shifts</TabsTrigger>
            </TabsList>
            <TabsContent value="defaults" className="mt-4">
              <Form {...formSettings}>
                <form id="attendanceSettingsForm" onSubmit={formSettings.handleSubmit(onSubmitSettings)} className="space-y-4 py-2">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField control={formSettings.control} name="expectedMorningIn" render={({ field }) => (
                      <FormItem><FormLabel>Expected Morning In</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={formSettings.control} name="expectedLunchOut" render={({ field }) => (
                      <FormItem><FormLabel>Expected Lunch Out</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField control={formSettings.control} name="expectedLunchIn" render={({ field }) => (
                      <FormItem><FormLabel>Expected Lunch In</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={formSettings.control} name="expectedAfternoonOut" render={({ field }) => (
                      <FormItem><FormLabel>Expected Afternoon Out</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  </div>
                  <FormField
                    control={formSettings.control}
                    name="requiredWorkHours"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Required Work Hours (per day)</FormLabel>
                        <FormControl><Input type="number" {...field} value={field.value?.toFixed(2) ?? '0.00'} readOnly className="bg-muted/50" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={formSettings.control}
                      name="lateGracePeriod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Late Grace Period (minutes)</FormLabel>
                          <FormControl><Input type="number" {...field} onChange={e => field.onChange(parseInt(e.target.value, 10))} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={formSettings.control}
                      name="earlyLeaveThreshold"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Early Leave Threshold (minutes)</FormLabel>
                          <FormControl><Input type="number" {...field} onChange={e => field.onChange(parseInt(e.target.value, 10))} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </form>
              </Form>
            </TabsContent>
            <TabsContent value="shifts" className="mt-4">
              <div className="space-y-4">
                <Card>
                  <CardContent className="pt-6 space-y-3">
                    {currentShifts.map((shift) => (
                      <div key={shift.id} className="flex justify-between items-center p-2 border rounded-md">
                        <div>
                          <p className="font-semibold">{shift.name}</p>
                          <p className="text-sm text-muted-foreground">{shift.startTime} - {shift.endTime}</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteShift(shift.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </div>
                    ))}
                    {currentShifts.length === 0 && <p className="text-center text-sm text-muted-foreground py-4">No custom shifts created.</p>}
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader><CardTitle className="text-md">Add New Shift</CardTitle></CardHeader>
                  <CardContent className="space-y-3">
                    <Input placeholder="Shift Name (e.g., Night Shift)" value={newShiftName} onChange={(e) => setNewShiftName(e.target.value)} />
                    <div className="flex gap-4">
                      <Input type="time" value={newShiftStartTime} onChange={(e) => setNewShiftStartTime(e.target.value)} />
                      <Input type="time" value={newShiftEndTime} onChange={(e) => setNewShiftEndTime(e.target.value)} />
                    </div>
                    <Button onClick={handleAddNewShift} className="w-full">
                      <PlusCircle className="mr-2 h-4 w-4" /> Add Shift to List
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter className="mt-4">
            <DialogClose asChild>
              <Button type="button" variant="outline">
                <XCircle className="mr-2 h-4 w-4" /> Cancel
              </Button>
            </DialogClose>
            <Button type="submit" form="attendanceSettingsForm" disabled={isSubmittingSettings || formSettings.formState.isSubmitting}>
              {isSubmittingSettings || formSettings.formState.isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Save Settings
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
