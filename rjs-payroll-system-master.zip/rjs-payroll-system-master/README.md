# RJS Payroll System

This is a NextJS starter for the RJS Payroll System.

To get started, take a look at src/app/page.tsx.
