# **App Name**: RJS Payroll System

## Core Features:

- Role Management: Role-based access control to ensure users only see relevant information.
- Admin Dashboard: Interactive dashboard for admins with key metrics on employees, leave requests, and payroll.
- Employee Profiles: User profile pages with at-a-glance view of personal information, attendance, and payslips.
- Employee Directory: Tabular display of employee data with search and filter options for easy navigation.
- Visual Calendar: Calendar view showing attendance status and leave schedules.
- Leave Management: Leave application form for users, and an approval workflow for admins.

## Style Guidelines:

- Background: Soft light gray (#F0F2F5) to provide a clean and neutral backdrop, enhancing readability.
- Primary: Calm blue (#64B5F6) for main interactive elements and headings to convey professionalism and trust.
- Accent: Muted cyan (#4DB6AC) to highlight important actions and notifications, creating visual interest without overwhelming the user.
- Clear, sans-serif font for readability, such as Open Sans, for all text elements.
- Consistent, minimalist icons to represent modules and actions.
- Responsive grid system for consistent layout across devices.